<?

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	���˿ռ���Ϣ�б�ҳ��

	$RCSfile: spacelist.php,v $
	$Revision: 1.103 $
	$Date: 2007/06/05 13:19:37 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

$uid = empty($_SGET['uid'])?0:intval($_SGET['uid']);
if(empty($uid)) messagebox('error', 'not_found', S_URL);

dbconnect();

$space = getuserspace($uid);
if(empty($space)) messagebox('error', 'not_found', S_URL);//�û�û�п�ͨ�ռ�

if($space['islock']) {
	$_SCONFIG['htmlspace'] = 0;
	getcookie(1);
	if($uid != $_SGLOBAL['supe_uid'] && $_SGLOBAL['member']['groupid'] != 1) messagebox('error', 'space_lock');
} else {
	getcookie();
}

$space['showcp'] = 0;

$type = empty($_SGET['type'])?'':trim($_SGET['type']);
$_SGET['type'] = $type = in_array($type, array_merge(array('favorite','friend','bbs','group','model'), $_SGLOBAL['type']))?$type:'';

$page = empty($_SGET['page'])?1:intval($_SGET['page']);
$_SGET['page'] = $page = ($page<2)?1:$page;

$view = empty($_SGET['view'])?'':trim($_SGET['view']);
if($type == 'bbs') {
	if(B_VER == 4) {
		$viewcodes = array('blog', 'thread', 'myfav');
	} else {
		$viewcodes = array('blog', 'thread', 'myfav', 'post', 'question', 'answer', 'orig', 'apply', 'image', 'file');
	}
	$view = in_array($view, $viewcodes)?$view:'thread';
} else {
	if($view) {
		if($type == 'friend') {
			$view = in_array($view, array('track', 'fav', 'visitor'))?$view:'track';
		} else {
			$view = in_array($view, array('track', 'fav'))?$view:'track';
		}
	}
}
$_SGET['view'] = $view;

$_SGET['itemtypeid'] = $itemtypeid = empty($_SGET['itemtypeid'])?0:intval($_SGET['itemtypeid']);
$_SGET['starttime'] = $starttime = empty($_SGET['starttime'])?0:intval($_SGET['starttime']);
$_SGET['endtime'] = $endtime = empty($_SGET['endtime'])?0:intval($_SGET['endtime']);
$searchkey = stripsearchkey(postget('searchkey'));

if($starttime>=$endtime || sgmdate($starttime, 'Ym')<sgmdate($space['dateline'], 'Ym')) {
	$_SGET['starttime'] = $starttime = $_SGET['endtime'] = $endtime = 0;
}

if($itemtypeid || $starttime || $endtime || $searchkey) $_SCONFIG['htmlspacelist'] = 0;

$spaceself = 0;
if($uid == $_SGLOBAL['supe_uid']) {
	$spaceself = 1;
	$_SGET['php'] = 1;
}
if(!empty($_SGET['css'])) $_SCONFIG['htmlspacelist'] = 0;

if(!empty($_SCONFIG['htmlspacelist'])) {
	$_SHTML['uid'] = $uid;
	$_SHTML['action'] = 'spacelist';
	if($type) $_SHTML['type'] = $type;
	if($view) $_SHTML['view'] = $view;
	$_SHTML['page'] = $page;
	$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
	ehtml('get', $_SCONFIG['htmlspacelisttime']);
	$_SCONFIG['debug'] = 0;
}

include_once(S_ROOT.'./include/common.inc.php');

if(empty($type) || $type == 'bbs' || $type == 'favorite') {
	$perpage = 100;
} elseif($type == 'model') {
	$perpage = 50;
} else {
	$perpage = 20;
}
if(in_array($view, array('blog', 'thread', 'myfav'))) $perpage = 20;
$start = ($page-1)*$perpage;

$newurl = geturl('uid/'.$uid.($type?'/type/'.$type:'').($itemtypeid?'/itemtypeid/'.$itemtypeid:'').($starttime?'/starttime/'.$starttime:'').($endtime?'/endtime/'.$endtime:''));
$urlarr = array('uid'=>$uid, 'action'=>'spacelist');
if($type) {
	$urlarr['type'] = $type;
	$showtplfile = "styles/space/spacelist_log_$type.html.php";
} else {
	$showtplfile = 'styles/space/spacelist_subject.html.php';
}
if($view) $urlarr['view'] = $view;
if($itemtypeid) $urlarr['itemtypeid'] = $itemtypeid;
if($starttime) $urlarr['starttime'] = $starttime;
if($endtime) $urlarr['endtime'] = $endtime;
if($searchkey) $urlarr['searchkey'] = $searchkey;

$iarr = array();
$multipage = '';
$tabactive = array('','','','','','','','','');
$thepagename = '';

if(in_array($view, array('track', 'fav', 'visitor'))) {
	if($type == 'friend') {
		//����
		if($view == 'fav') {
			$itablename = 'friends';
			$icolname1 = 'frienduid';
			$icolname2 = 'uid';
			$tabactive[2] = ' xspace-active';
			$firendname = $lang['adding_time'];
			$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">FANS</a>';
		} elseif($view == 'track') {
			$itablename = 'visitors';
			$icolname1 = 'visitoruid';
			$icolname2 = 'uid';
			$tabactive[1] = ' xspace-active';
			$firendname = $lang['visit_time'];
			$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['space_track'].'</a>';
		} else {
			$itablename = 'visitors';
			$icolname1 = 'uid';
			$icolname2 = 'visitoruid';
			$tabactive[3] = ' xspace-active';
			$firendname = $lang['visiting_hours'];
			$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['visitors'].'</a>';
		}
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname($itablename).' WHERE '.$icolname1.'=\''.$uid.'\'');
		$listcount = $_SGLOBAL['db']->result($query, 0);
		if($listcount) {
			$query = $_SGLOBAL['db']->query('SELECT f.'.$icolname2.' AS fuid, f.dateline AS fdateline, u.* FROM '.tname($itablename).' f LEFT JOIN '.tname('userspaces').' u ON u.uid=f.'.$icolname2.' WHERE f.'.$icolname1.'=\''.$uid.'\' ORDER BY f.dateline DESC LIMIT '.$start.','.$perpage);
			while ($item = $_SGLOBAL['db']->fetch_array($query)) {
				$item = spacebatch($item);
				$iarr[] = $item;
			}
			$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
		}
	} elseif($type == 'group') {
		//�Ҳ����Ȧ��
		$tabactive[2] = ' xspace-active';
		$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['in_the_group'].'</a>';

		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('groupuid').' WHERE uid=\''.$uid.'\' AND flag > 0');
		$listcount = $_SGLOBAL['db']->result($query, 0);
		if($listcount) {
			$query = $_SGLOBAL['db']->query('SELECT g.*, gu.* FROM '.tname('groupuid').' gu LEFT JOIN '.tname('groups').' g ON g.gid=gu.gid WHERE gu.uid=\''.$uid.'\' ORDER BY gu.dateline DESC LIMIT '.$start.','.$perpage);
			while ($item = $_SGLOBAL['db']->fetch_array($query)) {
				$item = groupbatch($item);
				$iarr[] = $item;
			}
			$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
		}
	} else {
		//��Ϣ
		if($view == 'fav') {
			$itablename = 'favorites';
			$tabactive[2] = ' xspace-active';
			$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang[$type].$lang['favorite'].'</a>';
		} else {
			$itablename = 'tracks';
			$tabactive[1] = ' xspace-active';
			$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang[$type].$lang['tracks'].'</a>';
		}
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname($itablename).' f INNER JOIN '.tname('spaceitems').' i ON i.itemid=f.itemid AND i.type=\''.$type.'\' WHERE f.uid=\''.$uid.'\'');
		$listcount = $_SGLOBAL['db']->result($query, 0);
		if($listcount) {
			$selectplus = $joinplus = $query = '';
			$query = $_SGLOBAL['db']->query('SELECT f.dateline AS f_dateline, i.*, ii.*'.$selectplus.' FROM '.tname($itablename).' f INNER JOIN '.tname('spaceitems').' i ON i.itemid=f.itemid AND i.type=\''.$type.'\' AND i.folder=1 LEFT JOIN '.tname(gettypetablename($type)).' ii ON ii.itemid=f.itemid WHERE f.uid=\''.$uid.'\' ORDER BY f.dateline DESC LIMIT '.$start.','.$perpage);
			while ($item = $_SGLOBAL['db']->fetch_array($query)) {
				$item = itembatch($item);
				$iarr[] = $item;
			}
			$multipage = multi($listcount, $perpage, $page, $urlarr, 0);		
		}
	}
} else {
	
	$wherearr = array();
	$tabactive[0] = ' xspace-active';
	if ($type == 'friend') {
		$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type").'">'.$lang['friend'].'</a>';
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('friends').' WHERE uid=\''.$uid.'\'');
		$listcount = $_SGLOBAL['db']->result($query, 0);
		if($listcount) {
			$query = $_SGLOBAL['db']->query('SELECT f.frienduid AS uid, f.dateline AS fdateline, f.grade, u.* FROM '.tname('friends').' f LEFT JOIN '.tname('userspaces').' u ON u.uid=f.frienduid WHERE f.uid=\''.$uid.'\' ORDER BY u.lastpost DESC LIMIT '.$start.','.$perpage);
			while ($item = $_SGLOBAL['db']->fetch_array($query)) {
				$item = spacebatch($item);
				$iarr[] = $item;
			}
			$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
		}
		$firendname = $lang['friends_time'];
	} elseif ($type == 'group') {
		//Ȧ��
		$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type").'">'.$lang['group'].'</a>';
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('groups').' WHERE uid=\''.$uid.'\' AND flag=\'1\'');
		$listcount = $_SGLOBAL['db']->result($query, 0);
		if($listcount) {
			$query = $_SGLOBAL['db']->query('SELECT g.gid,g.groupname,g.catid,g.ispublic,g.usernum,g.logo,g.lastpost,g.dateline,gf.intro FROM '.tname('groups').' g LEFT JOIN '.tname('groupfields').' gf ON gf.gid=g.gid WHERE g.uid=\''.$uid.'\' AND g.flag=\'1\' ORDER BY g.dateline DESC LIMIT '.$start.','.$perpage);
			while ($item = $_SGLOBAL['db']->fetch_array($query)) {
				$item = groupbatch($item);
				$iarr[] = $item;
			}
			$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
		}
	} elseif ($type == 'model') {
		include_once(S_ROOT.'./function/model.func.php');
		$midarr = getuserspacemid();
		$modellist = array();
		$hidemodellist = array();
		$_SGET['mid'] = empty($_SGET['mid']) ? 0 : intval($_SGET['mid']);
		$_SGET['uid'] = empty($_SGET['uid']) ? 0 : intval($_SGET['uid']);
		foreach($midarr as $mkey => $mvalue) {
			if($mkey < 5) {
				$modellist[$mkey]['modelname'] = $mvalue['modelname'];
				$modellist[$mkey]['mid'] = $mvalue['mid'];
				if(empty($_SGET['mid']) && $mkey ==0) {
					$modellist[$mkey]['active'] = ' class="xspace-active"';
					$_SGET['mid'] = $mvalue['mid'];
				} elseif($_SGET['mid'] ==$mvalue['mid']) {
					$modellist[$mkey]['active'] = ' class="xspace-active"';
				} else {
					$modellist[$mkey]['active'] = '';
				}
				$modellist[$mkey]['modelalias'] = $mvalue['modelalias'];	
			} else {
				$hidemodellist[$mkey]['modelname'] = $mvalue['modelname'];
				$hidemodellist[$mkey]['mid'] = $mvalue['mid'];
				$hidemodellist[$mkey]['modelalias'] = $mvalue['modelalias'];
			}
		}
		if(!empty($_SGET['mid'])) {
			$cacheinfo = getmodelinfoall('mid', $_SGET['mid']);
			$thepagename = $cacheinfo['models']['modelalias'];
			if(empty($cacheinfo['models'])) {
				messagebox('error', 'visit_the_channel_does_not_exist', S_URL);
			}
			$resultmodels = $cacheinfo['models'];
			$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname($resultmodels['modelname'].'items')." WHERE uid='$_SGET[uid]'");
			$listcount = $_SGLOBAL['db']->result($query, 0);
			$multipage = '';
			$listarr = array();
			if($listcount) {
				$urlarr['mid'] = intval($_SGET['mid']);
				$akey = 0;
				$multipage = multi($listcount, $perpage, $_SGET['page'], $urlarr , 0);
				$query = $_SGLOBAL['db']->query("SELECT itemid, catid, subject, dateline, viewnum FROM ".tname($resultmodels['modelname'].'items')." WHERE uid='$_SGET[uid]' ORDER BY dateline DESC LIMIT $start,$perpage");
				while ($item = $_SGLOBAL['db']->fetch_array($query)) {
					$listarr[$akey] = $item;
					$listarr[$akey++]['name'] = $cacheinfo['categories'][$item['catid']];
				}
				unset($akey);
			}
		}
	} elseif ($type == 'bbs') {
		//��̳
		dbconnect(1);
		if(!empty($starttime)) {
			$wherearr[] = 't.dateline>=\''.$starttime.'\'';
			$urlarr['starttime'] = $starttime;
		}
		if(!empty($endtime)) {
			$wherearr[] = 't.dateline<=\''.$endtime.'\'';
			$urlarr['endtime'] = $endtime;
		}
		if(empty($wherearr)) {
			$wheresql = '';
		} else {
			$wheresql = ' AND '.implode(' AND ', $wherearr);
		}
		
		$tabactive = array('','','','','','','','','','');
		
		switch ($view) {
			case 'thread':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['forum_on_the_theme'].'</a>';
				include_once(S_ROOT.'./function/bbs.func.php');
				$tabactive[0] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('mythreads', 1).' m, '.tname('threads', 1).' t WHERE m.uid=\''.$uid.'\' AND m.tid=t.tid AND t.displayorder>=0 '.$wheresql);
				$list_query = 'SELECT t.*, p.message FROM '.tname('mythreads', 1).' m, '.tname('threads', 1).' t, '.tname('posts', 1).' p WHERE m.uid=\''.$uid.'\' AND m.tid=t.tid AND t.displayorder>=0 AND t.author!=\'\' AND p.tid=t.tid AND p.first=1 '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'blog':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['my_corpus'].'</a>';
				include_once(S_ROOT.'./function/bbs.func.php');
				$tabactive[1] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('threads', 1).' t WHERE t.blog=1 AND t.authorid=\''.$uid.'\' AND t.displayorder>=0 '.$wheresql);
				$list_query = 'SELECT t.*, p.message FROM '.tname('threads', 1).' t, '.tname('posts', 1).' p WHERE t.blog=1 AND t.authorid=\''.$uid.'\' AND t.displayorder>=0 AND p.tid=t.tid AND p.first=1 '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'myfav':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['thread_favorite'].'</a>';
				include_once(S_ROOT.'./function/bbs.func.php');
				$tabactive[9] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query("SELECT COUNT(*) FROM ".tname('favorites', 1)." fav, ".tname('threads', 1)." tf WHERE fav.uid='$uid' AND tf.tid=fav.tid AND tf.displayorder>='0' ".$wheresql);
				$list_query = 'SELECT t.*, p.message FROM '.tname('favorites', 1).' fav, '.tname('threads', 1).' t, '.tname('posts', 1).' p WHERE fav.uid=\''.$uid.'\' AND t.tid=fav.tid AND t.displayorder>=0 AND p.tid=t.tid AND p.first=1 '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'image':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['bbs_image'].'</a>';
				$tabactive[2] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('attachments', 1).' t WHERE t.uid=\''.$uid.'\' AND t.isimage=\'1\' '.$wheresql);
				$list_query = 'SELECT t.* FROM '.tname('attachments', 1).' t WHERE t.uid=\''.$uid.'\' AND t.isimage=\'1\' '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'file':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['bbs_file'].'</a>';
				$tabactive[3] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('attachments', 1).' t WHERE t.uid=\''.$uid.'\' AND t.isimage=\'0\' '.$wheresql);
				$list_query = 'SELECT t.* FROM '.tname('attachments', 1).' t WHERE t.uid=\''.$uid.'\' AND t.isimage=\'0\' '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'post':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['sideblock_bbsreply'].'</a>';
				$tabactive[4] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('myposts', 1).' m, '.tname('threads', 1).' t WHERE m.uid=\''.$uid.'\' AND m.tid=t.tid AND t.displayorder>=0 '.$wheresql);
				$list_query = 'SELECT t.*, f.viewperm FROM '.tname('myposts', 1).' m, '.tname('threads', 1).' t LEFT JOIN '.tname('forumfields', 1).' f ON f.fid=t.fid WHERE m.uid=\''.$uid.'\' AND m.tid=t.tid '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'question':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['bbs_question'].'</a>';
				$tabactive[5] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('rewardlog', 1).' t WHERE t.authorid=\''.$uid.'\' '.$wheresql);
				$list_query = 'SELECT tt.*, f.viewperm FROM '.tname('rewardlog', 1).' t LEFT JOIN '.tname('threads', 1).' tt ON tt.tid=t.tid LEFT JOIN '.tname('forumfields', 1).' f ON f.fid=tt.fid WHERE t.authorid=\''.$uid.'\' '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'answer':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['bbs_answer'].'</a>';
				$tabactive[6] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('rewardlog', 1).' t WHERE t.answererid=\''.$uid.'\' '.$wheresql);
				$list_query ='SELECT tt.*, f.viewperm FROM '.tname('rewardlog', 1).' t LEFT JOIN '.tname('threads', 1).' tt ON tt.tid=t.tid LEFT JOIN '.tname('forumfields', 1).' f ON f.fid=tt.fid WHERE t.answererid=\''.$uid.'\' '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
			case 'orig':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['bbs_orig'].'</a>';
				$tabactive[7] = ' xspace-active';
				$wheresql = str_replace('dateline', 'starttimefrom', $wheresql);
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('activities', 1).' t WHERE t.uid=\''.$uid.'\' '.$wheresql);
				$list_query = 'SELECT tt.*, f.viewperm FROM '.tname('activities', 1).' t LEFT JOIN '.tname('threads', 1).' tt ON tt.tid=t.tid LEFT JOIN '.tname('forumfields', 1).' f ON f.fid=tt.fid WHERE t.uid=\''.$uid.'\' '.$wheresql.' ORDER BY t.starttimefrom DESC LIMIT '.$start.','.$perpage;
				break;
			case 'apply':
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/view/$view").'">'.$lang['bbs_apply'].'</a>';
				$tabactive[8] = ' xspace-active';
				$count_query = $_SGLOBAL['db_bbs']->query('SELECT COUNT(*) FROM '.tname('activityapplies', 1).' t WHERE t.uid=\''.$uid.'\' '.$wheresql);
				$list_query = 'SELECT tt.*, f.viewperm FROM '.tname('activityapplies', 1).' t LEFT JOIN '.tname('threads', 1).' tt ON tt.tid=t.tid LEFT JOIN '.tname('forumfields', 1).' f ON f.fid=tt.fid WHERE t.uid=\''.$uid.'\' '.$wheresql.' ORDER BY t.dateline DESC LIMIT '.$start.','.$perpage;
				break;
		}
		$listcount = $_SGLOBAL['db_bbs']->result($count_query, 0);
		$infids = array();
		if($listcount) {
			$query = $_SGLOBAL['db_bbs']->query($list_query);
			while ($item = $_SGLOBAL['db_bbs']->fetch_array($query)) {

				if(!empty($item['viewperm'])) {
					$viewpermarr = explode("\t", $item['viewperm']);
					if(!in_array('7', $viewpermarr)) {
						continue;//�鿴��������������
					}
				}
				if($view != 'file' && $view != 'image' && empty($item['author'])) continue;

				if(empty($item['subject'])) {
					if(!empty($item['message'])) {
						$item['subject'] = cutstr(trim(strip_tags($item['message'])), 40, 1);
					} elseif(!empty($item['description'])) {
						$item['subject'] = cutstr(trim(strip_tags($item['description'])), 40, 1);
					} elseif(!empty($item['filename'])) {
						$item['subject'] = cutstr(trim(strip_tags($item['filename'])), 40, 1);
					}
				}

				if($view == 'blog') {
					//$item['url'] = getbbsurl('blog.php', array('tid'=>$item['tid']));
					//$item['url'] = geturl('uid/'.$item['authorid'].'/action/viewbbs/tid/'.$item['tid']);
					$item['url'] = getbbsurl('viewthread.php', array('tid'=>$item['tid']));
					$item['message'] = spacecutstr($item['message'], 500);
				} elseif($view == 'thread' || $view == 'myfav') {
					$infids[$item['fid']] = $item['fid'];
					$item['url'] = getbbsurl('viewthread.php', array('tid'=>$item['tid']));
					$item['message'] = spacecutstr($item['message'], 500);
				} elseif($view == 'image') {
					$item['attachment'] = getbbsattachment($item);
					$item['url'] = getbbsurl('viewthread.php', array('tid'=>$item['tid']));
				} else {
					$item['url'] = getbbsurl('viewthread.php', array('tid'=>$item['tid']));
				}
				$iarr[] = $item;
			}
			$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
		}
		//���
		$forums = array();
		if(!empty($infids)) {
			$query = $_SGLOBAL['db_bbs']->query("SELECT f.fid, f.name, f.status, ff.viewperm FROM ".tname('forums', 1)." f LEFT JOIN ".tname('forumfields', 1)." ff ON ff.fid=f.fid WHERE f.fid IN(".simplode($infids).")");
			while ($value = $_SGLOBAL['db']->fetch_array($query)) {
				if(!empty($value['viewperm'])) $value['viewperm'] = trim($value['viewperm']);
				$forums[$value['fid']] = $value;
			}
			$newiarr = $viewpermarr = array();
			foreach ($iarr as $key => $value) {
				if(empty($forums[$value['fid']]['status'])) continue;
				if(!empty($forums[$value['fid']]['viewperm'])) {
					if(empty($viewpermarr[$value['fid']])) $viewpermarr[$value['fid']] = explode("\t", $forums[$value['fid']]['viewperm']);
					if(!in_array('7', $viewpermarr[$value['fid']])) continue;
				}
				$newiarr[] = $value;
			}
			$iarr = $newiarr;
		}
	} else {
	
		$wherearr[] = 'i.uid=\''.$uid.'\'';

		if(empty($type)) {
			$wherearr[] = 'i.type!=\'news\'';
		} else {
			$urlarr['type'] = $type;
			$wherearr[] = 'i.type=\''.$type.'\'';
		}
		$wherearr[] = 'i.folder=1';

		if(!empty($itemtypeid)) {
			$wherearr[] = 'i.itemtypeid=\''.$itemtypeid.'\'';
		}
		if(!empty($starttime)) {
			$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/starttime/$starttime/endtime/$endtime").'">'.sgmdate($starttime, 'Y-m').$lang['archiver'].'</a>';
			
			$wherearr[] = 'i.dateline>=\''.$starttime.'\'';
		}
		if(!empty($endtime)) $wherearr[] = 'i.dateline<=\''.$endtime.'\'';
		if(!empty($searchkey)) {
			$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/searchkey/$searchkey").'">'.$lang['search'].' '.$searchkey.'</a>';

			$wherearr[] = 'i.subject LIKE \'%'.$searchkey.'%\'';
		}
		
		if(empty($thepagename)) {
			if(empty($type)) {
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type/searchkey/$searchkey").'">'.$lang['list'].'</a>';
			} else {
				$thepagename = '<a href="'.geturl("uid/$uid/action/spacelist/type/$type").'">'.$lang[$type].'</a>';
			}
		}

		$wheresql = implode(' AND ', $wherearr);
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('spaceitems').' i WHERE '.$wheresql);
		$listcount = $_SGLOBAL['db']->result($query, 0);
		if($listcount) {
			if(empty($type)) {
				$query = $_SGLOBAL['db']->query('SELECT i.* FROM '.tname('spaceitems').' i WHERE '.$wheresql.' ORDER BY i.top DESC, i.dateline DESC LIMIT '.$start.','.$perpage);
			} else {
				$query = $_SGLOBAL['db']->query('SELECT m.*, i.* FROM '.tname('spaceitems').' i LEFT JOIN '.tname(gettypetablename($type)).' m ON m.itemid=i.itemid WHERE '.$wheresql.' ORDER BY i.top DESC, i.dateline DESC LIMIT '.$start.','.$perpage);
			}
			while ($item = $_SGLOBAL['db']->fetch_array($query)) {
				$item = itembatch($item);
				$iarr[] = $item;
			}
			$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
		}
	}
}

$title = $space['username'].' '.$thepagename.($page>1?'('.$page.')':'').' - '.$space['spacename'].' - '.$_SCONFIG['sitename'].' '.$_SCONFIG['seotitle'].' - Powered by X-Space';
$keywords = $space['username'].','.$thepagename;
$description = '';
	
//ģ�鲼��
$leftblock = $mainblock = $rightblock = '';
if(!empty($type) && !empty($channels['types'][$type])) {
	$leftblock = 'photo,action,itemtype,search,archive,information,rss';
} else {
	$leftblock = 'photo,action,search,archive,information,rss';
}

$space['showside'] = 1;
if($space['spacemode'] == 'diy' && $space['layout'] == 2) {
	$rightblock = $leftblock;
	$leftblock = '';
}

$effect = '';

include_once(S_ROOT.'./include/space_template.inc.php');

ob_out();

if(!empty($_SCONFIG['htmlspacelist'])) {
	ehtml('make');
}

function spacebatch($item) {

	$item['pmurl'] = getbbsurl('pm.php', array('action'=>'send', 'uid'=>$item['uid']));
	$item['prourl'] = geturl('uid/'.$item['uid'].'/action/viewpro/showpro/1');
	$item['guestbookurl'] = geturl('uid/'.$item['uid'].'/action/viewpro');
	$item['spaceurl'] = geturl('uid/'.$item['uid']);
	$item['photo'] = getphoto($item['uid'], $item['photo']);
	if(empty($item['username'])) {
		$item['username'] = $item['uid'];
	}
	$item['url'] = geturl("uid/$item[uid]");
	return $item;
}

function groupbatch($item) {

	if(empty($item['logo'])) {
		$item['logo'] = S_URL.'/images/base/nopic.gif';
	} else {
		$item['logo'] = A_URL.'/'.$item['logo'];
	}
	$item['url'] = geturl("action/mygroup/gid/$item[gid]");
	return $item;
}

?>