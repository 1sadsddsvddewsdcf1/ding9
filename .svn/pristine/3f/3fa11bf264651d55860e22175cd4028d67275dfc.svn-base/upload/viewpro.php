<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	�鿴�û�����

	$RCSfile: viewpro.php,v $
	$Revision: 1.50 $
	$Date: 2007/06/19 20:04:39 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

$perpage = 20;

$page = empty($_SGET['page'])?1:intval($_SGET['page']);
$page = ($page<2)?1:$page;
$start = ($page-1)*$perpage;

$uid = empty($_SGET['uid'])?0:intval($_SGET['uid']);
if(empty($uid)) messagebox('error', 'not_found', S_URL);

include_once(S_ROOT.'./include/common.inc.php');

$proidarr = array();
$space = getuserspace($uid);
if(empty($space)) {
	sheader(B_URL.'/viewpro.php?uid='.$uid);
}
if($space['islock']) messagebox('error', 'space_lock', S_URL);
$space['showcp'] = 0;

getcookie(1);
if(!empty($_SGET['showpro']) && $page<2) {
	$choicearr = $userfield = $profieldarr = array();
	$profield = '';
	$invisible = ($_SGLOBAL['supe_uid'] != $uid) ? ' AND invisible=0' : '';
	$titlekeyarr = array(
		'nickname', 'sex', 'birth', 'marriage', 'star', 'folk', 'bloodtype', 'tall', 'weight', 'native', 'figure', 'email',
		'email2', 'email3', 'qq', 'msn', 'phone', 'mobile', 'address', 'postalcode', 'edu', 'school', 'job',
		'position', 'income', 'housing', 'smoke', 'drink', 'interest'
	);
	$titlearr = array();
	foreach ($titlekeyarr as $value) {
		$titlearr[$value] = $lang[$value];
	}
	$query = $_SGLOBAL['db']->query("SELECT proid, title, selective, choices FROM ".tname('userprofile')." WHERE available>0 ".$invisible." ORDER BY displayorder");
	while ($fields = $_SGLOBAL['db']->fetch_array($query)) {
		$profieldarr['profile_'.$fields['proid']] = $fields['title'];
		$proidarr[] = $fields['proid'];
		if ($fields['selective']) {
			foreach (explode("\n", $fields['choices']) as $item) {
				list($index, $choice) = explode('=', $item);
				$choicearr['profile_'.$fields['proid']][$index] = $choice;
			}
		}
	}
	$titlearr = array_merge($profieldarr, $titlearr);
	if (!empty($proidarr)) {
		$profield = implode(', profile_', $proidarr);
		$profield = 'profile_'.$profield;
	}
	$query = $_SGLOBAL['db']->query("SELECT ".$profield." FROM ".tname('userfields')." WHERE uid='$uid'");
	$userfields['field'] = $_SGLOBAL['db']->fetch_array($query);
	if ($userfields['field']) {
		$userfields['title'] = $titlearr;
		foreach ($choicearr as $key => $choice) {
			$valarr = $keyarr = array();
			if(!empty($userfields['field'][$key])) {
				$keyarr = explode(',', $userfields['field'][$key]);
				foreach($keyarr as $vkey => $val) {
					$valarr[] = $choice[$val];
				}
			}
			$userfields['field'][$key] = implode(',', $valarr);
		}
	}
	$space = array_merge($space, $userfields);
}

//����
$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('guestbooks').' WHERE uid=\''.$uid.'\'');
$listcount = $_SGLOBAL['db']->result($query, 0);

$guestbooks = array();
$multipage = '';

if($listcount && $start<$listcount) {
	$query = $_SGLOBAL['db']->query("SELECT u.*, g.* FROM ".tname('guestbooks')." g LEFT JOIN ".tname('userspaces')." u ON u.uid=g.authorid WHERE g.uid='$uid' ORDER BY g.dateline DESC LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$value['photo'] = getphoto($value['authorid'], $value['photo']);
		if($value['isprivate']) {
			if(!empty($_SGLOBAL['supe_uid']) && ($uid == $_SGLOBAL['supe_uid'] || $value['authorid'] == $_SGLOBAL['supe_uid'])) {
				$value['message'] = '['.$lang['private_title'].'] '.snl2br($value['message']);
				$value['message'] = "<font color=\"blue\">$value[message]</font>";
			} else {
				$value['message'] = $lang['isprivate'];
			}
		} else {
			$value['message'] = snl2br($value['message']);
		}
		$guestbooks[] = $value;
	}
	
	$urlarr = array('uid'=>$uid, 'action'=>'viewpro');
	$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
}

$showtplfile = 'styles/space/viewpro.html.php';

$thepagename = '<a href="'.geturl("uid/$uid/action/viewpro/showpro/1").'">'.$lang['my_nformation'].'</a>';
$title = $space['username'].' '.$thepagename.' - '.$space['spacename'].' - '.$_SCONFIG['sitename'];

//ģ�鲼��
$effect = '';
$leftblock = $mainblock = $rightblock = '';
$leftblock = 'photo,action,search,archive,information,rss';
$space['showside'] = 1;
if($space['spacemode'] == 'diy' && $space['layout'] == 2) {
	$rightblock = $leftblock;
	$leftblock = '';
} elseif($space['spacemode'] == 'bbs') {
	$leftblock = 'photo,action,information,rss';
}

include_once(S_ROOT.'./include/space_template.inc.php');

ob_out();

?>