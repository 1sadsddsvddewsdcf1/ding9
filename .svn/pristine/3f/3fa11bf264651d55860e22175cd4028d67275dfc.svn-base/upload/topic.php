<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	ר��

	$RCSfile: topics.php,v $
	$Revision: $
	$Date: $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}
$_SGET['id'] = !empty($_SGET['id']) ? intval($_SGET['id']) : 0;
if(!empty($_SCONFIG['htmlindex'])) {
	$_SHTML['action'] = 'topic';
	if($_SGET['id']) $_SHTML['id'] = $_SGET['id'];
	$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
	ehtml('get', $_SCONFIG['htmlindextime']);
	$_SCONFIG['debug'] = 0;
}

include_once(S_ROOT.'./include/common.inc.php');
include_once(S_ROOT.'./include/topic_element.inc.php');
include_once(S_ROOT.'./function/topic.func.php');


$results = $elementarr = $guidearr = array();

//�趨Ĭ��ֵ
$tplname = 'topic_index';
$title = $lang['topic'].' - '.$_SCONFIG['sitename'];
$keywords = $lang['topic'];
$description = $lang['topic'];
$guidearr[] = array('url' => geturl('action/topic'),'name' => $channels['menus']['topic']['name']);
if(!empty($channels['types']['topic'])) unset($channels['types']['topic']);
$fullpath = 0;

if(!empty($_SGET['id'])) {
	@$_SGLOBAL['db']->query('UPDATE '.tname('topics').' SET viewnum = viewnum+1 WHERE id = \''.$_SGET['id'].'\'');

	//��⻺���ļ�
	$cachefile = S_ROOT.'./cache/topic/topic_'.$_SGET['id'].'.cache.php';
	$cacheinfo = '';
	if(file_exists($cachefile)) {
		include_once($cachefile);
	}
	
	//���ػ�����ѯ
	if(!empty($cacheinfo) && is_array($cacheinfo)) {
		$results = $cacheinfo['topics'];
		$elementarr = $cacheinfo['topicelements'];
	} else {
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('topics').' WHERE id = \''.$_SGET['id'].'\'');
		$results = $_SGLOBAL['db']->fetch_array($query);
		if(!empty($results)) {
			$query = $_SGLOBAL['db']->query('SELECT id, elementno FROM '.tname('topicelements').' WHERE topid = \''.$results['id'].'\'');
			while ($values = $_SGLOBAL['db']->fetch_array($query)) {
				$elementarr[$values['elementno']][] = getelementtpl($elementtplarr, 'php', $values['id']);
			}
		
			$cacheinfo = array(
				'topics'	=>	$results,
				'topicelements'	=>	$elementarr
			);
			$cacheinfo = arrayeval($cacheinfo);
			$text = '$cacheinfo = '.$cacheinfo.';';
			writefile($cachefile, $text, 'php');
		}
	}
	
	if(!empty($results)) {
		$title = strip_tags($results['subject']).' - '.$_SCONFIG['sitename'];
		$keywords = strip_tags($results['subject']);
		$description = strip_tags($results['subject']);
		$topicimage = empty($results['image']) ? 'admin/images/topic/tpic.gif' : $results['image'];
		$tplname = 'topic/data/topic_'.$results['id'].'/template.html.php';
		$fullpath = 1;
	}
	
}

include template($tplname, $fullpath);

ob_out();

if(!empty($_SCONFIG['htmlindex'])) {
	ehtml('make');
} else {
	maketplblockvalue('cache');
}

function getelementevent($id) {
	echo '';
}
?>