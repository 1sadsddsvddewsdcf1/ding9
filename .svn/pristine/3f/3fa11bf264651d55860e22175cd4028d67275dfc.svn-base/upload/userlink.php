<?

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	�û��ĸ�������������תҳ��

	$RCSfile: userlink.php,v $
	$Revision: 1.9 $
	$Date: 2006/12/14 02:13:14 $
*/
include_once('./include/main.inc.php');
include_once(S_ROOT.'./include/common.inc.php');

if(!empty($_SGET['linkid'])) {
	$linkid = intval($_SGET['linkid']);
} else {
	$linkid = 0;
}
if(!empty($linkid)) {
	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('userlinks').' WHERE linkid=\''.$linkid.'\'');
	if($link = $_SGLOBAL['db']->fetch_array($query)) {
		$_SGLOBAL['db']->query('UPDATE '.tname('userlinks').' SET viewnum=viewnum+1 WHERE linkid=\''.$linkid.'\'');
		sheader($link['url']);
	} else {
		$linkid = 0;
	}
}

if(empty($linkid)) {
	header('Location: '.S_URL);
}

?>