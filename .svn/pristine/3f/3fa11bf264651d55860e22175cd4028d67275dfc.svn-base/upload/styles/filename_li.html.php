<?exit?>
<!--{loop $iarr $ikey $value}-->
<li><a href="{B_URL}/attachment.php?aid=$value[a_aid]" target="_blank">$value[a_filename]</a></li>
<!--{/loop}-->