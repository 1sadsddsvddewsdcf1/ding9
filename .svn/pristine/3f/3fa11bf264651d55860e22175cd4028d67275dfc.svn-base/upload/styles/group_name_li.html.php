<?exit?>
<!--{loop $iarr $ikey $value}-->
<li><a href="$value[url]" target="_blank" title="$value[groupname]">$value[groupname]</a> ($value[usernum],$value[username])</li>
<!--{/loop}-->