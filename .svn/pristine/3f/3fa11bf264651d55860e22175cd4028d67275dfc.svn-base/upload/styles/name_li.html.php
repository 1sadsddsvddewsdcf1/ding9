<?exit?>
<!--{loop $iarr $ikey $value}-->
<li><a href="$value[url]" target="_blank">$value[name]</a></li>
<!--{/loop}-->