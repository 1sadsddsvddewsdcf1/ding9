<?exit?>
<ul class="xspace-list">
<!--{loop $iarr $value}-->
	<li>
	<strong>[$value[typename]]</strong>
	<a href="$value[url]" target="_blank">$value[subject]</a>
	<span class="xspace-smalltxt">#date("Y-m-d",$value["dateline"])#</span>
	</li>
<!--{/loop}-->
</ul>

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->
