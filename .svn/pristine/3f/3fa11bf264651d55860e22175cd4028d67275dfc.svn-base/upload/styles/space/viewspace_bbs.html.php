<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['weather'])}--> / ����: $item[weather]<!--{/if}-->
	<!--{if !empty($item['mood'])}-->/ ����: $item[mood]<!--{/if}-->
	<!--{if !empty($item['digest'])}-->/ ����($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ �ö�($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ ����������<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ ���˷��ࣺ<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	�鿴( $item[viewnum] ) / 
	����( $item[replynum] )
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
	<br />
	<div class="xspace-imginlog">
		<!--{loop $item['attach'] $value}-->
		<a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank" title="����鿴��ͼƬ"><img src="$value[thumbpath]" alt="$value[subject]" class="xspace-imgstyle" /></a>
		<p>$value[subject]</p>
		<!--{/loop}-->
	</div>
</div>
<!--{if !empty($ads['spaceviewad'])}-->
<div class="xspace-itemmessage">
	$ads[spaceviewad]
</div>
<!--{/if}-->

<!--{if !empty($item['tracks'])}-->
<div id="xspace-tracks" class="xspace-msgmodule">
	<h5>
	<a href="{S_URL}/batch.track.php?itemid=$item[itemid]" target="_blank" title="�鿴ȫ����ӡ" style="float:right;" class="xspace-smalltxt">ȫ����ӡ</a>
	<a href="javascript:;" onclick="javascript:deletetrack($item[itemid]);" target="_self" title="����ҵĽ�ӡ" style="float:right;margin-right:0.5em;" class="xspace-smalltxt">������ӡ</a>
	���½�ӡ:
	</h5>
	<ul class="xspace-list">
	<!--{loop $item['tracks'] $value}-->
	<li class="xspace-avatarlist xspace-imgstyle"><a href="$value[url]" title="$value[username]������#date("Y-n-d", $value["dateline"])#���ʹ�������" target="_blank"><img src="$value[photo]" alt="$value[username]������#date("Y-n-d", $value["dateline"])#���ʹ�������" /></a><p><a href="$value[url]" target="_blank">$value[username]</a></p></li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<!--{if !empty($item['relatives'])}-->
<div id="xspace-relatives" class="xspace-msgmodule">
	<h5>����Ķ�:</h5>
	<ul class="xspace-list">
	<!--{loop $item['relatives'] $value}-->
	<li><a href="$value[url]" target="_blank">$value[subject]</a> <span class="xspace-smalltxt">(<a href="{S_URL}/?$value[uid]" target="_blank">$value[username]</a>, #date("Y-n-d", $value["dateline"])#)</span></li> 
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<p class="xspace-itemlinks">
	<a href="{B_URL}/viewthread.php?tid=$item[tid]" target="_blank">��̳ģʽ</a>
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$item[itemid]', 300, 150);">�Ƽ�</a>
	<a href="javascript:;" onclick="joinfavorite($item[itemid]);">�ղ�</a>
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$item[itemid]', 400);">����������</a>
	<!--{if !empty($channels['menus']['group'])}-->
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=group&amp;itemid=$item[itemid]', 300);">�Ƽ���Ȧ��</a>
	<!--{/if}-->
	<a href="{S_URL}/batch.manage.php?itemid=$item[itemid]" target="_blank">����</a>
</p>

<p class="xspace-itemtag">TAG: 
	<!--{loop $item[relativetags] $value}-->
	<a href="#action/tag/tagname/$value#" target="_blank">$value</a>
	<!--{/loop}-->
</p>

<div id="xspace-itemreply">
	<!--{if $commentlist}-->
	<!--{loop $commentlist $value}-->
	<dl>
		<dt>
			<!--{if empty($value['spacename'])}-->
			<img src="$value[photo]" class="xspace-signavatar xspace-imgstyle" alt="" />
			<!--{else}-->
			<a href="#uid/$value[authorid]#" target="_blank"><img src="$value[photo]" class="xspace-signavatar xspace-imgstyle" alt="$value[spacename]" /></a>
			<!--{/if}-->
			<!--{if empty($value['spacename'])}-->
			$value[author]
			<!--{else}-->
			<a href="#uid/$value[authorid]#" target="_blank">$value[author]</a>
			<!--{/if}-->
			<span class="xspace-smalltxt">������#date("Y-m-d H:i:s", $value["dateline"])#</span>
		</dt>
		<dd>
			<!--{if !empty($value['subject'])}--><strong>$value[subject]</strong><br /><!--{/if}-->
			$value[message]
			<br />
			<!--{if !empty($commentlist[$value['pid']]['attachments'])}-->
			<div class="xspace-imginlog">
			<!--{loop $commentlist[$value['pid']]['attachments'] $value}-->
				<!--{if $value['isimage']}-->
					<a href="{B_URL}/attachment.php?aid=$value[aid]" target="_blank"><img src="$value[attachment]" alt="$value[filename]" class="xspace-imgstyle" /></a><p>$value[filename]</p>
				<!--{else}-->
					<p><img src="{S_URL}/images/base/haveattach.gif" align="absmiddle" border="0"><a href="{B_URL}/attachment.php?aid=$value[aid]" target="_blank"><strong>$value[filename]</strong></a><br />($value[dateline], Size: $value[attachsize], Downloads: $value[downloads])</p>
				<!--{/if}-->
			<!--{/loop}-->
			</div>
			<!--{/if}-->
		</dd>
	</dl>
	<!--{/loop}-->
	<!--{/if}-->
	<div id="xspace-multipage-div" class="xspace-multipage"><a href="{B_URL}/viewthread.php?tid=$item[tid]" target="_blank">������̳���鿴ȫ������</a></div>
</div>

<div id="xspace-itemform">
	<form id="xspace-commentform" action="{B_URL}/post.php?action=reply&amp;tid=$item[tid]&amp;replysubmit=yes" method="post" target="_self">
		<fieldset>
			<legend>����˵����</legend>
			<p>
				<label for="xspace-subject">����</label>
				<input type="text" size="20" id="xspace-subject" name="subject" value="" /> (��ѡ)
			</p>
			<p>
				<label for="xspace-commentmsg">����</label>
				<textarea id="xspace-commentmsg" name="message"></textarea>
			</p>

			<p class="xspace-seccodeline">
				<label for="xspace-seccode">��֤</label>
				<input type="text" size="10" id="xspace-seccode" name="supe_seccode" value="" />
				<label for="xspace-seccode"><img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="" title="�����壿�����һ��" /></label>
			</p>

			<p>
				<input type="hidden" name="supe_fromsupesite" value="$item[fromsupesite]" />
				<input type="hidden" name="supe_jumpurl" value="$newsiteurl/?uid/{$item[uid]}/action/viewspace/itemid/{$item[itemid]}/php/1" />
				<input type="hidden" name="itemid" value="$itemid" />
				<input type="hidden" name="tid" value="$item[tid]" />
				<button value="true" type="submit" name="submitcomment" id="xspace-btncomment">�ύ����</button>
			</p>
		</fieldset>
	</form>
</div>

<script language="javascript" type="text/javascript">
<!--
function newseccode(obj) {
	obj.src='{S_URL}/batch.seccode.php?'+Math.random(1);
}
addImgLink("xspace-showmessage");addImgLink("xspace-itemreply");
//-->
</script>
