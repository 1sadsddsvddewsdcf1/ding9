<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['digest'])}--> / ����($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ �ö�($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ ����������<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ ���˷��ࣺ<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">�鿴( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">����( $item[replynum] )</a> / 
	<a href="#xspace-itemform">����( <span class="xspace-rategood" title="����">$item[goodrate]</span> / <span class="xspace-ratebad" title="����">$item[badrate]</span> )</a>
</div>

<div id="xspace-fileinfo">
	<ul id="xspace-filebaseinfo" class="xspace-propertylist">
		<!--{if $item['filesize']}--><li><strong>�ļ���С</strong>: $item[filesize] $item[filesizeunit]</li><!--{/if}-->
		<!--{if $item['version']}--><li><strong>�ļ��汾</strong>: $item[version]</li><!--{/if}-->
		<!--{if $item['producer']}--><li><strong>������</strong>: $item[producer]</li><!--{/if}-->
		<!--{if $item['downfrom']}--><li><strong>�ļ���Դ</strong>: $item[downfrom]</li><!--{/if}-->
		<!--{if $item['language']}--><li><strong>��������</strong>: $item[language]</li><!--{/if}-->
		<!--{if $item['permission']}--><li><strong>��Ȩ��ʽ</strong>: $item[permission]</li><!--{/if}-->
		<!--{if $item['system']}--><li><strong>����ƽ̨</strong>: $item[system]</li><!--{/if}-->
	</ul>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
</div>

<div class="xspace-filedown xspace-msgmodule">
	<!--{if $item[attach]}-->
	<div class="xspace-localdown">
		<h5>��������</h5>
		<!--{if !empty($credits['abs'])}-->
			<p>������Ҫ���ѣ�<img src="{S_URL}/images/base/credit.gif">{$credits[abs]}��{$_SCONFIG[creditname]}</p>
		<!--{/if}-->
		<ul class="xspace-list">
			<!--{loop $item[attach] $value}-->
			<li><a href="{S_URL}/batch.download.php?aid=$value[aid]">$value[subject]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->

	<!--{if $item[remoteurl]}-->
	<div class="xspace-remotedown">
		<h5>Զ������</h5>
		<ul class="xspace-list">
			<!--{loop $item[remoteurl] $value}-->
			<li><a href="$value[remoteurl]" target="_blank">$value[remoteurlname]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->