<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=groups&op=add&openwindow=1">������Ȧ��</a><p>
<ul class="xspace-listtab">
	<li class="{$tabactive[0]}"><a href="#uid/$uid/action/spacelist/type/group#">�Ҵ�����Ȧ��</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/group/view/fav#">�Ҳ����Ȧ��</a></li>
</ul>

<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">���ڻ�û�����Ȧ����Ϣ</div>
<!--{else}-->
<ul class="xspace-itemlist">
<!--{loop $iarr $value}-->
	<li class="xspace-grouplist">
		<p class="xspace-smalltxt xspace-joingroup">��Ȧ����$value[usernum]λ��Ա, <a href="javascript:;" onclick="javascript:joingroup('$value[gid]');">���뱾Ȧ</a></p>
		<h4 class="xspace-entrytitle"><strong class="xspace-imgstyle"><a href="$value[url]" target="_blank"><img src="$value[logo]" class="xspace-grouplogo" alt="$value[groupname]" /></a></strong>
		<a href="$value[url]" target="_blank">$value[groupname]</a></h4>
		<p class="xspace-smalltxt">
		<!--{if !empty($view)}-->
		Ȧ��: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a> ����ʱ��:
		<!--{else}-->
		������
		<!--{/if}-->
		#date("Y-m-d H:i:s", $value["dateline"])#
		</p>
		<!--{if !empty($value['intro'])}--><p>$value[intro]</p><!--{/if}-->
		<p class="xspace-itemlinks"><a href="$value[url]">����Ȧ��</a>
		<a href="#action/mygroup/gid/$value[gid]/op/list/type/bbs#">Ȧ��������</a>
		<a href="#action/mygroup/gid/$value[gid]/op/list/type/members#">��Ա�б�</a>
		</p>
	</li>
<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->