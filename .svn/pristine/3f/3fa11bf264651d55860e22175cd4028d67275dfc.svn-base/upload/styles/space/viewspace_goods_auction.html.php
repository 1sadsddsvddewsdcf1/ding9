<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['digest'])}--> / ����($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ �ö�($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ ����������<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ ���˷��ࣺ<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">�鿴( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">����( $item[replynum] )</a> / 
	<a href="#xspace-itemform">����( <span class="xspace-rategood" title="����">$item[goodrate]</span> / <span class="xspace-ratebad" title="����">$item[badrate]</span> )</a>
</div>

<div class="xspace-goodsinfo">
	<div id="xspace-goodspic" class="xspace-imgstyle"><a href="$item[image]" target="_blank" title="����鿴ԭʼͼƬ"><img src="$item[image]" alt="$item[subject]" /></a></div>
	<div id="xspace-ownerinfo" class="xspace-msgmodule">
		<h5>������Ϣ: $item[member][username]</h5>
		<ul class="xspace-propertylist">
			<li>(<a href="{B_URL}/viewpro.php?uid=$item[uid]" target="_blank">��̳����</a> <a href="{B_URL}/pm.php?action=send&amp;uid=$item[uid]" target="_blank">վ����ϵ</a>)</li>
			<li>��̳����: $item[member][group]</li>
			<li>ע��ʱ��: #date("Y-m-d H:i:s",$item["member"]["regdate"])#</li>
			<li>��󷢱�: #date("Y-m-d H:i:s",$item["member"]["lastpost"])#</li>
			<li>��̳����: $item[member][posts]</li>
			<li>��̳����: $item[member][credits]</li>
		</ul>
	</div>
	<div id="xspace-goodsprice">
		<p>��ǰ�۸�: <strong><!--{if !empty($item[buyprice])}-->$item[buyprice]<!--{else}-->$item[price]<!--{/if}--></strong> Ԫ</p>
		<p><a href="{S_URL}/batch.common.php?action=price&amp;itemid={$item[itemid]}" class="xspace-auction">����</a></p>
		<p>��Ʒ����: $item[stocknum] / �Ӽ۷���: $item[markup]Ԫ</p>
		<p><!--{if $item['chargemode'] == 'buy'}-->��ҳе��˷�<!--{else}-->���ҳе��˷�<!--{/if}--> ƽ��:$item[chargemail]Ԫ ���:$item[chargeexpress]Ԫ EMS:$item[chargeems]Ԫ</p>
	</div>
	<ul id="xspace-goodsbaseinfo" class="xspace-propertylist">
		<li>��������: #date("Y-m-d",$item["dateline"])#</li>
		<li>��ʼ����:#date("Y-m-d H:i:s",$item["starttime"])#</li>
		<li>��Ч����:$item[term]��</li>
		<li>��ɫ: $item[quality]</li>
		<li>���ڵ�: $item[province] $item[city]</li>
		<li>֧����ʽ: $item[paymenttype]</li>
	</ul>
	<p class="xspace-send2fav"><a href="javascript:;" onclick="joinfavorite($item[itemid]);">�����ղؼ�</a></p>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
</div>

<div id="xspace-aplist" class="xspace-msgmodule">
	<h5>�����б�(�����˴Σ�$item[auctionnum])</h5>
	<table summary="auction" cellspacing="0" cellpadding="2" width="100%">
	<colgroup>
		<col class="xspace-buyer" />
		<col class="xspace-price" />
		<col class="xspace-buynum" />
		<col class="xspace-time" />
		<col class="xspace-status" />
	</colgroup>
	<tr>
		<th width="20%">������</th>
		<th width="15%">�۸�/Ԫ</th>
		<th width="15%">����</th>
		<th width="35%">ʱ��</th>
		<th width="15%">״̬</th>
	</tr>
	<!--{loop $item[auctions] $key $value}-->
	<!--{if ($value['allow'] == 1 || $value['status'] == 1)}-->
	<tr class="xspace-ontop">
	<!--{else}-->
	<!--{if ($key % 2 == 1)}-->
	<tr class="xspace-darkrow">
	<!--{else}-->
	<tr>
	<!--{/if}-->
	<!--{/if}-->
		<td><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></td>
		<td>$value[price]</td>
		<td>$value[buynum]</td>
		<td>#date("Y-m-d H:i:s", $value["dateline"])#</td>
		<td><!--{if ($value['status'] == 1)}-->�ɹ� <img src="{S_URL}/images/base/okhank.gif" alt="���׳ɹ�"><!--{elseif ($value[allow] == 1 && $value[status] == 0)}-->���� <a href="{S_URL}/batch.common.php?action=auction&amp;code=$value[code]">����</a><!--{else}-->����<!--{/if}-->
		</td>
	</tr>
	<!--{/loop}-->
	</table>
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->