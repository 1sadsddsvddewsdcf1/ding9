<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=friends&amp;op=add&amp;openwindow=1">���Ӻ���</a><p>
<ul class="xspace-listtab">
	<li class="{$tabactive[0]}"><a href="#uid/$uid/action/spacelist/type/friend#">�ҵĺ���</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/friend/view/fav#">�ҵ�FANS</a></li>
	<li class="{$tabactive[1]}"><a href="#uid/$uid/action/spacelist/type/friend/view/track#">��ȥ���Ŀռ�</a></li>
	<li class="{$tabactive[3]}"><a href="#uid/$uid/action/spacelist/type/friend/view/visitor#">�ҵķÿ�</a></li>
</ul>

<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">���ڻ�û����غ�����Ϣ</div>
<!--{else}-->
<ul class="xspace-itemlist">
	<!--{loop $iarr $value}-->
	<li class="xspace-friendlist">
		
		<!--{if empty($value['spacename'])}-->
		<h4 class="xspace-entrytitle">
		<a href="#uid/$value[fuid]#" target="_blank"><img src="$value[photo]" alt="" class="xspace-friendavatar xspace-imgstyle" /></a>
		<a href="#uid/$value[fuid]#" target="_blank">Member($value[fuid])</a>
		</h4>
		<p>��̳��Ա</p>
		<p>$firendname #date("", $value["fdateline"])#</p>
		<!--{else}-->
		<h4 class="xspace-entrytitle">
		<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=friendupdate&amp;uid=$value[uid]', 400);" target="_self"><img src="$value[photo]" alt="" class="xspace-friendavatar xspace-imgstyle" /></a>
		<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=friendupdate&amp;uid=$value[uid]', 400);" target="_self">$value[username]</a> 
		</h4>
		<p><a href="#uid/$value[uid]#" target="_blank">$value[spacename]</a> $value[province] $value[city]</p>
		<p>�ռ���� #date("", $value["lastpost"])# (<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=friendupdate&amp;uid=$value[uid]', 400);" target="_self">$value[spaceallnum]</a>)</p>
		<p>$firendname #date("", $value["fdateline"])#</p>
		<p class="xspace-itemlinks">
			<a class="xspace-profile" href="$value[prourl]" target="_blank">��������</a>
			<a class="xspace-sendpm" href="$value[pmurl]" target="_blank">����Ϣ</a>
			<a class="xspace-addfriend" href="javascript:;" onclick="javascript:joinfriend('$value[uid]');">��Ϊ����</a>
			<a class="xspace-guestbook" href="$value[guestbookurl]" target="_blank">��������</a>
		</p>
		<!--{/if}-->
	</li>
	<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->
