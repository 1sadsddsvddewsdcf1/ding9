<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['weather'])}--> / ����: $item[weather]<!--{/if}-->
	<!--{if !empty($item['mood'])}-->/ ����: $item[mood]<!--{/if}-->
	<!--{if !empty($item['digest'])}-->/ ����($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ �ö�($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ ����������<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ ���˷��ࣺ<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">�鿴( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">����( $item[replynum] )</a> / 
	<a href="#xspace-itemform">����( <span class="xspace-rategood" title="����">$item[goodrate]</span> / <span class="xspace-ratebad" title="����">$item[badrate]</span> )</a>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
	<br />
	<div class="xspace-imginlog">
		<!--{loop $item['attach'] $value}-->
		<!--{if $value['isimage']}-->
		<a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank" title="����鿴��ͼƬ"><img src="$value[thumbpath]" alt="$value[subject]" class="xspace-imgstyle" /></a>
		<p><a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank">$value[subject]</a></p>
		<!--{else}-->
		<a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank"><img src="{S_URL}/images/base/attachment.gif" border="0" alt="$value[subject]" ></a>
		<p><a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank">$value[filename](<!--{eval echo formatsize($value[size]);}-->)</a></p>
		<!--{/if}-->
		<!--{/loop}-->
	</div>
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->
