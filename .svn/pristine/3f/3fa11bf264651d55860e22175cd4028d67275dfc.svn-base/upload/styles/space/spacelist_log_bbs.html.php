<?exit?>

<ul class="xspace-listtab">
	<li class="{$tabactive[0]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/thread#">����</a></li>
	<li class="{$tabactive[1]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/blog#">�ļ�</a></li>
	<li class="{$tabactive[9]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/myfav#">�ղ�</a></li>
	<!--{if B_VER == '5'}-->
	<li class="{$tabactive[4]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/post#">�ظ�</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/image#">ͼƬ</a></li>
	<li class="{$tabactive[3]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/file#">�ļ�</a></li>
	<li id="xspace-myentry" class="xspace-sublist" onmouseover="showHideCatList('show', this.id, 'xspace-catlist', 5, 30, 68);" onmouseout="showHideCatList('hide', this.id, 'xspace-catlist');">����</li>
	<!--{/if}-->
</ul>

<div id="xspace-catlist" class="xspace-sublistitem" onmouseover="showHideCatList('show', 'xspace-myentry', this.id, 5, 30, 68);" onmouseout="showHideCatList('hide', 'xspace-myentry', this.id);">
	<ul>
		<li class="{$tabactive[5]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/question#">����</a></li>
		<li class="{$tabactive[6]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/answer#">�ش�</a></li>
		<li class="{$tabactive[7]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/orig#">�</a></li>
		<li class="{$tabactive[8]}"><a href="#uid/$uid/action/spacelist/type/bbs/view/apply#">����</a></li>
	</ul>
</div>

<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">���ڻ�û�������̳��Ϣ</div>
<!--{else}-->
<!--{if $view == 'image'}-->
<ul class="xspace-list">
	<!--{loop $iarr $value}-->
	<li class="xspace-imagelist xspace-imgstyle"><a href="$value[url]" target="_blank"><img src="$value[attachment]" /></a><p><a href="$value[url]" target="_blank">$value[subject]</a></p></li>
	<!--{/loop}-->
</ul>
<!--{elseif $view == 'thread' || $view == 'blog' || $view == 'myfav'}-->
<ul class="xspace-itemlist">
	<!--{loop $iarr $value}-->
	<li class="xspace-loglist">
		<h4 class="xspace-entrytitle"><a href="$value[url]" target="_blank">$value[subject]</a></h4>
		
		<p class="xspace-smalltxt"><a href="{B_URL}/redirect.php?tid=$value[tid]&goto=lastpost#lastpost" target="_blank" class="xspace-smalltxt">#date("Y-m-d H:i:s", $value["dateline"])#</a>
		<!--{if !empty($forums[$value['fid']]['name'])}-->
		 &nbsp; / &nbsp; <a href="{B_URL}/forumdisplay.php?fid=$value[fid]" target="_blank" class="xspace-smalltxt">{$forums[$value['fid']]['name']}</a>
		<!--{/if}-->
		</p>
		<div class="xspace-itemmessage" id="xspace-tid-{$value[tid]}">
		$value[message]
		</div>
		<p class="xspace-itemlinks">
			<a href="$value[url]" target="_blank">�鿴($value[views])</a>
			<a href="{B_URL}/post.php?action=reply&fid=$value[fid]&tid=$value[tid]" target="_blank">����($value[replies])</a>
		</p>
	</li>
	<!--{/loop}-->
</ul>
<!--{else}-->
<ul class="xspace-list">
	<!--{loop $iarr $value}-->
	<li><a href="$value[url]" target="_blank">$value[subject]</a> <span class="xspace-smalltxt">#date("Y-m-d",$value["dateline"])#</span></li>
	<!--{/loop}-->
</ul>
<!--{/if}-->
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->