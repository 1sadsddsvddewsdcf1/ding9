<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">��һƪ</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['digest'])}--> / ����($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ �ö�($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ ����������<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ ���˷��ࣺ<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">�鿴( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">����( $item[replynum] )</a> / 
	<a href="#xspace-itemform">����( <span class="xspace-rategood" title="����">$item[goodrate]</span> / <span class="xspace-ratebad" title="����">$item[badrate]</span> )</a>
</div>

<div class="xspace-linkproperty">
	<ul class="xspace-propertylist">
		<li><strong>��ַ</strong>: <a href="{S_URL}/batch.viewlink.php?itemid=$item[itemid]" target="_blank">$item[url]</a></li>
		<li><strong>����</strong>: <a href="{S_URL}/batch.viewlink.php?action=snapshot&amp;itemid=$item[itemid]" target="_blank">�鿴����</a></li>
		<li><strong>��Ȥ</strong>: <a href="{S_URL}/batch.viewlink.php?action=subject&amp;itemid=$item[itemid]" target="_blank">ͬ������ǩ</a> | <a href="{S_URL}/batch.viewlink.php?action=domain&amp;itemid=$item[itemid]" target="_blank">ͬվ����ǩ</a></li>
	</ul>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div class="xspace-itemmessage">
	<!--{eval echo nl2br($item[message])}-->
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->