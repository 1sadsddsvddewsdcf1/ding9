<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	վ����Ʒ��ҳ

	$RCSfile: goods.php,v $
	$Revision: 1.15 $
	$Date: 2007/06/27 17:15:08 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

if(!empty($_SCONFIG['htmlindex'])) {
	$_SHTML['action'] = 'goods';
	$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
	ehtml('get', $_SCONFIG['htmlindextime']);
	$_SCONFIG['debug'] = 0;
}

include_once(S_ROOT.'./include/common.inc.php');

$title = $lang['goods'].' - '.$_SCONFIG['sitename'];
$keywords = $lang['goods'];
$description = $lang['goods'];

$guidearr = array();
$guidearr[] = array('url' => geturl('action/goods'),'name' => $channels['menus']['goods']['name']);
if(!empty($channels['types']['topic'])) unset($channels['types']['topic']);

$tplname = 'goods_index';

$title = strip_tags($title);
$keywords = strip_tags($keywords);
$description = strip_tags($description);

include template($tplname);

ob_out();

if(!empty($_SCONFIG['htmlindex'])) {
	ehtml('make');
} else {
	maketplblockvalue('cache');
}

?>