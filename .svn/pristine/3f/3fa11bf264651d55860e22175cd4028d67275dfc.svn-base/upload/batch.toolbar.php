<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	ҳ�湤����

	$RCSfile: batch.toolbar.php,v $
	$Revision: 1.40 $
	$Date: 2007/06/25 14:39:34 $
*/


include_once('./include/main.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');
getcookie();

if(!empty($headercharset)) {
	@header('Content-Type: text/html; charset='.$charset);
}

$uid = intval($_SGLOBAL['supe_uid']);
$refer = $_SERVER['HTTP_REFERER'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$charset?>" />
<title>Tool Bar</title>
<link href="css/toolbar.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript" src="include/js/common.js"></script>
</head>
<body>

<div id="toolbar">
<?php
if(empty($uid)) {
	$siteurl = S_URL_ALL;
?>
	<div class="right">
		<ul>
			<li><a href="javascript:;" onclick="hidetoolbar();" class="close"><?=$blang['close']?></a></li>
			<form name="random" action="batch.common.php?action=random" method="post" target="_parent">
			<li><a class="random" href="javascript:document.random.submit()"><?=$blang['random']?></a></li>
			<li class="noborder"><?=$blang['username']?><input type="text" name="username" value=""></li>
			</form>
		</ul>
	</div>
	<div class="menus">
		<ul>
			<li class="noborder">
			<form id="tblogin" action="batch.login.php?action=login" method="post" target="_parent">
			<?=$blang['username']?> <input type="text" id="tbusername" name="username" />
			<?=$blang['password']?> <input type="password" id="tbpassword" name="password" />
			<button type="submit" class="login" name="loginsubmit" value="true"><?=$blang['login']?></button>
			<input type="hidden" name="refer" value="<?=$refer?>">
			</form>
			</li>
			<li><a href="<?=$bbsurl?>/register.php?referer=<?php echo $siteurl.'/?action/login';?>" class="register" target="_blank"><?=$blang['registration']?></a></li>
			<li><a href="<?=$bbsurl?>/member.php?action=lostpasswd" class="getpass" target="_blank"><?=$blang['find_passwords']?></a></li>
		</ul>
	</div>
<?php
} else {
	$spaceurl = url_remake(geturl("uid/$uid"));
?>
	<div class="right">
		<ul>
			<li><a href="javascript:;" onclick="hidetoolbar();" class="close"><?=$blang['close']?></a></li>
			<form name="random" action="batch.common.php?action=random" method="post" target="_parent">
			<li><a class="random" href="javascript:document.random.submit()"><?=$blang['random']?></a></li>
			<li class="noborder"><?=$blang['username']?><input type="text" name="username" value=""></li>
			</form>
		</ul>
	</div>
	<div id="quickguide">
		<ul id="menu">
			<li class="noborder"><?=$blang['fast_navigation']?></li>
			<li><a href="<?=$spaceurl?>" class="myspace" target="_parent"><?=$blang['my_space']?></a></li>
			<li><a href="spacecp.php?docp=1" class="manage" target="_blank"><?=$blang['space_management']?></a></li>
<?
if(!empty($channels['types'])) {
	foreach ($channels['types'] as $type => $value) {
		if($type != 'news' && $type != 'topic') {
			echo '<li><a href="spacecp.php?docp=me&action='.gettypetablename($type).'&op=add&openwindow=1" class="'.$type.'" target="_blank">'.$value['name'].'</a></li>';
		}
	}
}
?>			
			<li><a href="javascript:;" onclick="mngLink(this);" class="showmnglink"><?=$blang['editor_button_show']?></a></li>
			<li><a href="batch.login.php?action=logout&refer=<?echo rawurlencode($refer);?>" class="logout" target="_parent"><?=$blang['logout']?></a></li>
		</ul>
	</div>
<?php
}
?>

</body>
</html>