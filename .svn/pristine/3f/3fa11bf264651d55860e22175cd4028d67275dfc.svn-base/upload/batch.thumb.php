<?php

/*
	[SupeSite/X-Space](C)2001-2006ComsenzInc.
	ͼƬ�и�ִ�нű�

	$RCSfile: batch.thumb.php,v $
	$Revision: 1.6 $
	$Date: 2007/07/11 15:03:43 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./function/main.func.php');
include_once(S_ROOT.'./function/upload.func.php');
include_once(S_ROOT.'./language/batch.lang.php');

getcookie(1);

//û�е�¼
if(empty($_SGLOBAL['supe_uid']) || empty($_SGLOBAL['member']['password'])) {
	setcookie('_refer', rawurlencode(S_URL_ALL.'/admincp.php?'.$_SERVER['QUERY_STRING']));
	messagebox('error', 'admincp_login', geturl('action/login'));
}

//�ж��Ƿ�֧��DG��
if(!(function_exists('imageCreateFromJPEG') && function_exists('imageCreateFromPNG') && function_exists('imageCopyMerge'))) {
	messagebox('error', $blang['GD_lib_no_load']);
}

//�ж����ݺϷ���
if($_POST['imageauthcode'] != md5( $_POST['imagepath'].$_SCONFIG['sitekey'].$_POST['imagewidth'].$_POST['imageid'].$_POST['imageheight'].$_SGLOBAL['authkey'].$_POST['thumbimg'] )){
	messagebox('warning', 'parameter_chenged');
}

if(!empty($_POST['loop'])) {
$looparray = array('lux','luy','ldx','ldy','rux','ruy','rdx','rdy');
	foreach ($looparray as $imagemsg) {
			$_POST[$imagemsg] = round($_POST[$imagemsg] / $_POST['loop']);
	}
}

$width = $height = $image = $imagesrc = $swapfile = $makethumb  = '';

$picfiletype = fileext($_POST['imagepath']);

$pictypes = array();
$pictypes['gif'] = array('imagecreatefromgif','imagegif');
$pictypes['png'] = array('imagecreatefrompng','imagepng');
$pictypes['jpeg'] = array('imagecreatefromjpeg','imagejpeg');
$pictypes['jpg'] = array('imagecreatefromjpeg','imagejpeg');

$contenttypes = array();
$contenttypes['gif'] = 'image/gif';
$contenttypes['png'] = 'image/png';
$contenttypes['jpeg'] = 'image/jpg';
$contenttypes['jpg'] = 'image/jpg';

$width = $_POST['rdx'] - $_POST['ldx'];
$height = $_POST['rdy'] - $_POST['ruy'];

$image = @imagecreatetruecolor($width, $height);
$imagesrc = @$pictypes[$picfiletype][0]($_POST['imagepath']);

@imagecopy($image, $imagesrc, 0, 0, $_POST['ldx'], $_POST['luy'], $width, $height);

$swapfile = S_ROOT.'data/temp/swappic_'.$_SGLOBAL['supe_uid'].'.'.$picfiletype;

@$pictypes[$picfiletype][1]($image, $swapfile);

$makethumb = makethumb($swapfile, array($_POST['imagewidth'], $_POST['imageheight']), A_DIR.'/'.$_POST['thumbimg']);

@unlink ($swapfile);

print <<<END
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>$blang[thumb_image_ok]</title>
</head>
<script language="JavaScript">
<!--
function refreshParentImage(iamgeid) {
	var imagereload = opener.document.getElementById(iamgeid)
	imagereload.src = imagereload.src
	window.close();
}
//-->
</script>

<body onLoad="refreshParentImage('img$_POST[imageid]')">
<a href="./attachments/$_POST[thumbimg]"><img src="./attachments/$_POST[thumbimg]" border="0" /></a>
$blang[thumb_image_ok]<input type=button value="$blang[close_windows]" onClick="window.close();">
</body>
</html>
END;

?>