<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	XML RPC

	$RCSfile: xmlrpc.php,v $
	$Revision: 1.6 $
	$Date: 2007/06/07 21:00:35 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./include/common.inc.php');
include_once(S_ROOT.'/function/xmlrpc.func.php');

$_GET['rsd'] = @intval($_GET['rsd']);
if(!empty($_GET['rsd'])) {
	header("Content-type: text/xml", true);
	print ('<?xml version="1.0" encoding="utf-8" ?> 
	<rsd xmlns="http://archipelago.phrasewise.com/rsd" version="1.0">
    	<service xmlns="">
        <engineName>SupeSite BlogAPI</engineName> 
        <engineLink>http://x.discuz.net</engineLink>
        <homePageLink>'.S_URL_ALL.'/?'.$_GET['rsd'].'</homePageLink>
        <apis>
                <api name="MetaWeblog" preferred="true" apiLink="'.S_URL_ALL.'/xmlrpc.php" blogID="blog" />
        </apis>
	</service>
	</rsd>');
	exit();
}
dbconnect();
include_once(S_ROOT.'/class/xmlrpc.class.php');
$xmlrpc = xmlrpc::xmlrpcSet();
$data = $xmlrpc->xmlrpcServer();
?>