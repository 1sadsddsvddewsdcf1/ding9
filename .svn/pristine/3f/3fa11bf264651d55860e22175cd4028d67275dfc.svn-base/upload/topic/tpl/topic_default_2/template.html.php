<?exit?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset]" />
<title>$title - $_SCONFIG[sitename] $_SCONFIG[seotitle]- Powered By SupeSite</title>
<meta name="keywords" content="$keywords $_SCONFIG[seokeywords]" />
<meta name="description" content="$description $_SCONFIG[seodescription]" />
<link href="{S_URL}/css/topicelement.css" rel="stylesheet" type="text/css" />
<link href="{S_URL}/topic/tpl/$_GET[tpl]/topicstyle.css" rel="stylesheet" type="text/css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<!--{eval admincptopicmanage();}-->
<div id="wrap">
	<div id="header">
		<table border="0" cellpadding="0" cellspacing="0" id="headertab">
			<tr>
				<td id="logo">
					<a href="{S_URL}/"><img id="logo" src="{S_URL}/templates/default/images/logo.gif" alt="$_SCONFIG[sitename]" style="border: none;" /></a>
				</td>
				<td id="topmenu">
					<ul>
						<li><a href="{S_URL}/">��ҳ</a></li>
						<!--{loop $channels['menus'] $value}-->
						<li><a href="$value[url]">$value[name]</a></li>
						<!--{/loop}-->
						<li><a href="{S_URL}/batch.search.php">����</a></li>
					</ul>
				</td>
			</tr>
		</table>
		<!--{if !empty($_SCONFIG['indexadheader'])}-->	
		<div class="banner">$_SCONFIG[indexadheader]</div>
		<!--{/if}-->
	</div>
	<!--{eval $ads2 = getad('system','topic', 2);}-->
	<!--{if !empty($ads2['pageheadad'])}-->
	<div class="adbanner">$ads2[pageheadad]</div>
	<!--{/if}-->
	<div id="navigation">
		<form id="searchform" action="{S_URL}/batch.search.php" method="post">
			<input type="text" id="searchkey" name="searchkey" />
			<select name="type" id="type">
				<option value="">ȫ��</option>
				<!--{loop $channels['types'] $value}-->
					<option value="$value[nameid]">$value[name]</option>
				<!--{/loop}-->
			</select>
			<button type="submit" value="true" name="subjectsearch">����</button>
		</form>
		<p>����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a> &gt;&gt; 
			<a href="{S_URL}/?action-topic">ר��</a> &gt;&gt; 
			<span id="topicname"><!--{eval echo !empty($results[subject])?$results[subject]:'ר�����';}--></span>
		</p>
	</div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="26%" class="ss_side block" <!--{eval getelementevent(1);}-->>
				<!--{eval printelement(1);}-->
			</td>
			<td width="74%" class="ss_main">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td width="40%" class="block">
							<div class="tpic"><img src="{S_URL}/admin/images/topic/tpic.gif"></div>
						</td>
					    <td width="60%" <!--{eval getelementevent(2);}-->>
							<div id="introduction">
								<!--{eval echo !empty($results[message])?$results[message]:'';}-->
							</div>
							<!--{eval printelement(2);}-->
						</td>
					</tr>
					<tr>
					  <td colspan="2" <!--{eval getelementevent(3);}-->>
						<!--{eval printelement(3);}-->
					</td>
			      </tr>
				</table>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td width="50%" class="block" <!--{eval getelementevent(4);}-->>
							<!--{eval printelement(4);}-->
						</td>
					    <td width="50%" <!--{eval getelementevent(5);}-->>
							<!--{eval printelement(5);}-->
						</td>
					</tr>
					<tr>
					 	<td class="block" <!--{eval getelementevent(6);}-->>
							<!--{eval printelement(6);}-->
						</td>
					    <td <!--{eval getelementevent(7);}-->>
							<!--{eval printelement(7);}-->
						</td>
			      	</tr>
				</table>
			</td>
		</tr>
	</table>


<!--{if !empty($ads2['pagefootad'])}-->
<div class="adfooter">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads2['pageoutindex'])}-->
$ads2[pageoutindex]
<!--{/if}-->

<!-- Footer -->
<div id="footer">

	<!--{if !empty($_SCONFIG['indexadfooter'])}-->
	<p style="margin-bottom: 1em;">			
		$_SCONFIG[indexadfooter]
	</p>
	<!--{/if}-->
	<p>
		<a href="{S_URL}/">$_SCONFIG[sitename]</a> | 
		<a href="{B_URL}/" target="_blank">������̳</a> | 
		<a href="{S_URL}/?action/site/type/panel">������</a> | 
		<a href="{S_URL}/?action/site/type/map">վ���ͼ</a> | 
		<a href="{S_URL}/?action/site/type/link">��������</a> | 
		<a href="{S_URL}/?action/spaces">�ռ��б�</a> | 
		<a href="{S_URL}/archiver/">վ��浵</a> | 
		<a href="mailto:$_SCONFIG[adminemail]">��ϵ����</a>
	</p>
	<p id="copyright">
		Powered by <a href="http://www.supesite.com" target="_blank"><strong>Supe<span>Site</span></strong></a> <em><?=S_VER?></em> 
		&copy; 2001-2008 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
		<br />{eval debuginfo();}
	</p>
</div>
<!-- /Footer -->
</div>
</body>
</html>