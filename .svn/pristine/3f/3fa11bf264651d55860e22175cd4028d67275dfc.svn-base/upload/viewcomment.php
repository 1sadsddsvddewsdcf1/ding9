<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	�鿴����ҳ��

	$RCSfile: viewcomment.php,v $
	$Revision: 1.23 $
	$Date: 2007/03/19 16:14:57 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

include_once(S_ROOT.'./include/common.inc.php');

if(submitcheck('submitcomm', 1)) {
	
	$itemid = empty($_POST['itemid'])?0:intval($_POST['itemid']);
	if(empty($itemid)) messagebox('error', 'not_found', S_URL);
	
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) {
		if(empty($_SCONFIG['allowguest'])) {
			setcookie('_refer', rawurlencode(geturl('action/viewcomment/itemid/'.$itemid, 1)));
			messagebox('error', 'no_login', geturl('action/login'));
		}
	}
	
	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' WHERE itemid=\''.$itemid.'\' AND type=\'news\' AND folder=\'1\' AND allowreply=\'1\'');
	if(!$item = $_SGLOBAL['db']->fetch_array($query)) messagebox('error', 'no_permission', S_URL);

	$_POST['message'] = shtmlspecialchars(trim($_POST['message']));
	if(strlen($_POST['message']) < 2 || strlen($_POST['message']) > 10000) messagebox('error', 'message_length_error');
	$_POST['message'] = str_replace('[br]', '<br>', $_POST['message']);
	$_POST['message'] = str_replace('[quote]', '<blockquote class="xspace-quote">', $_POST['message']);
	$_POST['message'] = str_replace('[/quote]', '</blockquote>', $_POST['message']);

		//�ظ���������
	$_POST['message'] = censor($_POST['message']);

	$setsqlarr = array(
		'itemid' => $itemid,
		'type' => 'news',
		'uid' => '0',
		'authorid' => $_SGLOBAL['supe_uid'],
		'author' => $_SGLOBAL['supe_username'],
		'ip' => $_SGLOBAL['onlineip'],
		'dateline' => $_SGLOBAL['timestamp'],
		'rates' => $_POST['rates'],
		'message' => $_POST['message']
	);
	inserttable('spacecomments', $setsqlarr);

	if($_POST['rates']>0) {
		$goodrate = $_POST['rates'];
		$badrate = 0;
	} elseif($_POST['rates'] < 0) {
		$goodrate = 0;
		$badrate = 0 - $_POST['rates'];
	} else {
		$goodrate = 0;
		$badrate = 0;
	}
	$_SGLOBAL['db']->query('UPDATE '.tname('spaceitems').' SET lastpost='.$_SGLOBAL['timestamp'].', replynum=replynum+1,goodrate=goodrate+'.$goodrate.',badrate=badrate+'.$badrate.' WHERE itemid=\''.$itemid.'\'');

	messagebox('ok', 'succeed', geturl('action/viewcomment/itemid/'.$itemid));
}

if(!empty($_SGET['op']) && $_SGET['op'] == 'delete') {

	$cid = empty($_SGET['cid'])?0:intval($_SGET['cid']);
	if(empty($cid)) messagebox('error', 'not_found', S_URL);
	$itemid = empty($_SGET['itemid'])?0:intval($_SGET['itemid']);
	if(empty($itemid)) messagebox('error', 'not_found', S_URL);
	
	$deleteflag = false;
	getcookie(1);
	if(empty($_SGLOBAL['group'])) {
		messagebox('error', 'no_permission');
	}

	if($cid && $itemid && $_SGLOBAL['supe_uid']) {
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spacecomments').' WHERE cid=\''.$cid.'\'');
		if($comment = $_SGLOBAL['db']->fetch_array($query)) {
			if($_SGLOBAL['group']['groupid'] == 1 || $comment['authorid'] == $_SGLOBAL['supe_uid']) {
				if($comment['rates'] > 0) {
					$ratesql = ',goodrate=goodrate-'.$comment['rates'];
				} elseif ($comment['rates'] < 0) {
					$ratesql = ',badrate=badrate-'.abs($comment['rates']);
				} else {
					$ratesql = '';
				}
				$_SGLOBAL['db']->query('UPDATE '.tname('spaceitems').' SET replynum=replynum-1'.$ratesql.' WHERE itemid=\''.$comment['itemid'].'\'');
				$_SGLOBAL['db']->query('DELETE FROM '.tname('spacecomments').' WHERE cid=\''.$cid.'\'');
				$deleteflag = true;
			}
		}
	}
	if($deleteflag) {
		messagebox('ok', 'succeed', geturl('action/viewcomment/itemid/'.$itemid));
	} else {
		messagebox('error', 'no_permission');
	}
}

$perpage = 20;

$page = empty($_SGET['page'])?0:intval($_SGET['page']);
$page = ($page<1)?1:$page;
$start = ($page-1)*$perpage;

$itemid = empty($_SGET['itemid'])?0:intval($_SGET['itemid']);
if(empty($itemid)) messagebox('error', 'not_found', S_URL);

$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' WHERE itemid=\''.$itemid.'\' AND type=\'news\' AND folder=\'1\' AND allowreply=\'1\'');
if(!$item = $_SGLOBAL['db']->fetch_array($query)) messagebox('error', 'not_found', S_URL);

$listcount = $item['replynum'];
$iarr = array();
$multipage = '';
if($listcount) {
	$i = ($page-1)*$perpage + 1;
	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spacecomments').' WHERE itemid=\''.$itemid.'\' ORDER BY dateline DESC LIMIT '.$start.','.$perpage);
	while ($comment = $_SGLOBAL['db']->fetch_array($query)) {
		$comment['message'] = snl2br($comment['message']);
		$comment['num'] = $i;
		$i++;
		$iarr[] = $comment;
	}
	$urlarr = array('action'=>'viewcomment', 'itemid' => $itemid);
	$multipage = multi($listcount, $perpage, $page, $urlarr, 0);
}

$title = $item['subject'].' - '.$_SCONFIG['sitename'];

include template('news_viewcomment');

ob_out();

?>