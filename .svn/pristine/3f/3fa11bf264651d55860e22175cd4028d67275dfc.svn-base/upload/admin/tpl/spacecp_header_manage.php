<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	���˹���ҳ��ҳͷ

	$RCSfile: spacecp_header_manage.php,v $
	$Revision: 1.20 $
	$Date: 2007/06/18 19:37:24 $
*/

if(!defined('IN_SUPESITE_SPACECP')) {
	exit('Access Denied');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$_SCONFIG['charset']?>" />
<title>���˿ռ����</title>
<link href="<?=IMG_DIR?>/style.css" rel="stylesheet" type="text/css" />
<link href="<?=S_URL?>/images/edit/edit.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
var siteUrl = "<?=S_URL?>";
</script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/images/edit/edit.js"></script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/ajax.js"></script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/common.js"></script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/menu.js"></script>
<script language="javascript" type="text/javascript" src="<?=IMG_DIR?>/common.js"></script>
<script type="text/javascript">
	var spTips = GetCookie('spTips');
	var tipText = '��ʾ��������ʾ��Ϣ';
	if (spTips!=1) {
		tipText = '���ذ�������ʾ��Ϣ';
	}
	function showHideTips() {
		var shTips = getbyid('shtips');
		spTips = GetCookie('spTips');
		if (spTips!=1) {
			shTips.innerHTML = '��ʾ��������ʾ��Ϣ'
			CreatCookie('spTips','1');
		} else {
			shTips.innerHTML = '���ذ�������ʾ��Ϣ';
			DelCookie('spTips','0')
			
		}
	}
</script>
</head>

<body onload="addMouseEvent();">
<div class="wrap">

<table id="header" summary="header" cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr>
		<td>
			<div id="headertitle">
				<h1><a href="<?=S_URL?>/?<?=$_SGLOBAL['supe_uid']?>" title="�ص�<?=$space['spacename']?>��ҳ"><?=$space['spacename']?></a></h1>
				<p><?=$guide?></p>
			</div>
		</td>
		<td>
			<ul id="topmenu">
				<li>��ӭ����<a href="<?=CPURL?>?action=userspaces&op=photo"><?=stripslashes($_SGLOBAL['supe_username'])?></a> |</li>
				<li><a href="<?=S_URL?>/?<?=$_SGLOBAL['supe_uid']?>" target="_blank">�ҵĿռ���ҳ</a> |</li>
				<li><a href="<?=S_URL?>/" target="_blank">վ����ҳ</a> |</li>
				<li><a href="<?=B_URL?>/" target="_blank">������̳</a> |</li>
				<li><a href="<?=S_URL?>/batch.login.php?action=logout">�˳�</a></li>
			</ul>
			<ul id="actions">
				<li><a href="javascript:;" id="sidectrl" onclick="showContent('sidebar','sidectrl','�򿪲����','�رղ����');"><?=$sidetitle?></a></li>
				<li><a id="shtips" href="javascript:showHideTips();"><script type="text/javascript">document.write(tipText);</script></a></li>
			</ul>
		</td>
	</tr>
	<tr>
		<td colspan="2" id="menu">
			<ul>
				<?=$menustr?>
			</ul>
			<?=$popupmenustr?>
		</td>
	</tr>
</table>

<?php
$menucurrents = array('comment'=>'',
	'tracks'=>'',
	'favorites'=>'',
	'guestbook' => '',
	'userlinksadd'=>'',
	'userlinks'=>'',
	'attachments'=>'',
	'attachmentsdel'=>'',
	'update'=>'',
	'credit' => ''
);

if(empty($_GET['op'])) $_GET['op'] = 'comment';
if(empty($_GET['subop'])) $_GET['subop'] = '';
$menucurrents[$_GET['op'].$_GET['subop']] = ' class="current"';

?>

<table summary="content" cellpadding="0" cellspacing="0" border="0" width="100%" align="center">
<tr>
	<td id="sidebar" style="display:<?=$sidedisplay?>;">
		<div>
			<ul>
				<li><a href="<?=CPURL?>?action=manage&op=comment"<?=$menucurrents['comment']?>>���۹���</a></li>
				<li><a href="<?=CPURL?>?action=manage&op=tracks"<?=$menucurrents['tracks']?>>�㼣����</a></li>
				<li><a href="<?=CPURL?>?action=manage&op=favorites"<?=$menucurrents['favorites']?>>�ղع���</a></li>
				<li><a href="<?=CPURL?>?action=manage&op=guestbook"<?=$menucurrents['guestbook']?>>���Թ���</a></li>
			</ul>
		</div>
		<div>
			<ul>
				<li><a href="<?=CPURL?>?action=manage&op=credit"<?=$menucurrents['credit']?>><img src="images/base/credit.gif" border="0"><?=$_SCONFIG['creditname']?>����</a></li>
			</ul>
		</div>
		<div>
			<ul>
				<li><a href="<?=CPURL?>?action=manage&op=userlinks&subop=add"<?=$menucurrents['userlinksadd']?>>������������</a></li>
				<li><a href="<?=CPURL?>?action=manage&op=userlinks"<?=$menucurrents['userlinks']?>>������������</a></li>
			</ul>
		</div>
		<div>
			<ul>
				<li><a href="<?=CPURL?>?action=manage&op=attachments"<?=$menucurrents['attachments']?>>ʹ���еĸ�����Դ</a></li>
				<li><a href="<?=CPURL?>?action=manage&op=attachments&subop=del"<?=$menucurrents['attachmentsdel']?>>��ɾ���ĸ�����Դ</a></li>
			</ul>
		</div>
		<div>
			<ul>
				<li><a href="<?=CPURL?>?action=manage&op=update"<?=$menucurrents['update']?>>���¿ռ仺��</a></li>
			</ul>
		</div>
	</td>
	<td id="mainarea">

