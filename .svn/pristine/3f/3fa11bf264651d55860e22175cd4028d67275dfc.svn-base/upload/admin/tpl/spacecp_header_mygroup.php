<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	���˹���ҳ��ҳͷ

	$RCSfile: spacecp_header_mygroup.php,v $
	$Revision: 1.26 $
	$Date: 2007/07/10 12:52:25 $
*/

if(!defined('IN_SUPESITE_SPACECP')) {
	exit('Access Denied');
}

if(empty($_GET['op'])) $_GET['op'] = 'article';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=<?=$_SCONFIG['charset']?>" />
		<title>���˿ռ����</title>
		<link href="<?=IMG_DIR?>/style.css" rel="stylesheet" type="text/css" />
		<link href="<?=S_URL?>/images/edit/edit.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript">
			var siteUrl = "<?=S_URL?>";
		</script>
		<script language="javascript" type="text/javascript" src="<?=S_URL?>/images/edit/edit.js"></script>
		<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/ajax.js"></script>
		<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/common.js"></script>
		<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/menu.js"></script>
		<script language="javascript" type="text/javascript" src="<?=IMG_DIR?>/common.js"></script>
		<script type="text/javascript">
			var spTips = GetCookie('spTips');
			var tipText = '��ʾ��������ʾ��Ϣ';
			if (spTips!=1) {
				tipText = '���ذ�������ʾ��Ϣ';
			}
			function showHideTips() {
				var shTips = getbyid('shtips');
				spTips = GetCookie('spTips');
				if (spTips!=1) {
					shTips.innerHTML = '��ʾ��������ʾ��Ϣ'
					CreatCookie('spTips','1');
				} else {
					shTips.innerHTML = '���ذ�������ʾ��Ϣ';
					DelCookie('spTips','0')
					
				}
			}
		</script>
	</head>
	<body <?=($_GET['op'] == 'guide'?'':'onload="addMouseEvent();"')?>>
		<div class="wrap">
			<table id="header" summary="header" cellpadding="0" cellspacing="0" border="0" width="100%">
				<tr>
					<td>
						<div id="headertitle">
							<h1><a href="<?=S_URL?>/?<?=$_SGLOBAL['supe_uid']?>" title="�ص�<?=$space['spacename']?>��ҳ"><?=$space['spacename']?></a></h1>
							<p><?=$guide?></p>
						</div>
					</td>
					<td>
						<ul id="topmenu">
							<li>��ӭ����<a href="<?=CPURL?>?action=userspaces&op=photo"><?=stripslashes($_SGLOBAL['supe_username'])?></a> |</li>
							<li><a href="<?=S_URL?>/?<?=$_SGLOBAL['supe_uid']?>" target="_blank">�ҵĿռ���ҳ</a> |</li>
							<li><a href="<?=S_URL?>/" target="_blank">վ����ҳ</a> |</li>
							<li><a href="<?=B_URL?>/" target="_blank">������̳</a> |</li>
							<li><a href="<?=S_URL?>/batch.login.php?action=logout">�˳�</a></li>
						</ul>
						<ul id="actions">
							<li><a href="javascript:;" id="sidectrl" onclick="showContent('sidebar','sidectrl','�򿪲����','�رղ����');"><?=$sidetitle?></a></li>
							<li><a id="shtips" href="javascript:showHideTips();"><script type="text/javascript">document.write(tipText);</script></a></li>
						</ul>
					</td>
				</tr>
				<tr>
					<td colspan="2" id="menu">
						<ul>
							<?=$menustr?>
						</ul>
						<?=$popupmenustr?>
					</td>
				</tr>
			</table>
			
<?php
$menucurrents = array('article'=>'',
	'recommend'=>'',
	'bbs'=>'',
	'useraudit' => '',
	'invite'=>'',
	'invitelog'=>'',
	'edit'=>'',
	'notice'=>'',
	'style'=>'',
	'sharestyle' => '',
	'convey' => ''
);


$menucurrents[$_GET['op']] = ' class="current"';

if($_GET['op'] == 'managebbs') $menucurrents['bbs'] = ' class="current"';

?>

			<table summary="content" cellpadding="0" cellspacing="0" border="0" width="100%" align="center">
				<tr>
					<td id="sidebar" style="display:<?=$sidedisplay?>;">
						<div style="text-align: center; padding-top: 10px;">
							<img src="<?=$grouparr['logo']?>" width="100" height="100" class="avatar">
							<br><?=$grouparr['groupname']?>
							<p><a href="<?=S_URL?>/?action/mygroup/gid/<?=$gid?>" target="_blank">Ȧ����ҳ</a> | <a href="<?=S_URL?>/?action/mygroup/gid/<?=$gid?>/op/list/type/bbs" target="_blank">������</a>
							</p>
						</div>
						<div>	
							<ul>
								<li><a href="<?=CPURL?>?action=mygroups&op=article&gid=<?=$gid?>"<?=$menucurrents['article']?>>��Ϣ����</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=recommend&gid=<?=$gid?>"<?=$menucurrents['recommend']?>>Ȧ���Ƽ�����</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=bbs&gid=<?=$gid?>"<?=$menucurrents['bbs']?>>����������</a></li>
							</ul>
						</div>
						<div>
							<ul>
								<li><a href="<?=CPURL?>?action=mygroups&op=useraudit&gid=<?=$gid?>"<?=$menucurrents['useraudit']?>>��Ա����</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=invite&gid=<?=$gid?>"<?=$menucurrents['invite']?>>�����Ա</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=invitelog&gid=<?=$gid?>"<?=$menucurrents['invitelog']?>>�ѷ�����</a></li>
							</ul>
						</div>
						<? if($masters['flag'] == 3) {?>
						<div>
							<ul>
								<li><a href="<?=CPURL?>?action=mygroups&op=edit&gid=<?=$gid?>"<?=$menucurrents['edit']?>>Ȧ����������</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=notice&gid=<?=$gid?>"<?=$menucurrents['notice']?>>Ȧ�ӹ���</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=style&gid=<?=$gid?>"<?=$menucurrents['style']?>>Ȧ�ӷ��</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=sharestyle&gid=<?=$gid?>"<?=$menucurrents['sharestyle']?>>�������</a></li>
								<li><a href="<?=CPURL?>?action=mygroups&op=convey&gid=<?=$gid?>"<?=$menucurrents['convey']?>>ת��Ȧ��</a></li>
							</ul>	
						</div>
						<?}?>
					</td>
					<td id="mainarea">

