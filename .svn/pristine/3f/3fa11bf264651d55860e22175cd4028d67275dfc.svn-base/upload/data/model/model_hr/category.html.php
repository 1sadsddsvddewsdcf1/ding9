<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads = getad('system', $modelsinfoarr[modelname], '1')}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="models-content">
	<div class="models-main">
		<div class="models-nav">
			����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</div>
		<fieldset>
			<script type="text/javascript" src="{S_URL}/model/data/$modelsinfoarr[modelname]/images/validate.js"></script>
			<script type="text/javascript" src="{S_URL}/include/js/selectdate.js"></script>
			<legend>����</legend>
			<form method="get" name="modelsearch" id="modelsearch" action="{S_URL}/m.php">
			<ul class="models-fieldset">
			<!--{loop $searchtable $value}-->
				<li>$value</li>
			<!--{/loop}-->
			</ul>
			<p class="models-btnframe">
				<input name="name" type="hidden" id="name" value="$_GET[name]" />
				<input type="submit" value="����" class="btnsearch"> 
				<input type="reset" value="����" class="btnreset">
			</p>
			$linkagestr
			</form>
		</fieldset>
		<fieldset>
			<legend>$lang[system_catid]</legend>
			<ul class="models-fieldset">
				<!--{if !empty($categories)}-->
				<!--{loop $categories $key $value}-->
				<li><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_catid=$key" title="$value">$value</a></li>
				<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</fieldset>
		<!--{if !empty($ads['pagecenterad'])}-->
		<div class="admiddle">
			$ads[pagecenterad]
		</div>
		<!--{/if}-->
		<div class="models-articlelist">
			<!--{if !empty($listarr)}-->
			<!--{loop $listarr $key $value}-->
			<div class="models-article">
				<div class="models-articlelistinfo">
					<p class="title"><em class="date">#date("Y-m-d", $value[dateline])#</em><a href="$value[ss_url]" target="_blank">$value[subject]</a> <a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_corporation=<!--{eval echo rawurlencode($value[corporation]);}-->">$value[corporation]</a> </p>
					<!--{if !empty($columnsinfoarr)}-->
					<ul>
						<!--{if strlen($value[province])>0}-->
						<li><em>$columnsinfoarr[province][fieldcomment]:</em><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_province=<!--{eval echo rawurlencode($value[province]);}-->">$value[province]</a>
						<!--{/if}-->
						<!--{if strlen($value[city])>0}-->
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_city=<!--{eval echo rawurlencode($value[city]);}-->">$value[city]</a></li>
						<!--{/if}-->
						<!--{if strlen($value[seniority])>0}-->
						<li><em>$columnsinfoarr[seniority][fieldcomment]:</em><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_seniority=<!--{eval echo rawurlencode($value[seniority]);}-->">$value[seniority]</a></li>
						<!--{/if}-->
						<!--{if strlen($value[salary])>0}-->
						<li><em>$columnsinfoarr[salary][fieldcomment]:</em><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_salary=<!--{eval echo rawurlencode($value[salary]);}-->">$value[salary]</a></li>
						<!--{/if}-->
					</ul>
					<ul>
						<li><em>$lang[system_catid]:</em>
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_catid=$value[catid]">$categories[$value[catid]]</a></li>
						<!--{if strlen($value[education])>0}-->
						<li><em>$columnsinfoarr[education][fieldcomment]:</em>
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_education=<!--{eval echo rawurlencode($value[education]);}-->">$value[education]</a></li>
						<!--{/if}-->
						<!--{if strlen($value[corpsize])>0}-->
						<li><em>$columnsinfoarr[corpsize][fieldcomment]:</em>
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_corpsize=<!--{eval echo rawurlencode($value[corpsize]);}-->">$value[corpsize]</a></li>
						<!--{/if}-->
						<!--{if strlen($value[quantity])>0}-->
						<li><em>$columnsinfoarr[quantity][fieldcomment]:</em>
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_quantity=<!--{eval echo rawurlencode($value[quantity]);}-->">$value[quantity]</a></li>
						<!--{/if}-->
						<!--{if strlen($value[jobtype])>0}-->
						<li><em>$columnsinfoarr[jobtype][fieldcomment]:</em>
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_jobtype=<!--{eval echo rawurlencode($value[jobtype]);}-->">$value[jobtype]</a></li>
						<!--{/if}-->
						<!--{if strlen($value[language])>0}-->
						<li><em>$columnsinfoarr[language][fieldcomment]:</em>
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_language=<!--{eval echo rawurlencode($value[language]);}-->">$value[language]</a></li>
						<!--{/if}-->
					</ul>
					<!--{if !empty($value[introduce])}-->
                    <p class="maxcontent"><em>$columnsinfoarr[introduce][fieldcomment]:</em>
						<!--{loop $value[introduce] $dkey $dvalue}-->
							<!--{if $tmpvalue[formtype]=='textarea' }-->
							$dvalue 
							<!--{else}-->
							$dvalue
							<!--{/if}-->
						<!--{/loop}--></p>
					<!--{/if}-->
					<!--{/if}-->
				</div>
			</div>
			<!--{/loop}-->
			<!--{/if}-->
		</div>

		<!--{if $multipage}-->
		<div class="pages">
			<div class="models-page">
				$multipage
			</div>
		</div>
		<!--{/if}-->
	</div>
	<div class="models-side">
		<!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
		<div class="models-sideblock">
			<a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="��Ϣ����"><img src="$siteurl/$tpldir/images/models_btn_admin.jpg" title="��Ϣ����" /></a>
		</div>
		<!--{/if}-->
		<!--{if $modelsinfoarr[allowpost]}-->
		<div class="models-sideblock">
			<a href="$posturl" title="������Ϣ"><img src="$siteurl/$tpldir/images/models_btn_vote.jpg" alt="������Ϣ"/></a>
		</div>
		<!--{/if}-->
		<!-- �û���� -->
		<div class="models-sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		<!--{if !empty($gatherarr)}-->
		<!--{loop $gatherarr $key $value}-->
		<!--{if !empty($value)}-->
		<div class="models-sidetags">
			<h3>$cacheinfo[columns][$key][fieldcomment]</h3>
			<p>
				<!--{loop $value $tmpvalue}-->
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$key=<!--{eval echo rawurlencode($tmpvalue);}-->">$tmpvalue</a>
				<!--{/loop}-->
			</p>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
	</div>
</div>

<!--{if !empty($ads['pagefootad'])}-->
<div class="adfooter">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

<!--{eval include template($tpldir.'/footer.html.php', 1);}-->