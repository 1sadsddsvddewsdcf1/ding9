<?exit?>

<div id="models-footer">
	<p>
		<a href="{S_URL}/">$_SCONFIG[sitename]</a> | 
		<a href="{B_URL}/" target="_blank">������̳</a> | 
		<a href="{S_URL}/?action/site/type/panel">������</a> | 
		<a href="{S_URL}/?action/site/type/map">վ���ͼ</a> | 
		<a href="{S_URL}/?action/site/type/link">��������</a> | 
		<a href="{S_URL}/?action/spaces">�ռ��б�</a> | 
		<a href="{S_URL}/archiver/">վ��浵</a> | 
		<a href="mailto:$_SCONFIG[adminemail]">��ϵ����</a>
	</p>
	<p id="copyright">
		Powered by <a href="http://www.supesite.com" target="_blank"><strong>Supe<span>Site</span></strong></a> <em><?=S_VER?></em> 
		&copy; 2001-2008 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
		<br />{eval debuginfo();}
	</p>
</div>
</body>
</html>
