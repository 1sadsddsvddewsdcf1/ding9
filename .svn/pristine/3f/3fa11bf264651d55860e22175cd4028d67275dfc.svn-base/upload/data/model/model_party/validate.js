var imageext = new Array('jpg', 'jpeg', 'gif', 'png');
var flashext = new Array('swf');

function strLen(str) {
	var charset = document.charset; 
	var len = 0;
	for(var i = 0; i < str.length; i++) {
		len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
	}
	return len;
}

function fileext(filename) {
	if(filename == null || filename == '') {
		return '';
	}
	var ext = null;
	var num = filename.lastIndexOf(".");
	if(num != -1) {
		ext = filename.substring(num + 1);
	} else {
		ext = '';
	}
	return ext;
}

function isfileext(filename, extarr) {
	var ext = fileext(filename).toLowerCase();
	for(var i = 0; i < extarr.length; i++) {
		if(extarr[i] == ext){
			return true;
		}
	}
	return false;
}

function fill(setid, parentid, arr, value) {
	setid = document.getElementById(setid);
	if(setid != null) {
		setid.options[0]=new Option('��ѡ��','');
		opt = 0;
		if(parentid == '') {
			for(i=0;i<arr.length;i++) {
				setid.options[i+1]=new Option(arr[i][1],arr[i][0]);
				if(arr[i][1] == value) {
					opt = i+1;
				}
			}
			setid.options[opt].selected=true;
			setid.length=i+1;
		} else {
			parentcode = document.getElementById(parentid).value;
			count=1;
			if(parentcode != '') {
				for(i=0;i<arr.length;i++) {
					if(arr[i][0].toString().substring(0,parentcode.length)==parentcode.substring(0, parentcode.length)) {
						setid.options[count]=new Option(arr[i][1],arr[i][0]);
						if(value != null && arr[i][1] == value) {
							opt = count;
						}
						count=count+1;
					}
				}
			}
			setid.options[opt].selected=true;
			setid.length=count;
		}
	}
}

function validate(theform) {
	if(fieldinfo.length > 0) {
		for(i = 0; i < fieldinfo.length; i++) {
			obj = null;
			if(fieldinfo[i][2] == 'checkbox' && fieldinfo[i][4] == '1') {
				ischoose = false;
				var nodes = document.getElementsByTagName('input');
				if(nodes) {
					for(j = 0; j < nodes.length; j++) {
						var node = nodes[j];
						if (node.name == fieldinfo[i][0]+'[]') {
							if(obj == null) obj = node;
							if(node.checked == true) {
								ischoose = true;
								break;
							}
							
						}
					}
					if(!ischoose) {
						alert('����ѡ��һ��'+fieldinfo[i][1]);
						obj.focus();
						return false;
					}
				}
			} else {
				ischoose = true;
				obj = document.getElementById(fieldinfo[i][0]);
				if(fieldinfo[i][4] == '1' && obj && strLen(obj.value) < 1) {
					ischoose = false;
					if(fieldinfo[i][2] == 'text' || fieldinfo[i][2] == 'textarea') {
						alert('��������'+fieldinfo[i][1]);
					} else if(fieldinfo[i][2] == 'img' || fieldinfo[i][2] == 'flash' || fieldinfo[i][2] == 'file' || fieldinfo[i][2] == 'timestamp') {
						objvalue = document.getElementById(fieldinfo[i][0]+'_value');
						if(obj && strLen(objvalue.value) < 1) {
							alert('��δ����'+fieldinfo[i][1]+',����ȷ��');
						} else {
							ischoose = true;
						}
					} else {
						alert("����ѡ��һ��"+fieldinfo[i][1]);
					}
				}
				if(obj && obj.value != '') {
					if(fieldinfo[i][2] == 'text' || (fieldinfo[i][2] == 'textarea' && fieldinfo[i][3] != 0)) {
						if(fieldinfo[i][5] != 'TEXT' && fieldinfo[i][5] != 'MEDIUMTEXT' && fieldinfo[i][5] != 'LONGTEXT' && fieldinfo[i][5] != 'FLOAT' && fieldinfo[i][5] != 'DOUBLE') {
							if (strLen(obj.value) > fieldinfo[i][3]) {
								ischoose = false;
								alert('�������'+fieldinfo[i][1]+'���Ȳ�����Ҫ��,Ŀǰ����Ϊ'+strLen(obj.value)+'�ַ�,�뱣֤��'+fieldinfo[i][3]+'�ַ�����');
							}
						}
					} else if(fieldinfo[i][2] == 'img' || fieldinfo[i][2] == 'flash') {
						if (!isfileext(obj.value, (fieldinfo[i][2] == 'img' ? imageext : flashext))) {
							ischoose = false;
							alert('�������'+fieldinfo[i][1]+'��ʽ����ȷ,����ȷ��');
						}
					}
				}
				if(!ischoose) {
					obj.focus();
					return false;
				}
			}
		}
	}

	return true;
}

var fieldinfo = new Array(
new Array('subject', '�����', 'text', '80', '1', 'CHAR'),
new Array('catid', '�����', 'select', '6', '1', 'SMALLINT'),
new Array('subjectimage', '����ͼƬ', 'img', '80', '0', 'CHAR'),
new Array('organizer', '��֯��', 'textarea', '0', '1', 'TEXT'),
new Array('time', '��ϸʱ��', 'text', '40', '0', 'CHAR'),
new Array('site', '�ص�', 'text', '100', '1', 'CHAR'),
new Array('quantity', '����', 'text', '4', '1', 'SMALLINT'),
new Array('contact', '��ϵ��ʽ', 'textarea', '255', '0', 'VARCHAR'),
new Array('charge', '����', 'text', '100', '1', 'CHAR'),
new Array('content', '�����', 'textarea', '0', '1', 'TEXT'),
new Array('prompt', '��ʾ', 'textarea', '0', '0', 'TEXT')
);
