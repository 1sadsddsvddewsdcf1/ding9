<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads = getad('system', $modelsinfoarr[modelname], '1')}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div id="title">
	<em>
		����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		<!--{loop $guidearr $value}-->
		&gt;&gt; <a href="$value[url]">$value[name]</a>
		<!--{/loop}-->
	</em>
	<h2>$value[name]</h2>
</div>
<div id="main">
	<div id="loverlist">
		<!--{if !empty($ads['pagecenterad'])}-->
		<div class="admiddle">
			$ads[pagecenterad]
		</div>
		<!--{/if}-->

		<!--{if !empty($listarr)}-->
		<!--{loop $listarr $key $value}-->
		<div class="lover">
			<p class="loverthumb"><a href="$value[ss_url]" target="_blank" title="$value[subject]"><img src="$value[ss_imgurl]" alt="$value[subject]" /></a></p>
			<div class="loverinfo">
				<div class="author"><em>$columnsinfoarr[toprovince][fieldcomment]: <a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_toprovince=<!--{eval echo rawurlencode($value[toprovince]);}-->">$value[toprovince]</a><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_tocity=<!--{eval echo rawurlencode($value[tocity]);}-->">$value[tocity]</a>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_catid=$value[catid]">$categories[$value[catid]]</a>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_level=<!--{eval echo rawurlencode($value[level]);}-->">$value[level]</a></em>
				<h3><a href="$value[ss_url]" target="_blank">$value[subject]</a></h3></div>
				<!--{if !empty($columnsinfoarr)}-->
				<ul>
				<!--{loop $columnsinfoarr $tmpkey $tmpvalue}-->
					<!--{if !is_array($value[$tmpkey])}-->
					<!--{if strlen($value[$tmpkey]) > 0}-->
						<li>
						<!--{if $tmpvalue[formtype]!='timestamp' }-->
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$tmpkey=<!--{eval echo rawurlencode($value[$tmpkey]);}-->">$value[$tmpkey]</a>
						<!--{else}-->
						#date("m��d�� H:i", $value[$tmpkey])#
						<!--{/if}-->
						<!--{if $tmpkey=='age'}-->��<!--{elseif $tmpkey=='stature'}-->����<!--{/if}-->
						</li>
					<!--{/if}-->
					<!--{else}-->
						<li class="maxcontent">
						<!--{loop $value[$tmpkey] $dkey $dvalue}-->
							<!--{if $tmpvalue[formtype]=='textarea' }-->
							$dvalue 
							<!--{else}-->
							<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$tmpkey=<!--{eval echo rawurlencode($dvalue);}-->">$dvalue</a>
							<!--{/if}-->
						<!--{/loop}-->
						</li>
					<!--{/if}-->
				<!--{/loop}-->
				</ul>
				<!--{/if}-->
				<p class="more"><a href="$value[ss_url]" target="_blank" class="info">��ϸ����</a></p>
			</div>
		</div>
		<!--{/loop}-->
		<!--{else}-->
		<div class="errframe">
			<div class="error">��Ǹû���ҵ������Ϣ��</div>
		</div>
		<!--{/if}-->
		<!--{if $multipage}-->
		<div id="page">
			$multipage
		</div>
		<!--{/if}-->
	</div>
	<div id="listside">
		<div class="control">
			<!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
			<a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="��Ϣ����" class="admin">��Ϣ����</a>
			<!--{/if}-->
			<!--{if $modelsinfoarr[allowpost]}-->
			<a href="$posturl" title="��������" class="join">��������</a>
			<!--{/if}-->
		</div>
		<div id="sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		<div id="search">
			<h4>�߼�����</h4>
			<script type="text/javascript" src="{S_URL}/model/data/$modelsinfoarr[modelname]/images/validate.js"></script>
			<script type="text/javascript" src="{S_URL}/include/js/selectdate.js"></script>
			<form method="get" name="modelsearch" id="modelsearch" action="{S_URL}/m.php">
			<ul>
				<!--{loop $searchtable $value}-->
				<li>$value</li>
				<!--{/loop}-->
			</ul>
			$linkagestr
			<p>
				<input name="name" type="hidden" id="name" value="$_GET[name]" />
				<input type="submit" value="����" class="btnsearch"> 
				<input type="reset" value="����" class="btnreset">
			</p>
			</form>
		</div>
	</div>
</div>

<!--{if !empty($ads['pagefootad'])}-->
<div class="adfooter">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

<!--{eval include template($tpldir.'/footer.html.php', 1);}-->