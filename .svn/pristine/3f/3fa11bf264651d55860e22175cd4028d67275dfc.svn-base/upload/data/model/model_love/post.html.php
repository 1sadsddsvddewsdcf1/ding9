<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->

<link href="$siteurl/images/edit/edit.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="$siteurl/images/edit/edit.js"></script>
<script type="text/javascript" src="{S_URL}/model/data/$modelsinfoarr[modelname]/images/validate.js"></script>
<script type="text/javascript" src="{S_URL}/include/js/selectdate.js"></script>

<div id="title">
	<em>
		����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		<!--{loop $guidearr $value}-->
		&gt;&gt; <a href="$value[url]">$value[name]</a>
		<!--{/loop}-->
	</em>
	<h2>��������</h2>
</div>
<div id="main">
	<div id="post">
		$formstr
	</div>
	<div id="listside">
		<div id="sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
	</div>
</div>

<!--{eval include template($tpldir.'/footer.html.php', 1);}-->