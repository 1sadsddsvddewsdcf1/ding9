DROP TABLE IF EXISTS supe_loveitems;
CREATE TABLE supe_loveitems (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  catid smallint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  `subject` char(80) NOT NULL default '',
  subjectimage char(80) NOT NULL default '',
  rates smallint(6) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  viewnum mediumint(8) unsigned NOT NULL default '0',
  replynum mediumint(8) unsigned NOT NULL default '0',
  allowreply tinyint(1) NOT NULL default '0',
  grade tinyint(1) NOT NULL default '0',
  sex char(6) NOT NULL,
  age tinyint(3) NOT NULL,
  stature mediumint(3) NOT NULL,
  education char(12) NOT NULL,
  income char(20) NOT NULL,
  province char(9) NOT NULL,
  city char(30) NOT NULL,
  marriage char(6) NOT NULL,
  `level` char(20) NOT NULL,
  house char(20) NOT NULL,
  auto char(20) NOT NULL,
  localprovince char(9) NOT NULL,
  localcity char(30) NOT NULL,
  nation char(20) NOT NULL,
  belief char(30) NOT NULL,
  constellation char(9) NOT NULL,
  introduce char(255) NOT NULL,
  industry char(50) NOT NULL,
  toprovince char(9) NOT NULL,
  tocity char(30) NOT NULL,
  qq char(50) NOT NULL,
  msn char(50) NOT NULL,
  yahoo char(50) NOT NULL,
  wangwang char(50) NOT NULL,
  email char(50) NOT NULL,
  homepage char(100) NOT NULL,
  PRIMARY KEY  (itemid),
  KEY catid (catid,itemid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_lovemessage;
CREATE TABLE supe_lovemessage (
  nid mediumint(8) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  message mediumtext NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  children varchar(10) NOT NULL,
  interest mediumtext NOT NULL,
  note mediumtext NOT NULL,
  ta text NOT NULL,
  life mediumtext NOT NULL,
  PRIMARY KEY  (nid),
  KEY itemid (itemid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_lovecomments;
CREATE TABLE supe_lovecomments (
  cid int(10) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (cid),
  KEY itemid (itemid,dateline)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_loverates;
CREATE TABLE supe_loverates (
  rid int(10) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (rid),
  KEY itemid (itemid,dateline)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_lovecategories;
CREATE TABLE supe_lovecategories (
  catid smallint(6) unsigned NOT NULL auto_increment,
  upid smallint(6) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  note text NOT NULL,
  displayorder mediumint(6) unsigned NOT NULL default '0',
  url varchar(200) NOT NULL default '',
  subcatid varchar(200) NOT NULL default '',
  PRIMARY KEY  (catid),
  KEY upid (upid),
  KEY displayorder (displayorder)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_lovefolders;
CREATE TABLE supe_lovefolders (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  uid smallint(8) unsigned NOT NULL default '0',
  `subject` char(80) NOT NULL default '',
  message text NOT NULL,
  dateline int(10) unsigned NOT NULL default '0',
  folder tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (itemid),
  KEY folder (folder,dateline)
) TYPE=MyISAM;

