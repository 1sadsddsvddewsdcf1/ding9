<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads2 = getad('system',$modelsinfoarr[modelname], 2)}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<div id="title">
	<em>
		����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		<!--{loop $guidearr $value}-->
		&gt;&gt; <a href="$value[url]">$value[name]</a>
		<!--{/loop}-->
	</em>
	<h2>$value[name]</h2>
</div>
<div id="main">
	<div id="side">
		<div id="subject">
			<!--{if !empty($item[subjectimage])}-->
			<a href="$item[subjectimage]" target="_blank"><img src="$item[subjectimage]"></a>
			<!--{/if}-->
			<h3>$item[subject]</h3>
			<ul>
				<!--{if strlen($columnsallinfoarr[level][value])>0}-->
				<li class="level">$columnsallinfoarr[level][value]</li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[qq][value])>0}-->
				<li class="qq"><a href="http://wpa.qq.com/msgrd?V=1&Uin=$columnsallinfoarr[qq][value]&Site=<!--{eval echo rawurlencode($_SCONFIG[sitename]);}-->&Menu=yes" target="_blank">$columnsallinfoarr[qq][fieldcomment]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[msn][value])>0}-->
				<li class="msn"><a href="msnim:chat?contact=<!--{eval echo rawurlencode($columnsallinfoarr[msn][value]);}-->" target="_blank">$columnsallinfoarr[msn][fieldcomment]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[yahoo][value])>0}-->
				<li class="yahoo"><a href="http://edit.yahoo.com/config/send_webmesg?.target=<!--{eval echo rawurlencode($columnsallinfoarr[yahoo][value]);}-->&.src=pg" target="_blank">$columnsallinfoarr[yahoo][fieldcomment]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[wangwang][value])>0}-->
				<li class="taobao"><a href="http://amos1.taobao.com/msg.ww?v=2&uid=<!--{eval echo rawurlencode($columnsallinfoarr[wangwang][value]);}-->&s=2" target="_blank">$columnsallinfoarr[wangwang][fieldcomment]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[email][value])>0}-->
				<li class="email"><a href="mailto:<!--{eval echo rawurlencode($columnsallinfoarr[email][value]);}-->" target="_blank">$columnsallinfoarr[email][fieldcomment]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[homepage][value])>0}-->
				<li class="home"><a href="$columnsallinfoarr[homepage][value]" target="_blank">$columnsallinfoarr[homepage][fieldcomment]</a></li>
				<!--{/if}-->
				<li class="zan"><a href="javascript:;" onclick="setModelRate('$modelsinfoarr[modelname]', '$item[itemid]');">�� ( <span  id="modelrate">$item[rates]</span> )</a></li>
			</ul>
		</div>
		<div class="ta">
			<h3>$columnsallinfoarr[ta][fieldcomment]</h3>
			<p>$columnsallinfoarr[ta][value]</p>
		</div>
	</div>
	<div class="content">
		<!--{if !empty($ads2['pagecenterad'])}-->
		<div class="admiddle">
			$ads2[pagecenterad]
		</div>
		<!--{/if}-->
		<div class="authorinfo">
			<ul>
				<!--{if strlen($columnsallinfoarr[sex][value])>0}-->
				<li>{$columnsallinfoarr[sex][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_sex=<!--{eval echo rawurlencode($columnsallinfoarr[sex][value]);}-->">$columnsallinfoarr[sex][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[age][value])>0}-->
				<li>{$columnsallinfoarr[age][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_age=<!--{eval echo rawurlencode($columnsallinfoarr[age][value]);}-->">$columnsallinfoarr[age][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[stature][value])>0}-->
				<li>{$columnsallinfoarr[stature][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_stature=<!--{eval echo rawurlencode($columnsallinfoarr[stature][value]);}-->">$columnsallinfoarr[stature][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[education][value])>0}-->
				<li>{$columnsallinfoarr[education][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_education=<!--{eval echo rawurlencode($columnsallinfoarr[education][value]);}-->">$columnsallinfoarr[education][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[income][value])>0}-->
				<li>{$columnsallinfoarr[income][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_income=<!--{eval echo rawurlencode($columnsallinfoarr[income][value]);}-->">$columnsallinfoarr[income][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[toprovince][value])>0}-->
				<li>{$columnsallinfoarr[toprovince][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_toprovince=<!--{eval echo rawurlencode($columnsallinfoarr[toprovince][value]);}-->">$columnsallinfoarr[toprovince][value]</a><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_tocity=<!--{eval echo rawurlencode($columnsallinfoarr[tocity][value]);}-->">$columnsallinfoarr[tocity][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[province][value])>0}-->
				<li>{$columnsallinfoarr[province][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_province=<!--{eval echo rawurlencode($columnsallinfoarr[province][value]);}-->">$columnsallinfoarr[province][value]</a><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_city=<!--{eval echo rawurlencode($columnsallinfoarr[city][value]);}-->">$columnsallinfoarr[city][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[marriage][value])>0}-->
				<li>{$columnsallinfoarr[marriage][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_marriage=<!--{eval echo rawurlencode($columnsallinfoarr[marriage][value]);}-->">$columnsallinfoarr[marriage][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[children][value])>0}-->
				<li>{$columnsallinfoarr[children][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_children=<!--{eval echo rawurlencode($columnsallinfoarr[children][value]);}-->">$columnsallinfoarr[children][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[industry][value])>0}-->
				<li>{$columnsallinfoarr[industry][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_industry=<!--{eval echo rawurlencode($columnsallinfoarr[industry][value]);}-->">$columnsallinfoarr[industry][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[house][value])>0}-->
				<li>{$columnsallinfoarr[house][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_house=<!--{eval echo rawurlencode($columnsallinfoarr[house][value]);}-->">$columnsallinfoarr[house][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[auto][value])>0}-->
				<li>{$columnsallinfoarr[auto][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_auto=<!--{eval echo rawurlencode($columnsallinfoarr[auto][value]);}-->">$columnsallinfoarr[auto][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[localprovince][value])>0}-->
				<li>{$columnsallinfoarr[localprovince][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_localprovince=<!--{eval echo rawurlencode($columnsallinfoarr[localprovince][value]);}-->">$columnsallinfoarr[localprovince][value]</a><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_localcity=<!--{eval echo rawurlencode($columnsallinfoarr[localcity][value]);}-->">$columnsallinfoarr[localcity][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[nation][value])>0}-->
				<li>{$columnsallinfoarr[nation][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_nation=<!--{eval echo rawurlencode($columnsallinfoarr[nation][value]);}-->">$columnsallinfoarr[nation][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[belief][value])>0}-->
				<li>{$columnsallinfoarr[belief][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_belief=<!--{eval echo rawurlencode($columnsallinfoarr[belief][value]);}-->">$columnsallinfoarr[belief][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[constellation][value])>0}-->
				<li>{$columnsallinfoarr[constellation][fieldcomment]}��<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_constellation=<!--{eval echo rawurlencode($columnsallinfoarr[constellation][value]);}-->">$columnsallinfoarr[constellation][value]</a></li>
				<!--{/if}-->
			</ul>
		</div>

		<!--{if !empty($moreurl)}-->
		<dl class="models-maxfield">
			<dt><a href="$moreurl">�鿴����</a></dt>
		</dl>
		<!--{/if}-->

		<div id="particular" class="tabblock">
			<h3 id="particulartabs">
				<!--{if strlen($columnsallinfoarr[introduce][value])>0}-->
				<a id="introducetab" href="javascript:setTab('particular','introduce');" class="tab curtab">$columnsallinfoarr[introduce][fieldcomment]</a>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[note][value])>0}-->
				<a id="notetab" href="javascript:setTab('particular','note');" class="tab">$columnsallinfoarr[note][fieldcomment]</a>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[interest][value])>0}-->
				<a id="interesttab" href="javascript:setTab('particular','interest');" class="tab">$columnsallinfoarr[interest][fieldcomment]</a>
				<!--{/if}-->
				<!--{if strlen($item[message])>0}-->
				<a id="messagetab" href="javascript:setTab('particular','message');" class="tab">��������</a>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[life][value])>0}-->
				<a id="lifetab" href="javascript:setTab('particular','life');" class="tab">$columnsallinfoarr[life][fieldcomment]</a>
				<!--{/if}-->
			</h3>
			<!--{if strlen($columnsallinfoarr[introduce][value])>0}-->
			<div id="introduce" class="tabcontent">
				<p>$columnsallinfoarr[introduce][value]</p>
			</div>
			<!--{/if}-->
			<!--{if strlen($columnsallinfoarr[note][value])>0}-->
			<div id="note" class="tabcontent" style="display: none;">
				<p>$columnsallinfoarr[note][value]</p>
			</div>
			<!--{/if}-->
			<!--{if strlen($columnsallinfoarr[interest][value])>0}-->
			<div  id="interest" class="tabcontent" style="display: none;">
				<p>$columnsallinfoarr[interest][value]</p>
			</div>
			<!--{/if}-->
			<!--{if strlen($item[message])>0}-->
			<div id="message" class="tabcontent" style="display: none;">
				<p>$item[message]</p>
			</div>
			<!--{/if}-->
			<!--{if strlen($columnsallinfoarr[life][value])>0}-->
			<div id="life" class="tabcontent" style="display: none;">
				<p>$columnsallinfoarr[life][value]</p>
			</div>
			<!--{/if}-->
		</div>

		<!--{if !empty($modelsinfoarr[allowcomment]) && !empty($item[allowreply])}-->
			<!--{if !empty($commentlist)}-->
			<div id="commentlist">
				<h3>��������</h3>
				<!--{loop $commentlist $value}-->
				<dl>
					<dt>
						<em>
						<a href="#action/modelcomment/name/$modelsinfoarr[modelname]/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#">ɾ��</a> 
						<!--{if !empty($value['message'])}-->
						<a href="javascript:;" onclick="getModelQuote('$modelsinfoarr[modelname]', '$value[cid]')">����</a>
						<!--{/if}-->
						</em>
						<!--{if empty($value[authorid])}-->
						$value[author]
						<!--{else}-->
						<a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a>
						<!--{/if}-->
						&nbsp; ����ʱ�� #date("Y-n-d H:i:s", $value["dateline"])#
					</dt>
					<dd>
						<!--{if !empty($value['message'])}-->
						$value[message]
						<!--{/if}-->
					</dd>
				</dl>
				<!--{/loop}-->
				<p class="more"><a href="#action/modelcomment/name/$modelsinfoarr[modelname]/itemid/$item[itemid]#">�鿴ȫ�����ۡ���</a>(��$item[replynum]��)</p>
			</div>
			<!--{/if}-->
			<div id="comment">
				<h3>����˵����</h3>
				<form id="postcomm" action="#action/modelcomment/itemid/$item[itemid]/name/$modelsinfoarr[modelname]/php/1#" method="post">
				<p><label for="messagecomm">�� ��:</label><textarea id="messagecomm" name="messagecomm"></textarea></p>
				<!--{if empty($_SCONFIG['noseccode'])}-->
				<p><label for="seccode">�� ֤:</label><input type="text" id="seccode" name="seccode" class="submitcode" value="" size="5" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="�����壿�����һ��" /></p>
				<!--{/if}-->
				<p><button type="submit" id="submitcomm" name="submitcomm" value="submit" class="submitcomm">��������</button></p>
				<input type="hidden" id="itemid" name="itemid" value="$item[itemid]" />
				<input type="hidden" id="name" name="name" value="nxnaown" />
				</form>
			</div>	
		<!--{/if}-->
	</div>
</div>
<!--{if !empty($ads2['pagefootad'])}-->
<div class="adfooter">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads2['pageoutindex'])}-->
$ads2[pageoutindex]
<!--{/if}-->
<!--{eval include template($tpldir.'/footer.html.php', 1);}-->