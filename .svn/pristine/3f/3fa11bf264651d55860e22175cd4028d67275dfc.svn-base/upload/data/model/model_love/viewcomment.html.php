<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads2 = getad('system',$modelsinfoarr[modelname], 2)}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<div id="title">
	<em>
		����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		<!--{loop $guidearr $value}-->
		&gt;&gt; <a href="$value[url]">$value[name]</a>
		<!--{/loop}-->
	</em>
	<h2>��������</h2>
</div>
<div id="main">
	<div id="side">
		<div id="subject">
			<!--{if !empty($item[subjectimage])}-->
			<a href="$item[subjectimage]" target="_blank"><img src="$item[subjectimage]"></a>
			<!--{/if}-->
			<h3>$item[subject]</h3>
			<ul>
				<li class="zan"><a href="javascript:;" onclick="setModelRate('$modelsinfoarr[modelname]', '$item[itemid]');">�� ( <span  id="modelrate">$item[rates]</span> )</a></li>
			</ul>
		</div>
	</div>
	<div class="content">
			<!--{if !empty($modelsinfoarr['allowcomment'])}-->

			<!--{if !empty($iarr)}-->
			<div id="commentlist">
				<h3>��������</h3>
				<dl>
				<!--{loop $iarr $value}-->
					<dt>
						<em>
						<a href="#action/modelcomment/name/$modelsinfoarr[modelname]/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#">ɾ��</a> 
						<!--{if !empty($value['message'])}-->
						<a href="javascript:;" onclick="getModelQuote('$modelsinfoarr[modelname]', '$value[cid]')">����</a>
						<!--{/if}-->
						</em>
						<!--{if empty($value[authorid])}-->
						$value[author]
						<!--{else}-->
						<a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a>
						<!--{/if}-->
						&nbsp; ����ʱ�� #date("Y-n-d H:i:s", $value["dateline"])#
					</dt>
					<dd>
						<!--{if !empty($value['message'])}-->
						$value[message]
						<!--{/if}-->
					</dd>
					<!--{/loop}-->
				</dl>
			</div>
			<div class="pages">
				<div class="models-page">
					$multipage
				</div>
			</div>
			<!--{/if}-->

			<div id="comment">
				<h3>����˵����</h3>
				<form id="postcomm" action="#action/modelcomment/itemid/$item[itemid]/name/$modelsinfoarr[modelname]/php/1#" method="post">
				<p><label for="messagecomm">�� ��:</label><textarea id="messagecomm" name="messagecomm"  cols="100%" rows="5"></textarea></p>
				<!--{if empty($_SCONFIG['noseccode'])}-->
				<p><label for="seccode">�� ֤:</label><input type="text" id="seccode" name="seccode" class="submitcode" value="" size="5" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="�����壿�����һ��" /></p>
				<!--{/if}-->
				<p><button type="submit" id="submitcomm" name="submitcomm" value="submit" class="submitcomm">��������</button></p>
				<input type="hidden" id="itemid" name="itemid" value="$item[itemid]" />
				<input type="hidden" id="name" name="name" value="nxnaown" />
				</form>
			</div>	
		<!--{/if}-->
	</div>
</div>
<!--{if !empty($ads2['pagefootad'])}-->
<div class="adfooter">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads2['pageoutindex'])}-->
$ads2[pageoutindex]
<!--{/if}-->
<!--{eval include template($tpldir.'/footer.html.php', 1);}-->