<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->

<link href="$siteurl/images/edit/edit.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="$siteurl/images/edit/edit.js"></script>
<script type="text/javascript" src="{S_URL}/model/data/$modelsinfoarr[modelname]/images/validate.js"></script>
<script type="text/javascript" src="{S_URL}/include/js/selectdate.js"></script>

<div class="models-content">
	<div class="models-main">
		<div class="models-nav">
			����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
			&gt;&gt; <a href="#">����Ͷ��</a>
		</div>
		<div class="models-post">
		$formstr
		</div>
	</div>

	<div class="models-side">
		<!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
		<div class="models-sideblock">
			<a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="��Ϣ����"><img src="$siteurl/$tpldir/images/models_btn_admin.jpg" title="��Ϣ����" /></a>
		</div>
		<!--{/if}-->
		<!--{if $modelsinfoarr[allowpost]}-->
		<div class="models-sideblock">
			<a href="$posturl" title="����Ͷ��"><img src="$siteurl/$tpldir/images/models_btn_vote.jpg" alt="����Ͷ��"/></a>
		</div>
		<!--{/if}-->
		<!-- �û���� -->
		<div class="models-sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		<!--{if !empty($gatherarr)}-->
		<!--{loop $gatherarr $key $value}-->
		<!--{if !empty($value)}-->
		<div class="models-sidetags">
			<h3>$cacheinfo[columns][$key][fieldcomment]</h3>
			<p>
				<!--{loop $value $tmpvalue}-->
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$key=<!--{eval echo rawurlencode($tmpvalue);}-->">$tmpvalue</a>
				<!--{/loop}-->
			</p>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
	</div>

<!--{eval include template($tpldir.'/footer.html.php', 1);}-->