<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads2 = getad('system',$modelsinfoarr[modelname], 2)}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<div class="models-content">
	<div class="models-main">
		<div class="models-nav">
			����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</div>
		<div class="models-articletitle">
			<h1>$item[subject]</h1>
			<p>�����ߣ�<a href="#uid/$item[uid]#" target="_blank">$item[username]</a>&nbsp;&nbsp;���������$item[viewnum]&nbsp;&nbsp;����ʱ�䣺#date('Y-n-d H:i', $item["dateline"])#</p>
		</div>
		<div class="models-articlecontent">
			<!--{if !empty($item[subjectimage])}-->
			<a href="$item[subjectimage]" target="_blank"><img src="$item[subjectimage]"></a>
			<!--{/if}-->
			<p>$item[message]</p>
		</div>
		<!--{if !empty($ads2['pagecenterad'])}-->
		<div class="admiddle">
			$ads2[pagecenterad]
		</div>
		<!--{/if}-->
		<!--{if !empty($modelsinfoarr[allowrate])}-->
		<div class="models-articlesupport">
			<ul>
				<li>
					<em id="modelrate">$item[rates]</em>
					<a href="javascript:;" onclick="setModelRate('$modelsinfoarr[modelname]', '$item[itemid]');">��һ��</a>
				</li>
				<li>
					<em class="back">����</em>
					<a href="{S_URL}/m.php?name=$modelsinfoarr[modelname]">����</a>
				</li>
			</ul>
		</div>
		<!--{/if}-->
		<!--{if !empty($columnsinfoarr[fixed])}-->
		<div class="models-minfield">
			<ul>
				<!--{loop $columnsinfoarr[fixed] $ckey $cvalue}-->
				<!--{if !is_array($cvalue[value])}-->
					<li><strong>$cvalue[fieldcomment]: </strong>
					<!--{if $cvalue[formtype]=='textarea' }-->
					$cvalue[value]
					<!--{elseif $cvalue[formtype]=='timestamp'}-->
					#date("m��d�� H:i", $cvalue[value])#
					<!--{else}-->
					<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$ckey=<!--{eval echo rawurlencode($cvalue[value]);}-->">$cvalue[value]</a>
					<!--{/if}-->
					</li>
				<!--{else}-->
					<li><strong>$cvalue[fieldcomment]: </strong>
					<!--{loop $cvalue[value] $dkey $dvalue}-->
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$ckey=<!--{eval echo rawurlencode($dvalue);}-->">$dvalue</a>&nbsp;
					<!--{/loop}-->
					</li>
				<!--{/if}-->
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--{if !empty($moreurl)}-->
		<dl class="models-maxfield">
			<dt><a href="$moreurl">�鿴����</a></dt>
		</dl>
		<!--{/if}-->
		<!--{if !empty($columnsinfoarr[message])}-->
		<!--{loop $columnsinfoarr[message] $ckey $cvalue}-->
		<!--{if !empty($cvalue[isflash])}-->
			<div class="models-media">
				<h3 class="flash">$cvalue[fieldcomment]��</h3>
				<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="400" height="300">
				<param name="movie" value="$cvalue[filepath]" />
				<param name="quality" value="high" />
				<embed src="$cvalue[filepath]" type="application/x-shockwave-flash" pluginspage=" http://www.macromedia.com/go/getflashplayer" width="400" height="300"/>
				</object>
			</div>
		<!--{elseif !empty($cvalue[isfile])}-->
			<div class="models-media">
				<h3 class="file">$cvalue[fieldcomment]��</h3>
				<a href="$siteurl/batch.modeldownload.php?hash=$cvalue[filepath]">����</a>
			</div>
		<!--{elseif !empty($cvalue[isimage])}-->
			<div class="models-media">
				<h3 class="pic">$cvalue[fieldcomment]��</h3>
				<a href="$cvalue[filepath]" target="_blank"><img src="$cvalue[filepath]"></a>
			</div>
		<!--{else}-->
			<dl class="models-maxfield">
				<dt>$cvalue[fieldcomment]��</dt>
				<dd>
					<!--{if !is_array($cvalue[value])}-->
						$cvalue[value]
					<!--{else}-->
						<!--{loop $cvalue[value] $dkey $dvalue}-->
							$dvalue&nbsp;
						<!--{/loop}-->
					<!--{/if}-->
				</dd>
			</dl>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->

		<!--{if !empty($modelsinfoarr[allowcomment]) && !empty($item[allowreply])}-->
			<!--{if !empty($commentlist)}-->
			<dl class="models-commentlist">
				<h3>��������</h3>
				<!--{loop $commentlist $value}-->
				<dt>
					<span style="float: right;">
					<a href="#action/modelcomment/name/$modelsinfoarr[modelname]/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#">ɾ��</a> 
					<!--{if !empty($value['message'])}-->
					<a href="javascript:;" onclick="getModelQuote('$modelsinfoarr[modelname]', '$value[cid]')">����</a>
					<!--{/if}-->
					</span>
					<!--{if empty($value[authorid])}-->
					$value[author]
					<!--{else}-->
					<a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a>
					<!--{/if}-->
					&nbsp; ����ʱ�� #date("Y-n-d H:i:s", $value["dateline"])#
				</dt>
				<dd>
					<!--{if !empty($value['message'])}-->
					$value[message]
					<!--{/if}-->
				</dd>
				<!--{/loop}-->
			</dl>
			<p class="more"><a href="#action/modelcomment/name/$modelsinfoarr[modelname]/itemid/$item[itemid]#">�鿴ȫ�����ۡ���</a>(��$item[replynum]��)</p>
			<!--{/if}-->

			<div class="models-commentwrite">
				<h3>����˵����</h3>
				<form id="postcomm" action="#action/modelcomment/itemid/$item[itemid]/name/$modelsinfoarr[modelname]/php/1#" method="post">
					<p><label for="messagecomm">�� �ݣ�</label><textarea id="messagecomm" name="messagecomm"  cols="100%" rows="5"></textarea></p>
					<!--{if empty($_SCONFIG['noseccode'])}-->
					<p><label for="seccode">�� ֤��</label><input type="text" id="seccode" name="seccode" class="submitcode" value="" size="5" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="�����壿�����һ��" /></p>
					<!--{/if}-->
					<p><button type="submit" id="submitcomm" name="submitcomm" value="submit" class="submitcomm">��������</button>
					<input type="hidden" id="itemid" name="itemid" value="$item[itemid]" />
					<input type="hidden" id="name" name="name" value="nxnaown" /></p>
				</form>
			</div>
		<!--{/if}-->
	</div>
	<div class="models-side">
		<!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
		<div class="models-sideblock">
			<a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="��Ϣ����"><img src="$siteurl/$tpldir/images/models_btn_admin.jpg" title="��Ϣ����" /></a>
		</div>
		<!--{/if}-->
		<!--{if $modelsinfoarr[allowpost]}-->
		<div class="models-sideblock">
			<a href="$posturl" title="����Ͷ��"><img src="$siteurl/$tpldir/images/models_btn_vote.jpg" alt="����Ͷ��"/></a>
		</div>
		<!--{/if}-->
		<!-- �û���� -->
		<div class="models-sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		<!--{if !empty($gatherarr)}-->
		<!--{loop $gatherarr $key $value}-->
		<!--{if !empty($value)}-->
		<div class="models-sidetags">
			<h3>$cacheinfo[columns][$key][fieldcomment]</h3>
			<p>
				<!--{loop $value $tmpvalue}-->
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$key=<!--{eval echo rawurlencode($tmpvalue);}-->">$tmpvalue</a>
				<!--{/loop}-->
			</p>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
	</div>
</div>
<!--{if !empty($ads2['pagefootad'])}-->
<div class="adfooter">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads2['pageoutindex'])}-->
$ads2[pageoutindex]
<!--{/if}-->
<!--{eval include template($tpldir.'/footer.html.php', 1);}-->