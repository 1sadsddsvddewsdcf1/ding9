<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��̳����б�ҳ��

	$RCSfile: forumdisplay.php,v $
	$Revision: 1.28 $
	$Date: 2007/06/27 17:15:08 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

$fid = intval($_SGET['fid']);
$_SGET['page'] = empty($_SGET['page'])?1:intval($_SGET['page']);

if(!empty($_SCONFIG['htmlcategory'])) {
	$_SHTML['action'] = 'forumdisplay';
	$_SHTML['fid'] = $fid;
	if(!empty($_SGET['page'])) $_SHTML['page'] = intval($_SGET['page']);
	$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
	ehtml('get', $_SCONFIG['htmlcategorytime']);
	$_SCONFIG['debug'] = 0;
}

$forum = array();
if($fid) {
	dbconnect(1);
	$query = $_SGLOBAL['db_bbs']->query("SELECT f.*, ff.* FROM ".tname('forums', 1)." f LEFT JOIN ".tname('forumfields', 1)." ff ON ff.fid=f.fid WHERE f.fid='$fid'");
	$forum = $_SGLOBAL['db_bbs']->fetch_array($query);
}
if(empty($forum)) messagebox('error', 'not_found', S_URL);

$forumurl = B_URL.'/forumdisplay.php?fid='.$fid;
$jumptobbs = false;
if($forum['status'] == 0) {
	$jumptobbs = true;
} elseif(!empty($forum['password'])) {
	$jumptobbs = true;
} elseif(!empty($forum['viewperm'])) {
	$viewpermarr = explode("\t", $forum['viewperm']);
	if(!in_array('7', $viewpermarr)) {
		$jumptobbs = true;
	}
} elseif(!empty($forum['redirect'])) {
	$forumurl = $forum['redirect'];
	$jumptobbs = true;
}
if(B_VER == '5') {
	if(empty($forum['allowshare'])) $jumptobbs = true;
} elseif (B_VER == '4') {
	if(empty($forum['allowblog'])) $jumptobbs = true;
}
if($jumptobbs) {
	sheader($forumurl);
}

include_once(S_ROOT.'./include/common.inc.php');

@include_once(S_ROOT.'./data/system/bbsforums.cache.php');
if(!empty($_SGLOBAL['bbsforumarr']) && !empty($_SGLOBAL['bbsforumarr'][$forum['fid']]['name'])) {
	$forum['name'] = $_SGLOBAL['bbsforumarr'][$forum['fid']]['name'];
}

$title = $forum['name'].' - '.$_SCONFIG['sitename'];
$keywords = $forum['name'].','.$lang['bbs'];
$description = $forum['name'].','.$lang['bbs'];

$guidearr = array();
$guidearr[] = array('url' => geturl('action/bbs'),'name' => $channels['menus']['bbs']['name']);
$guidearr[] = array('url' => geturl('action/forumdisplay/fid/'.$forum['fid']),'name' => $forum['name']);

$tplname = 'bbs_forumdisplay';

$title = strip_tags($title);
$keywords = strip_tags($keywords);
$description = strip_tags($description);

include template($tplname);

ob_out();

if(!empty($_SCONFIG['htmlcategory'])) {
	ehtml('make');
} else {
	maketplblockvalue('cache');
}

?>