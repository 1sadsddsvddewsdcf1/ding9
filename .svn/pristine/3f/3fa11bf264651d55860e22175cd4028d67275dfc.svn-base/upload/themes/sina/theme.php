<?php

$themes = array(
	'name'		=> '���Ŵ�',
	'preview'	=> 'preview.jpg',
	'css'		=> 'style.css',
	'thumb'		=> 'thumb_preview.jpg'
);

?>