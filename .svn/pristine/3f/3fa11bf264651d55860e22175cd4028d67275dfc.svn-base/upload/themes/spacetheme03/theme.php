<?php

$themes = array(
	'name'		=> '��Ұ����',
	'preview'	=> 'preview.jpg',
	'css'		=> 'style.css',
	'thumb'		=> 'thumb_preview.jpg'
);

?>