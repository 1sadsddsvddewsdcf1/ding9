<?php

$themes = array(
	'name'		=> '�ڰ���ӳ',
	'preview'	=> 'preview.jpg',
	'css'		=> 'style.css',
	'thumb'		=> 'thumb_preview.jpg'
);

?>