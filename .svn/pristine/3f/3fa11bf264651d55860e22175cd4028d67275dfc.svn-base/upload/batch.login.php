<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	�û���¼/�˳�����

	$RCSfile: batch.login.php,v $
	$Revision: 1.40 $
	$Date: 2007/03/29 23:43:51 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

$action = empty($_GET['action'])?'':$_GET['action'];
if(empty($action)) exit('Access Denied');

if(postget('refer')) {
	$refer = postget('refer');
} else {
	if(!empty($_SERVER['HTTP_REFERER'])) {
		$refer = $_SERVER['HTTP_REFERER'];
	} else {
		$refer = geturl('action/site/type/panel');
	}
}
if(!empty($_SCONFIG['ucmode'])) {
	include_once(S_ROOT.'./uc_client/client.php');
}
switch ($action) {
	case 'login':
		include_once(S_ROOT.'./include/common.inc.php');
		$cookietime = 0;

		if(!empty($_POST['cookietime'])) $cookietime = intval($_POST['cookietime']);
		if (submitcheck('loginsubmit')) {
			$password = $_POST['password'];
			$username = $_POST['username'];

			dbconnect(1);
			if(empty($_SCONFIG['ucmode'])) {
				$password = md5($password);
				$query = $_SGLOBAL['db_bbs']->query('SELECT * FROM '.tname('members', 1).' WHERE username=\''.$username.'\' AND password=\''.$password.'\'');
			} else {
				$ucresult = uc_user_login($username, $password, $loginfield == 'uid');
				list($members['uid'], $members['username'], $members['password'], $members['email']) = saddslashes($ucresult);
				if($members['uid'] > 0) {
					$query = $_SGLOBAL['db_bbs']->query('SELECT * FROM '.tname('members', 1).' WHERE uid=\''.$members['uid'].'\'');
				} else {
					messagebox('error', 'login_error', geturl('action/login'));
				}
			}

			if($member = $_SGLOBAL['db_bbs']->fetch_array($query)) {
				if(empty($_SCONFIG['noseccode']) || empty($_SCONFIG['ucmode']) && $member['secques']) {
					$title = $blang['safety_questions'];
					$guidearr = array();
					include template('site_secques');
					exit;
				} else {
					$msg = 'login_succeed';
					if(!empty($_SCONFIG['ucmode'])) {
						$msg = $lang['login_succeed'].uc_user_synlogin($member['uid']);
					}
					dologin($member, $cookietime, $msg);
					exit;
				}
			} else {
				messagebox('error', 'login_error', geturl('action/login'));
			}
		} elseif(submitcheck('loginsubmit_secques')) {
			if(!submitcheck('loginsubmit_secques', 1)) {
				messagebox('error', 'seccode_error', geturl('action/login'));
			}
			$password = $_POST['password'];
			$uid = intval($_POST['uid']);
			dbconnect(1);
			$secstr = '';
			if(empty($_SCONFIG['ucmode'])) {
				$secques = quescrypt($_POST['questionid'], $_POST['answer']);
				$secstr = " AND secques='$secques'";
			}
			$query = $_SGLOBAL['db_bbs']->query('SELECT * FROM '.tname('members', 1)." WHERE uid='$uid' AND password='$password' $secstr ");
			if($member = $_SGLOBAL['db_bbs']->fetch_array($query)) {
				if(empty($_SCONFIG['ucmode'])) {
					dologin($member, $cookietime);
				} else {
					$msg = $lang['login_succeed'].uc_user_synlogin($member['uid']);
					dologin($member, $cookietime, $msg);
				}
				exit;
			} else {
				messagebox('error', 'login_error', geturl('action/login'));
			}

		}
		break;
	case 'logout':
		obclean();
		sclearcookie();
		setcookie('_refer', '');
		$msg = 'logout_succeed';
		if(!empty($_SCONFIG['ucmode'])) {
			$msg = $lang['logout_succeed'].uc_user_synlogout();
		}
		messagebox('ok', $msg, rawurldecode($refer));
		break;
	default:
		break;
}

setcookie('_refer', '');
messagebox('ok', 'login_succeed', rawurldecode($refer));

function dologin($member, $cookietime, $msg = 'login_succeed') {
	global $_SGLOBAL, $refer, $lang;

	$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('userspaces').' WHERE uid=\''.$member['uid'].'\'');
	$havespace = $_SGLOBAL['db']->result($query, 0);

	$insertsqlarr = array(
		'uid' => $member['uid'],
		'groupid' => $member['groupid'],
		'username' => addslashes($member['username']),
		'password' => addslashes($member['password']),
		'secques' => addslashes($member['secques']),
		'timeoffset' => addslashes($member['timeoffset']),
		'dateformat' => addslashes($member['dateformat']),
		'havespace' => $havespace,
		'newpm' => $member['newpm']
	);
	replacetable('members', $insertsqlarr);

	$uid = $member['uid'];
	$password = $member['password'];
	$secques = $member['secques'];
	
	//������̳member��
	dbconnect(1);
	$_SGLOBAL['db_bbs']->query("UPDATE ".tname('members', 1)." SET lastip='$_SGLOBAL[onlineip]', lastvisit='$_SGLOBAL[timestamp]', xspacestatus='$havespace' WHERE uid='$uid'");

	$cookievalue = authcode("$password\t$secques\t$uid", 'ENCODE');
	
	ssetcookie('sid', '', $cookietime);
	ssetcookie('auth', $cookievalue, $cookietime);
	setcookie('_refer', '');
	messagebox('ok', $msg, rawurldecode($refer));
}

function quescrypt($questionid, $answer) {
	return $questionid > 0 && $answer != '' ? substr(md5($answer.md5($questionid)), 16, 8) : '';
}

?>