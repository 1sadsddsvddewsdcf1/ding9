<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	ģ��Ͷ��ҳ��

	$RCSfile: modelpost.php,v $
	$Revision: $
	$Date: $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

include_once(S_ROOT.'./include/common.inc.php');
include_once(S_ROOT.'./function/model.func.php');
include_once(S_ROOT.'./function/html.func.php');
include_once(S_ROOT.'./function/spacecp.func.php');
include_once(S_ROOT.'./function/model.func.php');

$modelname = empty($_SGET['name']) ? trim(postget('name')) : trim($_SGET['name']);
$modelsinfoarr = $columnsinfoarr = array();
$cacheinfo = getmodelinfoall('modelname', $modelname);
if(empty($cacheinfo['models'])) {
	messagebox('error', 'visit_the_channel_does_not_exist', S_URL);
}
$modelsinfoarr = $cacheinfo['models'];
$columnsinfoarr = $cacheinfo['columns'];

getcookie(0);

if(empty($modelsinfoarr['allowpost'])) {
	messagebox('error', 'this_channel_does_not_allow_contributions');
} else {
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) {
		if(empty($modelsinfoarr['allowguest'])) {
			setcookie('_refer', rawurlencode(geturl('action/modelpost/name/'.$modelname, 1)));
			messagebox('error', 'no_login', geturl('action/login'));
		}
	}
}

//�ύ����
if(submitcheck('valuesubmit', 1)) {
	modelpost($cacheinfo);
}

//����
$channelsmore = array();
if(!empty($channels['menus']) && count($channels['menus']) > 12) {
	$channelsmore = $channels['menus'];
	for($i = 0; $i < 12; $i++) {
		array_shift($channelsmore);
	}
}

//Ͷ������
$posturl = geturl('action/modelpost/name/'.$modelsinfoarr['modelname']);

//����
$guidearr = array();
$guidearr[] = array('url' => empty($channels['menus'][$modelsinfoarr['modelname']]) ? S_URL.'/m.php?name='.$modelsinfoarr['modelname'] : $channels['menus'][$modelsinfoarr['modelname']]['url'],'name' => $modelsinfoarr['modelalias']);

//�Զ������
if(!empty($cacheinfo['columns'])) {
	foreach($cacheinfo['columns'] as $tmpvalue) {
		if(!empty($tmpvalue['fielddata'])) {
			$temparr = explode("\r\n", $tmpvalue['fielddata']);
			if($tmpvalue['formtype'] != 'linkage') {
				$gatherarr[$tmpvalue['fieldname']] = $temparr;
			}
		}
	}
}

//CATEGORIES
$clistarr = getmodelcategory($modelsinfoarr['modelname']);
$categorylistarr = array(''=>array('pre'=>'', 'name'=>'------'));
foreach ($clistarr as $key => $value) {
	$categorylistarr[$key] = $value;
}

$thevalue = array();
foreach ($columnsinfoarr as $value) {
	if(!preg_match("/^(TEXT|MEDIUMTEXT|LONGTEXT)$/i", $_POST['fieldtype'])) {
		$thevalue[$value['fieldname']] = $value['formtype'] != 'timestamp' ? $value['fielddefault'] : $_SGLOBAL['timestamp'];
	} else {
		$thevalue[$value['fieldname']] = '';
	}
}
	
$formstr = $linkagestr = '';
//ҳ����ʾ
if(!empty($cacheinfo['fielddefault']['subject'])) $lang['subject'] = $cacheinfo['fielddefault']['subject'];
if(!empty($cacheinfo['fielddefault']['subjectimage'])) $lang['photo_title'] = $cacheinfo['fielddefault']['subjectimage'];
if(!empty($cacheinfo['fielddefault']['catid'])) $lang['system_catid'] = $cacheinfo['fielddefault']['catid'];
if(!empty($cacheinfo['fielddefault']['message'])) $lang['content'] = $cacheinfo['fielddefault']['message'];
$formstr .= label(array('type'=>'form-start', 'name'=>'thevalueform', 'action'=>S_URL.'/index.php?action-modelpost-name-'.$modelsinfoarr['modelname'], 'other'=>' onSubmit="return validate(this)"'));
$formstr .= label(array('type'=>'div-start'));
$formstr .= label(array('type'=>'title', 'alang'=>$lang['model_post_base']));
$formstr .= label(array('type'=>'table-start'));
$formstr .= label(array('type'=>'input', 'alang'=>$lang['subject'].'<span style="color: #F00">*</span>', 'name'=>'subject', 'width'=>'30%', 'size'=>'52', 'value'=>''));
$formstr .= label(array('type'=>'file', 'alang'=>$lang['photo_title'], 'name'=>'subjectimage', 'width'=>'30%', 'size'=>'52', 'value'=>''));
$formstr .= label(array('type'=>'select-div', 'alang'=>$lang['system_catid'].$lang['system_catid_notes'], 'name'=>'catid', 'radio'=>1, 'options'=>$categorylistarr, 'width'=>'30%', 'value'=>''));
$formstr .= '<tr id="tr_message">'.
			'<th>'.$lang['content'].'</th>'.
			'<td><table style="width: 100%"><tr><td>';
$formstr .= label(array('type'=>'edit', 'alang'=>$lang['content'], 'name'=>'message', 'value'=>'', 'op'=>0));
$formstr .= '</td></tr></table></td></tr>';
	foreach ($columnsinfoarr as $value) {
		if(!empty($value['allowpost'])) {
			$temparr = $temparr2 = array();
			$other = '';
			if($value['formtype'] == 'select') {
				$temparr2 = array(''=>'');
			}

			//������ʾ��Ϣ
			if(!empty($value['isrequired'])) {
				$value['fieldcomment'] .= '<span style="color: #F00">*</span>';
			}
			$value['fieldcomment'] .= '<p>';
			if(!empty($value['ishtml'])) {
				$value['fieldcomment'] .= $lang['support_html_code'];
			}
			if(!empty($value['isbbcode'])) {
				$value['fieldcomment'] .= $lang['support_discuz_code'];
			}
			if(preg_match("/^(TINYINT|SMALLINT|MEDIUMINT|INT|BIGINT)$/i", $value['fieldtype']) && !preg_match("/^(select|radio|checkbox|linkage|timestamp|file|img|flash)$/i", $value['formtype'])) {
				$value['fieldcomment'] .= $lang['numerical_only_field_support'];
			}
			if(preg_match("/^(FLOAT|DOUBLE)$/i", $value['fieldtype']) && !preg_match("/^(select|radio|checkbox|file|img|flash)$/i", $value['formtype'])) {
				$value['fieldcomment'] .= $lang['numerical_only_float'];
			}
			if(preg_match("/^(text|password|textarea)$/i", $value['formtype']) && !preg_match("/^(TEXT|MEDIUMTEXT|LONGTEXT|FLOAT|DOUBLE)$/i", $value['fieldtype'])) {
				$value['fieldcomment'] .= $lang['length_of_0'].$value['fieldlength'].$lang['length_of_1'];
			}
			$value['fieldcomment'] .= '</p>';
			
			
			$temparr = explode("\r\n", $value['fielddata']);
			foreach($temparr as $value2) {
				$temparr2[$value2] = $value2;
			}
			if($value['formtype'] == 'linkage') {
				$temparr2 = array();
				if(!empty($cacheinfo['linkage']['down'][$value['id']])) {
					$downfieldname = $cacheinfo['columnids'][$cacheinfo['linkage']['down'][$value['id']]];
					$other = ' onchange="fill(\''.$downfieldname.'\', \''.$value['fieldname'].'\', '.$downfieldname.'arr);"';
				}
				if($value['upid'] == '0') {
					$linkagestr .= 'fill(\''.$value['fieldname'].'\', \'\', '.$value['fieldname'].'arr, \'\');';
				} else {
					$linkagestr .= 'fill(\''.$value['fieldname'].'\', \''.$cacheinfo['columnids'][$value['upid']].'\', '.$value['fieldname'].'arr, \'\');';
				}
			}
			$value['formtype'] = $value['formtype'] == 'text' ? 'input' : $value['formtype'];
			$value['formtype'] = $value['formtype'] == 'linkage' ? 'select' : $value['formtype'];
			if(preg_match("/^(img|flash|file)$/i", $value['formtype'])) {
				$value['formtype'] = 'file';
			}

			if($value['formtype'] != 'timestamp') {
				$formstr .= label(array('type'=>$value['formtype'], 'alang'=>$value['fieldcomment'], 'name'=>$value['fieldname'], 'options'=>$temparr2, 'rows'=>6, 'width'=>'30%', 'size'=>'52', 'value'=>$thevalue[$value['fieldname']], 'other'=>$other));
			} else {
				$thevalue[$value['fieldname']] = sgmdate($thevalue[$value['fieldname']]);
				$formstr .= <<<EOF
				<tr>
				<th>$value[fieldcomment]</th>
				<td>
				<input type="text" name="$value[fieldname]" id="$value[fieldname]" readonly="readonly" value="{$thevalue[$value['fieldname']]}" /><img src="$siteurl/admin/images/time.gif" onClick="getDatePicker('$value[fieldname]', event, 21)" />
				</td>
				</tr>
EOF;
			}
		}
	}
if(empty($_SCONFIG['noseccode'])) {
	$formstr .= '<tr id="tr_seccode"><th>'.$lang['verification_code'].'<span style="color: #F00">*</span></th><td><input type="text" id="seccode" name="seccode" value="" size="5" class="seccode" /> <img id="xspace-imgseccode" src="'.S_URL.'/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="'.$lang['click_for_a'].'" /></td>';
}
$formstr .= label(array('type'=>'table-end'));
$formstr .= label(array('type'=>'div-end'));
$formstr .= '<div class="buttons">';
$formstr .= label(array('type'=>'button-submit', 'name'=>'thevaluesubmit', 'other'=>' onclick="publish_article();"', 'value'=>$lang['common_submit']));
$formstr .= label(array('type'=>'button-reset', 'name'=>'thevaluereset', 'value'=>$lang['common_reset']));
$formstr .= '</div>';
$formstr .= '<input name="mid" type="hidden" value="'.$modelsinfoarr['mid'].'" />';
$formstr .= '<input name="valuesubmit" type="hidden" value="yes" />';
$formstr .= label(array('type'=>'form-end'));
$formstr .= "<script>$linkagestr</script>\n";

$title = $modelsinfoarr['modelalias'].' - '.$_SCONFIG['sitename'];
$keywords = !empty($modelsinfoarr['seokeywords']) ? $modelsinfoarr['seokeywords'] : $modelsinfoarr['modelalias'];
$description = !empty($modelsinfoarr['seodescription']) ? $modelsinfoarr['seodescription'] : $modelsinfoarr['modelalias'];
$title = strip_tags($title);
$keywords = strip_tags($keywords);
$description = strip_tags($description);

//ģ��
if(empty($modelsinfoarr['tpl'])) {
	$tpldir = 'model/data/'.$modelsinfoarr['modelname'];
} else {
	$tpldir = 'mthemes/'.$modelsinfoarr['tpl'];
}
include template($tpldir.'/post.html.php', 1);

ob_out();

?>