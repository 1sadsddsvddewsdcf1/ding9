<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	�û���̬���

	$RCSfile: batch.panel.php,v $
	$Revision: 1.17 $
	$Date: 2007/06/25 14:39:34 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

getcookie();

$uid = $_SGLOBAL['supe_uid'];

if(!empty($uid)) {
	$uid_url = url_remake(geturl("uid/$uid"));
	print <<<END
	document.write('<h3>$blang[my_menu]</h3>');
	document.write('<ul class="msgtitlelist">');
	document.write('<li><a href="$uid_url" target="_blank">$blang[my_space]</a> &nbsp; <a href="$siteurl/spacecp.php?docp=me" target="_blank">$blang[space_management]</a></li>');
	document.write('<li><a href="$bbsurl/pm.php" target="_blank">$blang[my_pm]</a> &nbsp; <a href="$bbsurl/" target="_blank">$blang[forum_visit]</a></li>');
	document.write('<li><a href="$siteurl/?action-site-type-panel" target="_self">$blang[my_quickly_face]</a> &nbsp; <a href="$siteurl/batch.login.php?action=logout" target="_self">$blang[safe_logout]</a></li>');
	document.write('</ul>');
END;
} else {
	$siteurl = S_URL_ALL;
	print <<<END
	document.write('<form id="login" method="post" name="login" action="$siteurl/batch.login.php?action=login" target="_self">');
	document.write('<fieldset id="userlogin">');
	document.write('<legend>$blang[user_login]</legend>');
	document.write('<p><label for="username">$blang[username]</label><input type="text" name="username" id="username" /></p>');
	document.write('<p><label for="userpass">$blang[password]</label><input type="password" name="password" id="userpass" /></p>');
	document.write('<p class="cookietime"><label for="cookietime"><input type="checkbox" id="cookietime" name="cookietime" value="315360000" />$blang[i_remember]</label></p>');
	document.write('<p><button type="submit" name="loginsubmit" id="dologin" value="true">$blang[login]</button></p> <a href="$bbsurl/register.php?referer=$siteurl/index.php" target="_blank">$blang[registration]</a> <a href="$bbsurl/member.php?action=lostpasswd" target="_blank">$blang[find_passwords]</a></p>');
	document.write('</fieldset>');
	document.write('</form>');
END;
}

?>