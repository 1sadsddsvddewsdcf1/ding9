<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	TRACKBACK

	$RCSfile: trackback.php,v $
	$Revision: 1.23 $
	$Date: 2007/01/23 05:17:46 $
*/

include_once('./include/main.inc.php');

header('Content-type: text/xml');
if(empty($_SCONFIG['allowtrackback'])) {
	tbexit();
}

$code = empty($_GET['code'])?'':$_GET['code'];
$code = authcode($code, 'DECODE', md5(md5($_SCONFIG['sitekey'])));

$carr = explode("\t", $code);

if(count($carr) != 3) tbexit();
$id = intval($carr[0]);
$encode = ($carr[1]=='utf-8')?'utf-8':$_SCONFIG['charset'];
$thetime = intval($carr[2]);
if($_SGLOBAL['timestamp']-$thetime>3600) tbexit();

if(isset($_REQUEST['url'])){
    $title = trim(strip_tags($_REQUEST['title']));
    $content = trim(strip_tags($_REQUEST['excerpt']));
    $from = trim(strip_tags($_REQUEST['blog_name']));
    $url = trim(strip_tags($_REQUEST['url']));
} else {
	tbexit();
}
$error = 1;

if(empty($url) || substr($url, 0, 7) != 'http://') {
    $msg = 'Invalid Parameter!';
} elseif(empty($id)) {
    $msg = 'TrackBack info is missing!';
} else {

	include_once('./include/common.inc.php');

	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' WHERE itemid=\''.$id.'\' AND type=\'blog\' AND folder=\'1\'');
	if($item = $_SGLOBAL['db']->fetch_array($query)) {
		$insertsqlarr = array(
			'itemid' => $id,
			'type' => 'blog',
			'uid' => $item['uid'],
			'authorid' => 0,
			'author' => encodeconvert($encode, $from),
			'ip' => $_SGLOBAL['onlineip'],
			'dateline' => $_SGLOBAL['timestamp'],
			'rates' => 0,
			'message' => encodeconvert($encode, $content),
			'url' => $url,
			'subject' => encodeconvert($encode, $title)
		);
		$cid = inserttable('spacecomments', $insertsqlarr, 1);
        if(!empty($cid)) {
        	$_SGLOBAL['db']->query('UPDATE '.tname('spaceitems').' SET trackbacknum=trackbacknum+1 WHERE itemid=\''.$id.'\'');
        	$error = 0;
        } else {
        	$msg = 'Could not save trackback data, possibly because of mysql database!';
        }
	} else {
		$msg = 'Could not save trackback data!';
	}
}

echo '<?xml version="1.0" encoding="'.$_SCONFIG['charset'].'"?>';
if($error){
	echo "<response><error>1</error><message>$msg</message></response>";
} else {
	echo "<response><error>0</error></response>";
}

function tbexit() {
	global $_SCONFIG;
	echo '<?xml version="1.0" encoding="'.$_SCONFIG['charset'].'"?>';
	echo "<response><error>0</error><message>No TrackBack</message></response>";
	exit;
}

?>