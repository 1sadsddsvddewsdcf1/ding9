<?

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��Ա�������˿ռ�

	$RCSfile: register.php,v $
	$Revision: 1.50 $
	$Date: 2007/06/27 17:15:09 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

getcookie(1);

if(empty($_SGLOBAL['supe_uid'])) {
	setcookie('_refer', rawurlencode(geturl('action/register', 1)));
	messagebox('error', 'no_login', geturl('action/login'));
}

include_once(S_ROOT.'./include/common.inc.php');

if(submitcheck('registersubmit')) {

	$query = $_SGLOBAL['db']->query('SELECT uid FROM '.tname('userspaces').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
	if($space = $_SGLOBAL['db']->fetch_array($query)) {
		messagebox('ok', 'succeed', geturl('uid/'.$_SGLOBAL['supe_uid']));
	}

	$_POST['spacename'] = shtmlspecialchars($_POST['spacename']);

	$tpl = array();
	$_POST['tplid'] = trim(preg_replace("/[^a-z0-9\-\_]/i", '', trim($_POST['tplid'])));
	$dir = S_ROOT.'./themes/'.$_POST['tplid'];
	if(is_dir($dir) && file_exists($dir.'/theme.php')) {
		@include_once($dir.'/theme.php');
		$tpl['css'] = cssimage_replace(sreadfile($dir.'/'.$themes['css']), 'themes/'.$_POST['tplid']);//�滻url
		$tpl['tplname'] = $themes['name'];
	}
	if(empty($tpl['css'])) {
		$tpl['css'] = 'body { margin: 0; padding: 0; background: #EEE; color: #000; font: 12px Arial, Helvetica, sans-serif; text-align: center; }
		input, textarea, select, button { font: 1em Arial, Helvetica, sans-serif; }
		#wrap { margin: 1em auto; text-align: left; width: 770px; w\idth: 760px; border: 5px solid #FFF; background: #FFF; overflow: hidden; }
		#header { background: #1C5B9E; margin-bottom: 5px; }
		#header * { color: #FFF; }
		#menu { line-height: 26px; }
		.xspace-blocktitle { margin: 0; font-size: 1.2em; line-height: 1.6em; border-bottom: 1px solid #CCC; }
		.sidearea { background: #EEE; padding: 5px; overflow: hidden; }
		#mainarea { padding: 5px; }
		a { color: #006; text-decoration: none; }
		a:hover { text-decoration: underline; }
		a:visited { color: #099; }';
	}

	if($_POST['spacemode'] != 'bbs') $_POST['spacemode'] = 'blog';
	$setsqlarr = array(
		'uid' => $_SGLOBAL['supe_uid'],
		'dateline' => $_SGLOBAL['timestamp'],
		'username' => $_SGLOBAL['supe_username'],
		'spacename' => $_POST['spacename'],
		'catid' => intval($_POST['catid']),
		'province' => shtmlspecialchars($_POST['province']),
		'city' => shtmlspecialchars($_POST['city']),
		'spacemode' => $_POST['spacemode']
	);

	inserttable('userspaces', $setsqlarr);

	$setsqlarr = array(
		'uid' => $_SGLOBAL['supe_uid'],
		'blogmod' => 1,//��ʾ�����ժҪ
		'summarylen' => 300
	);
	inserttable('userspacefields', $setsqlarr);

	updatetable('members', array('havespace'=>1), array('uid'=>$_SGLOBAL['supe_uid']));
	
	dbconnect(1);
	$_SGLOBAL['db_bbs']->query('UPDATE '.tname('members', 1).' SET xspacestatus=\'1\' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');

	$thedir = getuserfile($_SGLOBAL['supe_uid'], 'css', 'path', 1);
	writefile($thedir, $tpl['css']);
	
	messagebox('ok', 'succeed', geturl('uid/'.$_SGLOBAL['supe_uid']));
	
} else {

	dbconnect(1);
	$query = $_SGLOBAL['db_bbs']->query('SELECT groupid, username, password FROM '.tname('members', 1).' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
	$member = $_SGLOBAL['db_bbs']->fetch_array($query);

	$_SGLOBAL['member']['groupid'] = $groupid = $member['groupid'];
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT COUNT(*) FROM ".tname('members')." WHERE uid='$_SGLOBAL[supe_uid]'"), 0);
	if($count) {
		$_SGLOBAL['db']->query('UPDATE '.tname('members').' SET groupid=\''.$groupid.'\' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
	} else {
		$setsqlarr = array(
			'uid' => $_SGLOBAL['supe_uid'],
			'groupid' => $groupid,
			'username' => addslashes($member['username']),
			'password' => addslashes($member['password'])
		);
		inserttable('members', $setsqlarr);
	}
	
	@include_once(S_ROOT.'./data/system/group.cache.php');
	if(!empty($_SGLOBAL['grouparr'][$_SGLOBAL['member']['groupid']])) {
		$_SGLOBAL['group'] = $_SGLOBAL['grouparr'][$_SGLOBAL['member']['groupid']];
	} else {
		messagebox('error', 'space_no_popedom', geturl("uid/$_SGLOBAL[supe_uid]"));
	}
	
	if(empty($_SGLOBAL['group']['allowspace'])) {
		messagebox('error', 'space_no_popedom', geturl("uid/$_SGLOBAL[supe_uid]"));
	}

	$query = $_SGLOBAL['db']->query('SELECT uid FROM '.tname('userspaces').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
	if($space = $_SGLOBAL['db']->fetch_array($query)) {
		messagebox('error', 'succeed', geturl('uid/'.$_SGLOBAL['supe_uid']));
	}
	
	//ģ��
	$tpllist = array();
	$themearr = getthemes();
	foreach ($themearr as $tpl) {
		if(empty($tpl['thumb'])) {
			$tpl['a_thumbpath'] = S_URL.'/images/base/nopic.gif';
		} else {
			$tpl['a_thumbpath'] = S_URL.'/themes/'.$tpl['dir'].'/'.$tpl['thumb'];
		}
		if(empty($tpl['preview'])) {
			$tpl['a_filepath'] = S_URL.'/images/base/nopic.gif';
		} else {
			$tpl['a_filepath'] = S_URL.'/themes/'.$tpl['dir'].'/'.$tpl['preview'];
		}
		$tpl['tplid'] = $tpl['dir'];
		$tpl['tplname'] = $tpl['name'];
		$tpllist[] = $tpl;
	}

	//����
	$catstr = '';
	$uplistarr = getcategory('space');
	foreach ($uplistarr as $key => $value) {
		$catstr .= '<option value="'.$key.'">'.$value['pre'].$value['name'].'</option>';
	}
	
	$title = $lang['register'];

	include template('site_register');
}

?>