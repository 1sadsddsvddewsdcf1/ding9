<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	վ��ͼƬ��ҳ

	$RCSfile: image.php,v $
	$Revision: 1.16 $
	$Date: 2007/06/27 17:15:08 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

if(!empty($_SCONFIG['htmlindex'])) {
	$_SHTML['action'] = 'image';
	$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
	ehtml('get', $_SCONFIG['htmlindextime']);
	$_SCONFIG['debug'] = 0;
}

include_once(S_ROOT.'./include/common.inc.php');

$title = $lang['image'].' - '.$_SCONFIG['sitename'];
$keywords = $lang['image'];
$description = $lang['image'];

$guidearr = array();
$guidearr[] = array('url' => geturl('action/image'),'name' => $channels['menus']['image']['name']);
if(!empty($channels['types']['topic'])) unset($channels['types']['topic']);

$tplname = 'image_index';

$title = strip_tags($title);
$keywords = strip_tags($keywords);
$description = strip_tags($description);

include template($tplname);

ob_out();

if(!empty($_SCONFIG['htmlindex'])) {
	ehtml('make');
} else {
	maketplblockvalue('cache');
}

?>