<?exit?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>$title $_SCONFIG[seotitle]</title>
<meta name="keywords" content="$keywords $_SCONFIG[seokeywords]" />
<meta name="description" content="$description $_SCONFIG[seodescription]" />
<link href="{S_URL}/$tpldir/images/style.css" rel="stylesheet" type="text/css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<div id="header">
	<table>
	<tr>
		<td valign="middle" id="logo">
			<a href="{S_URL}/"><img src="{S_URL}/$tpldir/images/logo.gif"/></a>
		</td>
		<td valign="middle" id="topmenu">
			<ul>
				<!--{loop $channels['menus'] $key $value}-->
				<li><a href="$value[url]" <!--{if $key==$modelsinfoarr[modelname]}-->class="on"<!--{/if}-->>$value[name]</a></li>
				<!--{/loop}-->
			</ul>
		</td>
	</tr>
	</table>
</div>
