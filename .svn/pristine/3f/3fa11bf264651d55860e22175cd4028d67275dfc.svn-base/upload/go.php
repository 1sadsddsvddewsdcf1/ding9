<?

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	XS��������ӿ�

	$RCSfile: go.php,v $
	$Revision: 1.2 $
	$Date: 2006/12/14 02:13:14 $
*/

include_once('./include/main.inc.php');

$domain = empty($_GET['d'])?'':$_GET['d'];

if(empty($domain)) {
	sheader(S_URL);
} else {
	mydomain($domain);
}

?>
