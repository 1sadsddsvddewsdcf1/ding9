<?exit?>
{template bbs_header}

<!--{if !empty($ads2['pagecenterad'])}-->
<div class="content" style="background: none; margin-bottom: 0.5em;">
	$ads2[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->
<div class="contentR">
	<div class="sideR">

		<div class="block topblock">
			<h3>$forum[name]</h3>
			<!--�Ӱ��-->
			<!--{block name="bbsforum" parameter="fup/$fid/allowblog/1/order/displayorder/limit/0,100/cachetime/28800/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subarr'] $value}-->
				<li><a href="$value[url]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->
		</div>

		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="bbsthread" parameter="fid/$fid/dateline/2592000/order/views DESC/limit/0,10/cachetime/97200/cachename/hotthread/tpl/data"}-->
		<!--{if $_SBLOCK['hotthread']}-->
		<div class="block">
			<h3>�¶ȹ�ע�ȵ�</h3>
			<dl>
				<!--{loop $_SBLOCK['hotthread'] $value}-->
				<dt><a href="$value[url]">$value[subject]</a></dt>
				<!--{/loop}-->
			</dl>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">
		<!--������������־�б�-->
		<!--{if $forum['type'] != 'group'}-->
		<!--{block name="bbsthread" parameter="perpage/20/fid/$fid/showdetail/1/messagelen/160/subjectlen/40/order/dateline DESC/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		<div class="block topblock">
			<a href="javascript:;" onclick="ColExpAllIntro('threadlist',this)" class="more minus">ֻ�г�����</a>
			<h3>�����б�</h3>
			<ul id="threadlist" class="messagelist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<h4>
						<em class="smalltxt"><a href="#uid/$value[authorid]#" target="_blank">$value[author]</a></em>
						<a href="$value[url]" target="_blank">$value[subject]</a>
					</h4>
					<p class="smalltxt">
						������: #date("Y-m-d", $value["dateline"])# 
						<!--{if $value[replies]}--><a href="$value[url]" target="_blank" class="replynum">�ظ�: $value[replies]</a><!--{/if}-->
					</p>
					<p>$value[message] <a href="$value[url]" target="_blank">...ȫ��</a></p>
				</li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[newlist_multipage]}-->
				$_SBLOCK[newlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>��ǰֻ��һҳ</span></div>
				<!--{/if}-->
			</div>
			
		</div>
		<!--{/if}-->
		<!--{/if}-->

		<!--{if $_SGET['page']<2 && !empty($_SBLOCK['subarr'])}-->
		<!--{loop $_SBLOCK['subarr'] $key $value}-->
		<!--{eval $cachetime=1800+$key*5;}-->
		<!--{block name="bbsthread" parameter="fid/$value[fid]/order/dateline DESC/limit/0,20/cachetime/$cachetime/cachename/subthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['subthreadlist']}-->
		<div class="block">
			<a href="#action/forumdisplay/fid/$value[fid]#" class="more">����</a>
			<h3><a href="#action/forumdisplay/fid/$value[fid]#">$value[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template bbs_footer}
