<?exit?>
{template image_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->
<div class="contentR" style="margin-bottom: 0;">
	<div class="sideR">
	
		<!-- �û���� -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!--����ͼƬ-->
		<!--{block name="spaceimage" parameter="order/i.dateline DESC/limit/0,6/subjectlen/14/cachetime/12000/cachename/newimage/tpl/data"}-->
		<div class="block" style="height: 320px; overflow: hidden;">
			<h3>�����ϴ�</h3>
			<dl>
				<!--{loop $_SBLOCK['newimage'] $value}-->
				<dt><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a> <span class="smalltxt" title="����$value[replynum]������">($value[replynum])</span></dt>
				<dd><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / #date("m-d h:m", $value["dateline"])#</dd>
				<!--{/loop}-->
			</dl>
		</div>
		
	</div>
	<div class="mainarea">
		
		<!--��ѡ�����ܺ������-->
		<div class="block topblock" style="height: 190px; overflow: hidden;">
			<h3>һ�ܺ�����ͼ</h3>
			<!--{block name="spaceimage" parameter="dateline/604800/order/i.goodrate DESC/limit/0,5/cachetime/64400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/focusimageweek/tpl/data"}-->
			<ul class="avatarlist">
				<!--{loop $_SBLOCK['focusimageweek'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
					<ul>
						<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
						<li class="smalltxt"><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
						<li class="smalltxt"><span class="goodrate">����: $value[goodrate]</span></li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--���㣺�������-->
		<div id="focusimage" class="block">
			<h3 id="focusimagetabs" class="tabs">
				<a id="weektab" href="javascript:setTab('focusimage','week')" class="tab curtab">���ܽ���</a>
				<a id="monthtab" href="javascript:setTab('focusimage','month')" class="tab">���½���</a>
				<a id="alltab" href="javascript:setTab('focusimage','all')" class="tab">��������</a>
			</h3>
			<!--������������б�(һ��)-->
			<!--{block name="spaceimage" parameter="dateline/604800/order/i.replynum DESC/limit/0,16/cachetime/84400/subjectlen/28/subjectdot/1/cachename/focusimageweek/tpl/data"}-->
			<div id="week" class="tabcontent">
				<ul class="list2col" style="height: 190px; overflow: hidden;">
					<!--{loop $_SBLOCK['focusimageweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a><span class="smalltxt" title="����$value[replynum]������"> ($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--������������б�(һ��)-->
			<!--{block name="spaceimage" parameter="dateline/2592000/order/i.replynum DESC/limit/0,16/cachetime/94400/subjectlen/28/subjectdot/1/cachename/focusimagemonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px; overflow: hidden;">
					<!--{loop $_SBLOCK['focusimagemonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a><span class="smalltxt" title="����$value[replynum]������"> ($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--������������б�(ȫ��)-->
			<!--{block name="spaceimage" parameter="order/i.replynum DESC/limit/0,16/cachetime/104400/subjectlen/28/subjectdot/1/cachename/focusimage/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px; overflow: hidden;">
					<!--{loop $_SBLOCK['focusimage'] $value}-->
					<li><cite><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a><span class="smalltxt" title="����$value[replynum]������"> ($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>

<!--��������ͼƬ-->
<!--{block name="spaceimage" parameter="order/i.lastpost DESC/limit/0,12/cachetime/11400/subjectlen/12/showdetail/1/cachename/commendimage/tpl/data"}-->
<div class="block cleanblock">
	<h3>��������ͼƬ����</h3>
	<div style="width: 100%; background: #FFF; overflow: hidden">
		<ul id="scroller" class="imgthumblist">
			<!--{loop $_SBLOCK['commendimage'] $value}-->
			<li>
				<div><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
				<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
</div>

<div class="contentR">
	<div class="sideR">
	
		<!--�¶Ⱥ���-->
		<!--{block name="spaceimage" parameter="dateline/2592000/order/i.lastpost DESC/limit/0,8/cachetime/57400/subjectlen/12/showdetail/1/cachename/specialimage/tpl/data"}-->
		<div class="block" style="height: 566px; overflow: hidden;">
			<h3>�¶Ⱥ���ͼ</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['specialimage'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a>
					<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
					<p class="smalltxt">�ϴ�: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a></p>
					<p class="smalltxt"><span class="goodrate">����: $value[goodrate]</span></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="mainarea">
		<!--���ܵ������-->
		<!--{block name="spaceimage" parameter="dateline/604800/order/i.viewnum DESC/limit/0,8/cachetime/84410/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/hotimage/tpl/data"}-->
		<div class="block" style="height: 567px; overflow: hidden;">
			<h3>���ܵ������</h3>
			<ul class="coverlist">
				<!--{loop $_SBLOCK['hotimage'] $value}-->
				<li>
					<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
					<ul>
						<li><h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4></li>
						<li class="smalltxt">�ϴ�: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
						<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
						<li class="smalltxt"><span class="goodrate">����: $value[goodrate]</span>
						<!--{if $value[replynum]}--> <a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}--></li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template image_footer}