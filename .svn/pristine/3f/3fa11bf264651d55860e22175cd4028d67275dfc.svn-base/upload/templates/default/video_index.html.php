<?exit?>
{template video_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->

<div class="contentR">
	<!-- �Ҳ� -->
	<div class="sideR">
		<!-- �û���� -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<div class="block">
			<a href="{S_URL}/spacecp.php?action=spacevideos&amp;op=add" style="display: block; background: #FFFAF5 url({S_URL}/templates/$_SCONFIG[template]/images/postvideo.jpg); margin: 1px; line-height: 50px; font-weight: bold; text-indent: 50px; color: #009900;">�ϴ���Ƶ</a>
		</div>
		<div class="block">
			<a href="{S_URL}/spacecp.php?action=spacevideos&amp;op=online" style="display: block; background: #FFFAF5 url({S_URL}/templates/$_SCONFIG[template]/images/postvideo.jpg) no-repeat 0 -50px; margin: 1px; line-height: 50px;  font-weight: bold; text-indent: 50px; color: #009900;">����¼����Ƶ</a>
		</div>
		
		<div class="block cleanblock">
			<ul class="msgtitlelist" style="height: 44px; overflow: hidden;">
				<li><a href="#">�ϴ�����</a></li>
				<li><a href="#">�ϴ���Ƶ��֪</a></li>
			</ul>
		</div>
		
	</div>
	<!-- /�Ҳ� -->

	<div class="mainarea">
		
		<div class="block cleanblock topblock" style=" height: 283px; overflow: hidden;">
		
		<!--һ�ܺ���Ӱ��-->
		<!--{block name="spacevideo" parameter="dateline/604800/order/i.goodrate DESC/limit/0,5/cachetime/53400/subjectlen/12/showdetail/1/cachename/hotvideo/tpl/data"}-->
		<div style="float: left; margin: 5px 10px 0; width: 320px; height: 270px;">
		<!--{if !empty($_SBLOCK['hotvideo'])}-->
			<script type="text/javascript" language="javascript">
			<!--			
			var xsTextBar = 1; //�Ƿ���ʾ�������ӣ�1Ϊ��ʾ��0Ϊ����ʾ
			var xsPlayBtn = 0; //�Ƿ���ʾ���Ű�ť��1��ʾ��0Ϊ����ʾ
			var xsImgSize = new Array(320,240); //�õ�ͼƬ�ĳߴ磬��ʽΪ������,�߶ȡ�
		
			var xsImgs = new Array();
			var xsImgLinks = new Array();
			var xsImgTexts = new Array();
			
			<!--{eval $i=0;}-->
			<!--{loop $_SBLOCK['hotvideo'] $key $value}-->
			xsImgs[$i] = "$value[image]";
			xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
			xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
			<!--{eval $i++;}-->
			<!--{/loop}-->
			//-->
			</script>
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		<!--��־ͼƬ�õ�Ƭ ����-->
			
		<!--��������-->
		<!--{block name="spacevideo" parameter="order/i.lastpost DESC/limit/0,4/cachetime/64400/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/hotlist/tpl/data"}-->
		<div style="padding: 5px 10px; 0">
			<ul style="margin: 0; padding: 0; list-style: none;">
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li style="height: 65px; margin-bottom: 4px; overflow: hidden; background: url({S_URL}/templates/$_SCONFIG[template]/images/dotline_h.gif) repeat-x bottom;;">
					<div style="border: 1px solid #DDD; background: #FFF; padding: 5px; float: left; margin-right: 10px;"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" style="width: 64px; height: 48px;" /></a></div>
					<ul style="margin: 0; padding: 0; list-style: none; padding-top: 6px;">
						<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
						<li class="smalltxt">�ϴ�: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
						<li class="smalltxt">�鿴: $value[viewnum] / ����: $value[replynum]</li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		</div>
		
	</div>
</div>



<div class="contentR">
	<div class="sideR">

		<!--������Ƶ -->
		<!--{block name="spacevideo" parameter="order/i.dateline DESC/limit/0,10/showdetail/1/subjectlen/14/cachetime/12000/cachename/newvideo/tpl/data"}-->
		<div class="block" style="height: 878px; overflow: hidden;">
			<h3>�����ϴ�</h3>
			<dl>
				<!--{loop $_SBLOCK['newvideo'] $value}-->
				<dt><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a> <span class="smalltxt" title="����$value[replynum]������">($value[replynum])</span></dt>
				<dd>�ϴ�: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / #date("Y-m-d", $value["dateline"])#</dd>
				<!--{/loop}-->
			</dl>
		</div>
		
	</div>
	<div class="mainarea">
		
		<!--���ܵ������ -->
		<div class="block" style="height: 190px; overflow: hidden;">
			<h3>���ܵ������</h3>
			<!--{block name="spacevideo" parameter="dateline/604800/order/i.viewnum DESC/limit/0,5/cachetime/64400/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/hotratevideo/tpl/data"}-->
			<ul class="avatarlist">
					<!--{loop $_SBLOCK['hotratevideo'] $value}-->
					<li>
						<div><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
							<li class="smalltxt">�ϴ�: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
							<li class="smalltxt">���: $value[viewnum]</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
		</div>
		
		<!--�������-->
		<div id="focusvideo" class="block" style="height: 680px; overflow: hidden;">
			<h3 id="focusvideotabs" class="tabs">
				<a id="weektab" onclick="setTab('focusvideo','week')" class="tab curtab">���ܽ���</a>
				<a id="monthtab" onclick="setTab('focusvideo','month')" class="tab">���½���</a>
				<a id="alltab" onclick="setTab('focusvideo','all')" class="tab">��������</a>
			</h3>
			<div id="week" class="tabcontent">
			<!--{block name="spacevideo" parameter="dateline/604800/order/i.replynum DESC/limit/0,10/cachetime/74400/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/focusvideoweek/tpl/data"}-->
				<ul class="videoscrlist">
					<!--{loop $_SBLOCK['focusvideoweek'] $value}-->
					<li>
						<div class="videoscr"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4></li>
							<li class="smalltxt">�ϴ�: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}-->
								<!--{if $value['goodrate']}--><span class="goodrate">����: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<div id="month" class="tabcontent" style="display: none;">
			<!--{block name="spacevideo" parameter="dateline/2092000/order/i.replynum DESC/limit/0,10/cachetime/84400/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/focusvideomonth/tpl/data"}-->
				<ul class="videoscrlist">
					<!--{loop $_SBLOCK['focusvideomonth'] $value}-->
					<li>
						<div class="videoscr"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4></li>
							<li class="smalltxt">�ϴ�: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}-->
								<!--{if $value['goodrate']}--><span class="goodrate">����: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<div id="all" class="tabcontent" style="display: none;">
			<!--{block name="spacevideo" parameter="order/i.replynum DESC/limit/0,10/cachetime/94400/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/focusvideo/tpl/data"}-->
				<ul class="videoscrlist">
					<!--{loop $_SBLOCK['focusvideo'] $value}-->
					<li>
						<div class="videoscr"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4></li>
							<li class="smalltxt">�ϴ�: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}-->
								<!--{if $value['goodrate']}--><span class="goodrate">����: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template video_footer}