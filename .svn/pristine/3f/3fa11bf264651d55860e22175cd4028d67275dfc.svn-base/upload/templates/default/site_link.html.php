<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>����λ�ã�
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h2>վ������</h2>
</div>
<!-- ���� -->
<!--{block name="friendlink" parameter="order/displayorder/limit/0,100/cachetime/11600/namelen/16/cachename/friendlink/tpl/data"}-->
<!--{eval $imglink=$txtlink="";}-->
<!--{loop $_SBLOCK['friendlink'] $value}-->
<!--{if $value[logo]}-->
<!--{eval $imglink .="<li><a href=\"".$value[url]."\" target=\"_blank\"><img src=\"".$value[logo]."\" alt=\"".$value[description]."\" /></a></li>";}-->
<!--{else}-->
<!--{eval $txtlink .= "<li><a href=\"".$value[url]."\" title=\"".$value[description]."\" target=\"_blank\">".$value[name]."</a></li>";}-->
<!--{/if}-->
<!--{/loop}-->
<div id="friendlink">
	<ul class="imglink">
	$imglink
	</ul>
	<ul>
	$txtlink
	</ul>
</div>
<!-- /���� -->

{template site_footer}