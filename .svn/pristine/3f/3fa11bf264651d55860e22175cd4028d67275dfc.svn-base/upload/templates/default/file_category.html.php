<?exit?>
{template file_header}

<!--{if !empty($ads2['pagecenterad'])}-->
<div class="banner">
	$ads2[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->
<div class="contentR">
	<div class="sideR">
	
		<div class="block topblock">
			<h3>$thecat[name]</h3>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{/if}-->
			<!--{block name="category" parameter="upid/$thecat[catid]/ischannel/2/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['subarr'] $value}-->
					<li><a href="$value[url]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>
		
		<!--ר���б�-->
		<!--{block name="category" parameter="upid/$thecat[catid]/ischannel/1/showattach/1/order/c.displayorder/limit/0,100/cachetime/16400/cachename/channel/tpl/data"}-->
		<!--{if $_SBLOCK['channel']}-->
		<div class="block">
			<h3>ר��</h3>
			<ul class="imglogolist">
				<!--{loop $_SBLOCK['channel'] $value}-->
				<li>
					<a href="#action/category/catid/$value[catid]#"><img src="$value[thumb]" alt="" /></a>
					<p><a href="#action/category/catid/$value[catid]#">$value[name]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--վ���Ƽ��ļ�-->
		<!--{block name="spacefile" parameter="catid/$thecat[subcatid]/dateline/2592000/order/i.viewnum DESC/limit/0,15/cachetime/95400/cachename/hotfile/tpl/data"}-->
		<div class="block">
			<h3>�¶ȵ�����а�</h3>
			<dl>
				<!--{loop $_SBLOCK['hotfile'] $value}-->
				<dt><a href="$value[url]" target="_blank">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></dt>
				<!--{/loop}-->
			</dl>
		</div>
		
	</div>
	<div class="mainarea">

		<!--��ǰ���������б�-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="spacefile" parameter="perpage/15/catid/$thecat[subcatid]/order/i.dateline DESC/showdetail/1/messagelen/150/messagedot/1/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		
		<div class="block topblock">
			<a href="javascript:;" onclick="ColExpAllIntro('filelist',this)" class="more minus">ֻ�г�����</a>
			<h3>�ļ��б�</h3>
			<ul id="filelist" class="messagelist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<h4>
						<em class="smalltxt">
							<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}-->
							<!--{if $value[goodrate]}--><span class="goodrate">����: $value[goodrate]</span><!--{/if}-->&nbsp;
						</em>
						<a href="$value[url]" target="_blank">$value[subject]</a>
					</h4>
					<p class="smalltxt">
						<a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a> �ϴ��� #date("Y-m-d", $value["dateline"])# 
						��С: $value[filesize] $value[filesizeunit] ��Ȩ��ʽ: $value[permission] ����ƽ̨: $value[system]
					</p>
					<p>$value[message] <a href="$value[url]">...ȫ��</a></p>
				</li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[newlist_multipage]}-->
				$_SBLOCK[newlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>��ǰֻ��һҳ</span></div>
				<!--{/if}-->
			</div>
			
		</div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--��̳��Դ�б�-->
		<!--{if !empty($thecat['bbsmodel'])}-->
		<!--{if $_SGET['page']<2 || !empty($_SGET['mode'])}-->
		<!--{eval $_SGET['mode']='bbs';}-->
		<!--{block name="bbsthread" parameter="perpage/20/$thecat[blockparameter]/cachename/bbsthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['bbsthreadlist']}-->
		<div class="block">
			<h3>��̳��Դ</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['bbsthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[bbsthreadlist_multipage]}-->
				$_SBLOCK[bbsthreadlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>��ǰֻ��һҳ</span></div>
				<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->

		<!--�ӷ��������б�-->
		<!--{if $_SGET['page']<2}-->
		<!--{loop $_SBLOCK['subarr'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
		<!--{block name="spacefile" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,5/cachetime/$ctime/showdetail/1/messagelen/150/messagedot/1/cachename/sublist/tpl/data"}-->
		<!--{if $_SBLOCK['sublist']}-->
		<div class="block">
			<a href="#action/category/catid/$cat[catid]#" class="more">����</a>
			<h3>
				<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
			</h3>
			<ul class="messagelist">
			<!--{loop $_SBLOCK['sublist'] $value}-->
				<li>
					<h4><a href="$value[url]" target="_blank">$value[subject]</a> <span class="smalltxt">($value[viewnum]�˵��,$value[replynum]������)</span></h4>
					<p class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a>, ������ #date("Y-m-d", $value["dateline"])#<br /></p>
					<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
					<p>��С: $value[filesize] $value[filesizeunit] ��Ȩ��ʽ: $value[permission] ����ƽ̨: $value[system]</p>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template file_footer}