<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>����λ�ã�
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h1>TAG</h1>
</div>
<div class="contentR">
	<div class="sideR">
		<div class="block topblock">
			<h3>TAG��Ϣ</h3>
			<h1 style="margin: 10px; text-align: center; font-size: 1.6em;">$tag[tagname]</h1>
			<ul class="msgtitlelist">
				<li>������: <a href="$tag[spaceurl]" target="_blank" class="author">$tag[username]</a></li>
				<li>����ʱ��: #date("Y-m-d H:i:s",$tag["dateline"])#</li>
				<li>����Ϣ��: $tag[spaceallnum]</li>
			</ul>
		</div>
		<div class="block">
			<h3>���TAG</h3>
			<ul class="msgtitlelist">
				<!--{if $tag[relativetags]}-->
				<!--{loop $tag[relativetags] $key $value}-->
				<li><a href="#action/tag/tagname/$key#">$value</a></li>
				<!--{/loop}-->
				<!--{else}-->
				<li>�������TAG</li>
				<!--{/if}-->
			</ul>
		</div>
	</div>
	<div class="mainarea">
		<div class="block topblock">
			<a href="#action/tag/tagid/$tag[tagid]#" class="more">�����б�</a>
			<h3>TAG��Ϣ�б�</h3>
			<ul class="msgtitlelist linelist articlelist">
				<!--{loop $iarr $value}-->
				<li><cite><a href="#action/$value[type]#">{$value[typename]}</a> </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<div class="pagediv">
			$multi
		</div>
	</div>
</div>

{template site_footer}