<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>����λ�ã�
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h1>վ���ͼ</h1>
</div>
<!-- ������ -->
<div id="sitemap">
	<!--��Ѷ������ ��ʼ-->
	<!--{if !empty($channels['types']['news'])}-->
	<!--{block name="category" parameter="type/news/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/10800/cachename/newscat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['news']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['newscat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--��Ѷ������ ����-->
	
	<!--��־������ ��ʼ-->
	<!--{if !empty($channels['types']['blog'])}-->
	<!--{block name="category" parameter="type/blog/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/10900/cachename/blogcat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['blog']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['blogcat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--��־������ ����-->

	<!--ͼƬ������ ��ʼ-->
	<!--{if !empty($channels['types']['image'])}-->
	<!--{block name="category" parameter="type/image/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/11000/cachename/imagecat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['image']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['imagecat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--ͼƬ������ ����-->

	<!--Ӱ�������� ��ʼ-->
	<!--{if !empty($channels['types']['video'])}-->
	<!--{block name="category" parameter="type/video/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/21000/cachename/videocat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['video']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['videocat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--Ӱ�������� ����-->

	<!--��Ʒ������ ��ʼ-->		
	<!--{if !empty($channels['types']['goods'])}-->
	<!--{block name="category" parameter="type/goods/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/11100/cachename/goodscat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['goods']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['goodscat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--��Ʒ������ ����-->

	<!--�ļ������� ��ʼ-->
	<!--{if !empty($channels['types']['file'])}-->
	<!--{block name="category" parameter="type/file/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/11200/cachename/filecat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['file']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['filecat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--�ļ������� ����-->

	<!--��ǩ������ ��ʼ-->
	<!--{if !empty($channels['types']['link'])}-->
	<!--{block name="category" parameter="type/link/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/11300/cachename/linkcat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['link']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['linkcat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--��ǩ������ ����-->

	<!--Ȧ�Ӹ����� ��ʼ-->
	<!--{if !empty($channels['menus']['group'])}-->
	<!--{block name="category" parameter="type/group/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/21400/cachename/groupcat/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['group']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['groupcat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--Ȧ�Ӹ����� ����-->

	<!--���˿ռ������ ��ʼ-->
	<!--{block name="category" parameter="type/space/isroot/1/ischannel/2/limit/0,100/order/c.displayorder/cachetime/11400/cachename/spacecat/tpl/data"}-->
	<div class="block">
		<h3>���˿ռ�</h3>
		<ul>
			<!--{loop $_SBLOCK['spacecat'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--���˿ռ������ ����-->
	<!--ģ���б���ʼ-->
	<!--{loop $modelarr $value}-->
		<div class="block">
			<h3>$value[modelalias]</h3>
			<ul>
				<!--{loop $value['categories'] $key $val}-->
				<li><a href="{S_URL}/m.php?name={$value[modelname]}&mo_catid=$key" title="$val">$val</a></li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/loop}-->
	<!--ģ���б�����-->
	<!--��̳����б�100�� ��ʼ-->
	<!--{if !empty($channels['menus']['bbs'])}-->
	<!--{block name="bbsforum" parameter="type/forum/limit/0,100/order/f.displayorder/cachetime/21500/cachename/bbsforum/tpl/data"}-->
	<div class="block">
		<h3>$channels['menus']['bbs']['name']</h3>
		<ul>
			<!--{loop $_SBLOCK['bbsforum'] $value}-->
			<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
	<!--��̳����б�100�� ����-->
	
</div>
<!-- /���� -->

{template site_footer}