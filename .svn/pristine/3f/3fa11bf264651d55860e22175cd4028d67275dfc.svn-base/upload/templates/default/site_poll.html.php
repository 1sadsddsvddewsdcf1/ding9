<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>����λ�ã�
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h1>ͶƱ</h1>
</div>
<div id="panel">
	<h3>ͶƱ:$poll[subject]</h3>
	<p>ͶƱ����:$poll[votersnum]</p>
	<p>��ʼʱ��($poll[dateline])-����ʱ��($poll[updatetime])</p>
	<p id="pollsummary">ͶƱ˵��:$poll[summary]</p>
	<form id="pollform" action="#action/poll/php/1#" method="post">
		<fieldset id="pollresult" style="display: none;">
			<legend>ͶƱ���</legend>
			<ul>
			<!--{loop $poll[options] $key $options}-->
				<li>
					$options[name]
					<p>
						<span class="pollnum">��Ʊ:$options[num] / $options[percent]%</span>
						<span class="pollpercent"><span style="width: $options[percent]%;">&nbsp;</span></span>
					</p>
				</li>
			<!--{/loop}-->
			</ul>
		</fieldset>
		<script language="javascript" type="text/javascript">
		function showresult() {
		var result=getbyid('pollresult');
		if (result.style.display=='none') result.style.display='block'; else result.style.display='none';
		}
		</script>
		<fieldset id="dopoll">
			<legend>ͶƱ</legend>
			<ul>
			<!--{loop $poll[options] $okey $options}-->
				<li>
					<!--{if $poll[ismulti]}-->
					<input type="checkbox" id="votekey-$okey" name="votekey[]" value="$okey" class="votekey" />
					<!--{else}-->
					<input type="radio" id="votekey-$okey" name="votekey[]" value="$okey" class="votekey"/>
					<!--{/if}-->
					<label for="votekey-$okey">$options[name]</label>
				</li>
			<!--{/loop}-->
			</ul>
			<input type="hidden" name="pollid" value="$poll[pollid]" />
			<input type="hidden" name="pollsubmit" value="yes" />
			<button id="dovote" name="pollbtn" type="submit" value="true">ͶƱ</button>
			&nbsp;<button type="button" onclick="showresult();">�鿴���</button>
		</fieldset>
	</form>
</div>

{template site_footer}