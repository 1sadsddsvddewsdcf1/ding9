<?exit?>
{template site_header}

<div id="navigation" class="simplepage">
	<p>����λ�ã�
		<a href="{S_URL}/">��ҳ</a>
		&gt;&gt; $title
	</p>
	<h1>վ�㹫��</h1>
</div>
<div id="panel">
	<ul class="messagelist">
	<!--{loop $listvalue $value}-->
		<li>
			<h4><a href="$value[url]">$value[subject]</a></h4>
			<p class="smalltxt">������: $value[author]&nbsp;&nbsp;��ʼʱ��: $value[starttime]&nbsp;&nbsp;����ʱ��: $value[endtime]</p>
			<p>$value[message]</p>
		</li>
	<!--{/loop}-->
	</ul>
	<div class="pages" style="">
		$multipage
	</div>
</div>

{template site_footer}