<?exit?>
{template news_header}
<!-- Content���� -->
<div class="contentR">
	<div class="sideR">

		<!--���¸�������-->
		<!--{block name="spacenews" parameter="catid/$thecat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/7280/cachename/newnews/tpl/data"}-->
		<!--{if $_SBLOCK['newnews']}-->
		<div class="block topblock">
			<h3>���¸���</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="spacenews" parameter="catid/$thecat[subcatid]/dateline/2592000/order/i.viewnum DESC/limit/0,10/cachetime/28800/cachename/hotnews/tpl/data"}-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>�¶��ȵ�</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
		<!--�����Ѷ-->
		<!--{if !empty($news[relativeitemids])}-->
		<!--{block name="spacenews" parameter="itemid/$news[relativeitemids]/order/i.dateline DESC/limit/0,20/cachetime/17680/cachename/relativeitem/tpl/data"}-->
		<div class="block">
			<h3>����Ķ�</h3>
			<ul class="msgtitlelist">
			<!--{loop $_SBLOCK['relativeitem'] $ikey $value}-->
			<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
			<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--{if !empty($ads3['viewsiderad'])}-->
		<div class="block">
			<h3>�����Ƽ�</h3>
			<div style="text-align:center;padding:0.5em;">$ads3['viewsiderad']</div>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">

		<div id="articledetail" class="block topblock">
			<h3 style="font-weight: normal;">
				<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$news[itemid]', 400);" class="more">�Ƽ�������</a>
				<a href="{S_URL}/batch.common.php?action=viewnews&amp;op=up&amp;itemid=$news[itemid]&amp;catid=$news[catid]" class="viewnewsup">��һƪ</a> |
				<a href="{S_URL}/batch.common.php?action=viewnews&amp;op=down&amp;itemid=$news[itemid]&amp;catid=$news[catid]" class="viewnewsdown">��һƪ</a>
			</h3>
			<h1 class="articletitle" style="$news[styletitle]">$news[subject]</h1>
			<p class="articleinfo">
				<span class="articlectrl">
					�ֺ�:&nbsp;
					<a href="javascript:doZoom('12');">С</a>&nbsp;
					<a href="javascript:doZoom('14');">��</a>&nbsp;
					<a href="javascript:doZoom('16');">��</a>&nbsp; |
					<a href="javascript:doPrint();" class="btnprint">��ӡ</a>
				</span>
				<span class="smalltxt">����: #date('Y-n-d H:i', $news["dateline"])# &nbsp;&nbsp; ����: $news[newsauthor] &nbsp;&nbsp; ��Դ: <!--{if !empty($news[newsfromurl])}--><a href="$news[newsfromurl]" target="_blank" title="$news[newsfrom]">$news[newsfrom]</a><!--{else}-->$news[newsfrom]<!--{/if}--> &nbsp;&nbsp; �鿴: $news[viewnum]��</span>
			</p>
		
			<!--{if !empty($news[custom][name])}-->
			<br />
			<div id="custominfo">
				<h5>$news[custom][name]</h5>
				<ul>
				<!--{loop $news[custom][key] $ckey $cvalue}-->
					<li><strong>$cvalue[name]: </strong>$news[custom][value][$ckey]</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<div id="articlebody">

			$news[message]
			<!--{if !empty($ads3['pagecenterad'])}-->
			<div class="content" style="background: none; margin-bottom: 0.5em;">
			$ads3[pagecenterad]
			</div>
			<!--{/if}-->

			<!--{if empty($multipage)}-->
			<!--{loop $news['attacharr'] $attach}-->
			<!--{if $attach['isimage']}-->
			<br /><a href="$attach[url]" target="_blank"><img src="$attach[thumbpath]" alt="$attach[subject]" /></a><br />$attach[subject]<br />
			<!--{else}-->
			<br /><a href="$attach[url]" target="_blank"><img src="{S_URL}/images/base/attachment.gif" alt="$attach[subject]" /><br />$attach[filename](<!--{eval echo formatsize($attach[size]);}-->)</a><br />
			<!--{/if}-->
			<!--{/loop}-->
			<!--{/if}-->
			<br />

			<!--{if !empty($relativetagarr)}-->
			<br /><strong>TAG:</strong> 
			<!--{loop $relativetagarr $value}-->
			<!--{eval $svalue = rawurlencode($value);}-->
			<a href="#action/tag/tagname/$svalue#" target="_blank">$value</a>
			<!--{/loop}-->
			<!--{/if}-->
			
			</div>

			<!--{if $multipage}-->
			<div class="pages">
				$multipage
			</div>
			<!--{/if}-->

		</div>
		
		<!--{if !empty($commentlist)}-->
		<div id="commentlist" class="block">
			<a href="#action/viewcomment/itemid/$news[itemid]#" class="more">�鿴ȫ��$news[replynum]������</a>
			<h3>��������</h3>
			<ul class="commentlist">
				<!--{loop $commentlist $value}-->
				<li>
					<h4>
						<a href="#action/viewcomment/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#" class="more del">ɾ��</a> 
						<!--{if !empty($value['message'])}--><a href="javascript:;" onclick="getQuote($value[cid])" class="more quote">����</a><!--{/if}-->
						<!--{if empty($value[authorid])}-->$value[author]<!--{else}--><a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a><!--{/if}-->
					 	<span class="smalltxt">(#date("Y-n-d H:i:s", $value["dateline"])#, ����: <strong class="price">$value[rates]</strong> )</span>
					</h4>
					<div>
					<!--{if !empty($value['message'])}-->
					$value[message]
					<!--{else}-->
					�� <span style="font-size:16px">$value[rates]</span> ��
					<!--{/if}-->
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			<div class="pages"><div class="xspace-page"><a href="#action/viewcomment/itemid/$news[itemid]#">�鿴ȫ��$news[replynum]������</a></div></div>
		</div>
		<!--{/if}-->

		<div id="xspace-rates" class="block">
			<div id="xspace-rates-bg">
				<div id="xspace-rates-star" class="xspace-rates0">&nbsp;</div>
				<div id="xspace-rates-a">
					<a href="javascript:;" onmouseover="rateHover(-5);" onmouseout="rateOut();" onclick="setRateXML('-5', '$news[itemid]');">-5</a>
					<a href="javascript:;" onmouseover="rateHover(-3);" onmouseout="rateOut();" onclick="setRateXML('-3', '$news[itemid]');">-3</a>
					<a href="javascript:;" onmouseover="rateHover(-1);" onmouseout="rateOut();" onclick="setRateXML('-1', '$news[itemid]');">-1</a>
					<a href="javascript:;" onmouseover="rateHover(0);" onmouseout="rateOut();" onclick="setRateXML('0', '$news[itemid]');">-</a>
					<a href="javascript:;" onmouseover="rateHover(1);" onmouseout="rateOut();" onclick="setRateXML('1', '$news[itemid]');">+1</a>
					<a href="javascript:;" onmouseover="rateHover(3);" onmouseout="rateOut();" onclick="setRateXML('3', '$news[itemid]');">+3</a>
					<a href="javascript:;" onmouseover="rateHover(5);" onmouseout="rateOut();" onclick="setRateXML('5', '$news[itemid]');">+5</a>
				</div>
				<input type="hidden" id="xspace-rates-value" name="rates" value="0" />
			</div>
			<p>���֣�<span id="xspace-rates-tip">0</span></p>
		</div>
		
		<div id="comment" class="block cleanblock">
			<h3>����˵����</h3>
			<form id="postcomm" action="#action/viewcomment/itemid/$news[itemid]/php/1#" method="post">
				<p><label for="message">����:</label><textarea id="message" name="message"  onfocus="showcode()"></textarea></p>
				<!--{if empty($_SCONFIG['noseccode'])}-->
				<p id="seccodeline" class="seccodeline"><label for="seccode">��֤:</label><input type="text" id="seccode" name="seccode" value="" size="20" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="�����壿�����һ��" /></p>
				<!--{/if}-->
				<p><button type="submit" id="submitcomm" name="submitcomm" value="submit" style="margin-left: 2.8em; line-height: 35px; height: 35px; padding: 0 30px; color: #090;">��������</button></p>
				<input type="hidden" id="itemid" name="itemid" value="$news[itemid]" />
			</form>
		</div>
		
	</div>
</div>
<!-- /Content -->

<script language="javascript" type="text/javascript">
<!--
	addMediaAction('articlebody');
	addImgLink("articlebody");
//-->
</script>
<!--{if !empty($ads3['pagemovead']) || !empty($ads3['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads3['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads3['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads3['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template news_footer}
