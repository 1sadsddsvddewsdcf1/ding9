<?exit?>
{template topic_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
$ads[pagecenterad]
</div>
<!--{/if}-->

	<!-- Content���� -->
	<div class="contentR" style="background: none;">
		<!-- �Ҳ� -->
		<div class="sideR">
			<!-- �û���� -->
			<div id="userpanel" class="block topblock">
				<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
			</div>
			<div class="block" style="overflow: hidden;">
				<!--{block name="topic" parameter="dateline/2592000/order/viewnum DESC/limit/0,4/cachetime/0/subjectlen/14/subjectdot/1/cachename/hottopic/tpl/data"}-->
				<h3>����ר��</h3>
				<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hottopic'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
		<!-- /�Ҳ� -->
		<div class="mainarea">
			<div id="hottopic" class="block topblock">
				<h3 id="hottopictabs" class="tabs">
					<a id="toptab" href="javascript:setTab('hottopic','top')" class="tab curtab">�����Ƽ�</a>
					<a id="monthtab" href="javascript:setTab('hottopic','month')" class="tab">�µ����</a>
					<a id="alltab" href="javascript:setTab('hottopic','all')" class="tab">�ܵ����</a>
				</h3>
				<!--�����Ƽ�ר���б�(һ��)-->
				<!--{block name="topic" parameter="top/3,2,1/order/top DESC, id DESC/limit/0,18/cachetime/0/subjectlen/40/subjectdot/1/cachename/toptopic/tpl/data"}-->
				<div id="top" class="tabcontent">
					<ul class="list2col" style="height:188px;">
						<!--{loop $_SBLOCK['toptopic'] $value}-->
						<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--�µ����ר���б�(һ��)-->
				<!--{block name="topic" parameter="dateline/2592000/order/viewnum DESC/limit/0,18/cachetime/0/subjectlen/40/subjectdot/1/cachename/hottopicmonth/tpl/data"}-->
				<div id="month" class="tabcontent" style="display: none;">
					<ul class="list2col" style="height:188px;">
						<!--{loop $_SBLOCK['hottopicmonth'] $value}-->
						<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--�ܵ����ר���б�(ȫ��)-->
				<!--{block name="topic" parameter="order/viewnum DESC/limit/0,18/cachetime/0/subjectlen/40/subjectdot/1/cachename/hottopic/tpl/data"}-->
				<div id="all" class="tabcontent" style="display: none;">
					<ul class="list2col" style="height:188px;">
						<!--{loop $_SBLOCK['hottopic'] $value}-->
						<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
						<!--{/loop}-->
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="contentR">
		<div class="sideR">
			<!--{block name="topic" parameter="catid/0/order/id DESC/limit/0,10/cachetime/0/subjectlen/14/cachename/topiclist/tpl/data"}-->
			<!--{if $_SBLOCK['topiclist']}-->
			<div class="block" style="overflow: hidden;">
				<h3>ר���б�</h3>
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['topiclist'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
		</div>
		<div class="mainarea">
			<div class="blockcategorylist">
			<!--����������ר���б�-->
			<!--{loop $_SBLOCK['category'] $ckey $cat}-->
			<!--{block name="topic" parameter="catid/$cat[subcatid]/order/id DESC/limit/0,10/cachetime/0/subjectlen/40/cachename/topiclist/tpl/data"}-->
			<div class="blockcategory">
				<h3>
					<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
					<a href="#action/category/catid/$cat[catid]#" class="more">����</a>
				</h3>
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['topiclist'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/loop}-->
			</div>
		</div>
	</div>


<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

{template topic_footer}