<?exit?>
{template topic_header}

<!--{if !empty($ads2['pagecenterad'])}-->
<div class="banner">
	$ads2[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->
<div class="contentR">
	<div class="sideR">
	
		<div class="block topblock">
			<h3>$thecat[name]</h3>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{/if}-->
			<!--{block name="category" parameter="upid/$thecat[catid]/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['subarr'] $value}-->
					<li><a href="$value[url]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>
		
		<!--�¶ȵ�����а�-->
		<!--{block name="topic" parameter="catid/$thecat[subcatid]/dateline/2592000/order/viewnum DESC/limit/0,8/cachetime/0/subjectlen/14/subjectdot/1/cachename/hottopicmonth/tpl/data"}-->
		<div class="block">
			<h3>�¶ȵ�����а�</h3>
			<dl>
				<!--{loop $_SBLOCK['hottopicmonth'] $value}-->
				<dt><a href="$value[url]" target="_blank">$value[subject]</a> <span class="smalltxt">($value[viewnum])</span></dt>
				<!--{/loop}-->
			</dl>
		</div>
		
	</div>
	<div class="mainarea">

		<!--��ǰ���������б�-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="topic" parameter="perpage/40/catid/$thecat[subcatid]/order/id DESC/cachename/topiclist/tpl/data"}-->
		<!--{if $_SBLOCK['topiclist']}-->
		<div class="block topblock">
			<h3>ר���б�</h3>
			<ul id="newslist" class="newslist">
				<!--{loop $_SBLOCK['topiclist'] $value}-->
				<li><!--{eval $titlestyle = mktitlestyle($value[styletitle]);}-->
					<a href="$value[url]" target="_blank" style="$titlestyle">$value[subject]</a>
					<span class="smalltxt">(#date("m-d h:m", $value["dateline"])#)</span>
				</li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[topiclist_multipage]}-->
			<div class="pages">
				$_SBLOCK[topiclist_multipage]
			</div>
			<!--{/if}-->
			
		</div>
		<!--{/if}-->
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template topic_footer}