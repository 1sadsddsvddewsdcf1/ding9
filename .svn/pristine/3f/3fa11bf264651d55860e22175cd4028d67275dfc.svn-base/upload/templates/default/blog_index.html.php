<?exit?>
{template blog_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->
<div class="content" style="background: none;">
	<!-- �Ҳ� -->
	<div class="sideR">
		<!-- �û���� -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!-- ͬ�ǿռ� -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<button value="true" type="submit" name="usersearch">ͬ��<br />�ռ�</button>
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
			</form>
		</div>
		
		<!--���¸��¿ռ�-->
		<!--{block name="userspace" parameter="order/u.lastpost DESC/limit/0,12/cachetime/11900/cachename/newspace/tpl/data"}-->
		<div class="block" style="height: 297px; overflow: hidden;">
			<h3>�ռ����</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newspace'] $value}-->
				<li><cite>#date("h:m", $value["lastpost"])# </cite><a href="$value[url]">$value[spacename]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<!-- /�Ҳ� -->
	<!-- ��� -->
	<div class="sideL">

		<!--����ͼ����־-->
		<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/cachetime/13930/cachename/picblog/tpl/data"}-->
		<div id="slideimg" class="block cleanblock topblock" style="height: 205px; overflow: hidden;">
		<!--{if !empty($_SBLOCK['picblog'])}-->
			<script type="text/javascript" language="javascript">
			<!--			
			var xsTextBar = 1; //�Ƿ���ʾ�������ӣ�1Ϊ��ʾ��0Ϊ����ʾ
			var xsPlayBtn = 0; //�Ƿ���ʾ���Ű�ť��1��ʾ��0Ϊ����ʾ
			var xsImgSize = new Array(200,167); //�õ�ͼƬ�ĳߴ磬��ʽΪ������,�߶ȡ�
		
			var xsImgs = new Array();
			var xsImgLinks = new Array();
			var xsImgTexts = new Array();
			
			<!--{eval $i=0;}-->
			<!--{loop $_SBLOCK['picblog'] $key $value}-->
			xsImgs[$i] = "$value[a_thumbpath]";
			xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
			xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
			<!--{eval $i++;}-->
			<!--{/loop}-->
			//-->
			</script>
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		<!--��־ͼƬ�õ�Ƭ ����-->
		
		<!--�����Ķ� ����:һ��֮�ں�������־����-->
		<!--{block name="spaceblog" parameter="dateline/604800/order/i.goodrate DESC/limit/0,9/subjectlen/24/subjectdot/1/cachetime/38000/cachename/weekgoodrate/tpl/data"}-->
		<div id="commendread" class="block boldblock">
			<h3>һ�ܺ�������</h3>
			<ul class="msgtitlelist" style="height: 230px; overflow: hidden;">
			<!--{if !empty($_SBLOCK['weekgoodrate'])}-->
				<!--{loop $_SBLOCK['weekgoodrate'] $value}-->
				<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" title="$value[subjectall]">$value[subject]</a><span class="smalltxt">($value[goodrate])</span></li>
				<!--{/loop}-->
			<!--{/if}-->
			</ul>
		</div>
		
	</div>
	<!-- /��� -->
	<div class="mainarea">
		<!--ͷ���Ķ� ����:һ��֮�ڷ�����/��������-->
		<div id="headline" class="block cleanblock topblock">
			<!--{block name="spaceblog" parameter="dateline/604800/showattach/1/showdetail/1/order/i.replynum DESC/limit/0,1/subjectlen/40/subjectdot/1/messagelen/80/messagedot/1/cachetime/68600/cachename/headblog/tpl/data"}-->
			<!--{if !empty($_SBLOCK['headblog'])}-->
			<!--{loop $_SBLOCK['headblog'] $value}-->
			<!--{if !empty($value['a_thumbpath'])}--><a href="$value[url]" target="_blank"><img src="$value[a_thumbpath]" alt="" /></a><!--{/if}-->
			<strong><a href="$value[url]" target="_blank">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<!--���·�������־-->
		<!--{block name="spaceblog" parameter="order/i.dateline DESC/limit/0,18/showspacename/1/subjectlen/40/subjectdot/1/cachetime/14800/cachename/coolblog/tpl/data"}-->
		<div id="focus">
			<ul class="msgtitlelist">
				<!--{if !empty($_SBLOCK['coolblog'])}-->
					<!--{loop $_SBLOCK['coolblog'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div>
	</div>
</div>

<!-- �ռ�֮�� -->
<div id="blogs" class="block">
	<h3 id="blogstabs" class="tabs">
		<a id="spacestartab" href="javascript:setTab('blogs','spacestar');" class="tab curtab">�ռ�֮��</a>
		<a id="spaceranktab" href="javascript:setTab('blogs','spacerank');" class="tab">�ռ�������</a>
	</h3>
	<div id="spacestar" class="tabcontent">
		<!--{block name="userspace" parameter="isstar/1/showdetail/1/order/u.lastpost DESC/limit/0,8/cachetime/94400/cachename/spacestar/tpl/data"}-->
		<ul class="imgthumblist" style="margin: 10px 0 6px 10px">
			<!--{loop $_SBLOCK['spacestar'] $value}-->
			<li class="smallthumb">
				<div><a href="$value[url]"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
				<p><a href="$value[url]">$value[username]</a></p>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
	<div id="spacerank" class="tabcontent" style="display: none;">
		<!--{block name="userspace" parameter="order/u.spaceallnum DESC/limit/0,8/showdetail/1/cachetime/84400/cachename/superspace/tpl/data"}-->
		<ul class="imgthumblist" style="margin: 10px 0 6px 10px">
			<!--{loop $_SBLOCK['superspace'] $value}-->
			<li class="smallthumb">
				<div><a href="$value[url]"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
				<p><a href="$value[url]">$value[username]</a></p>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
</div>

<div class="content">
	<!-- �Ҳ��� -->
	<div class="sideR">
		<!--�����û��ռ������б�-->
		<!--{block name="userspace" parameter="lastpost/604800/order/u.spaceblognum DESC/limit/0,10/cachetime/19900/cachename/newspace/tpl/data"}-->
		<div id="hotspace" class="block stat" style="height: 252px;">
			<a href="#action/spaces#" class="more">���пռ�</a>
			<h3>һ���ȵ�ռ�</h3>
			<ol>
				<!--{loop $_SBLOCK['newspace'] $value}-->
				<li><em>$value[spaceblognum] </em><a href="$value[url]">$value[spacename]</a></li>
				<!--{/loop}-->
			</ol>
		</div>
	</div>
	<div class="sideL">
	
		<!--������־TAG�б�-->
		<!--{block name="tag" parameter="order/spaceblognum DESC/limit/0,20/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block boldblock">
			<h3>����TAG</h3>
			<div style="height: 213px; line-height: 1.98em;">
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spaceblognum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
	</div>
	<div class="mainarea">
		<div id="hotarticle" class="block">
			<h3 id="hotarticletabs" class="tabs">
				<a id="daytab" href="javascript:setTab('hotarticle','day')" class="tab curtab">�ܵ����</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week')" class="tab">�µ����</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all')" class="tab">�ܵ����</a>
			</h3>
			<!--վ������BLOG�б�(һ��)-->
			<!--{block name="spaceblog" parameter="dateline/604800/order/i.viewnum DESC/limit/0,10/cachetime/65400/subjectlen/40/subjectdot/1/cachename/hotarticleweek/tpl/data"}-->
			<div id="day" class="tabcontent">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotarticleweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt" title="����$value[replynum]������">($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ������BLOG�б�(һ��)-->
			<!--{block name="spaceblog" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,10/cachetime/77200/subjectlen/40/subjectdot/1/cachename/hotarticlemonth/tpl/data"}-->
			<div id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotarticlemonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt" title="����$value[replynum]������">($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ������BLOG�б�(ȫ��)-->
			<!--{block name="spaceblog" parameter="order/i.viewnum DESC/limit/0,10/cachetime/87400/subjectlen/40/subjectdot/1/cachename/hotarticle/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotarticle'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt" title="����$value[replynum]������">($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
</div>

<!--ͼƬ��־��ʾ-->
<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.lastpost DESC/subjectlen/14/subjectdot/1/limit/0,6/cachetime/8000/cachename/picblog/tpl/data"}-->
<div class="block">
	<ul class="imgthumblist">
	<!--{loop $_SBLOCK['picblog'] $value}-->
		<li class="list1line"><div><a href="$value[url]" title="$value[subject]"><img src="$value[a_thumbpath]" alt="$value[subject]" /></a></div><p><a href="$value[url]">$value[subject]</a></p></li>
	<!--{/loop}-->
	</ul>
</div>

<div class="contentR">
	<div class="sideR">

		<!--�������ռ�-->
		<!--{block name="userspace" parameter="order/u.dateline DESC/limit/0,15/cachetime/11900/cachename/lastspace/tpl/data"}-->
		<div class="block">
			<h3>�������ռ�</h3>
			<dl>
				<!--{loop $_SBLOCK['lastspace'] $value}-->
				<dt><a href="$value[url]">$value[spacename]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></dt>
				<!--{/loop}-->
			</dl>
		</div>
		
		<!--վ������BLOG�б�(һ��)-->
		<!--{block name="spaceblog" parameter="lastpost/604800/order/i.replynum DESC/limit/0,10/cachetime/15400/subjectlen/40/subjectdot/1/cachename/replyhot/tpl/data"}-->
		<div class="block">
			<h3>һ�������ȵ�</h3>
			<dl>
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<dt><a href="$value[url]">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></dt>
				<!--{/loop}-->
			</dl>
		</div>
	
		<!--���۸���-->
		<!--{block name="spaceblog" parameter="order/i.lastpost DESC/limit/0,10/cachetime/11000/cachename/newblog/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>���۸���</h3>
			<dl>
				<!--{loop $_SBLOCK['newblog'] $value}-->
				<dt><a href="$value[url]">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></dt>
				<!--{/loop}-->
			</dl>
		</div>

	</div>
	<div class="mainarea" style="padding-bottom: 6px;">
		<div class="blockcategorylist">
		<!--������������־�б�-->
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spaceblog" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/34/cachename/bloglist/tpl/data"}-->
		<div class="blockcategory">
			<h3>
				<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
				<a href="#action/category/catid/$cat[catid]#" class="more">����</a>
			</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['bloglist'] $value}-->
				<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/loop}-->
		</div>
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template blog_footer}