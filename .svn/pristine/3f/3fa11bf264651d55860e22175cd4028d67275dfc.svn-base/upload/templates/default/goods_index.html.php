<?exit?>
{template goods_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->
<div class="contentR">
	<div class="sideR">
		<!-- �û���� -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!-- ͬ����Ʒ -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<button value="true" type="submit" name="goodscitysearch">ͬ��<br />��Ʒ</button>
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
			</form>
		</div>
	</div>
	<div class="mainarea">
		
		<!-- һ���ȵ�����Ʒ -->
		<div class="block topblock" style="height: 178px; overflow: hidden;">
			<h3>һ���ȵ�����Ʒ</h3>
			<!--{block name="spacegoods" parameter="dateline/604800/order/i.viewnum DESC/limit/0,12/cachetime/45400/subjectlen/40/subjectdot/1/showdetail/1/cachename/spacialgoods/tpl/data"}-->
			<div>
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['spacialgoods'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" title="{$value[subjectall]} {$value[price]}Ԫ {$value[province]}{$value[city]}">$value[subject]</a> <span class="smalltxt">($value[price]Ԫ)</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<!-- �¶ȵ���ȵ� -->
		<!--{block name="spacegoods" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,2/cachetime/83400/subjectlen/30/showdetail/1/cachename/promotion/tpl/data"}-->
		<div class="block" style="height: 186px; overflow: hidden;">
			<h3>�¶ȵ���ȵ�</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['promotion'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[thumb]" width="78" height="78" alt="$value[subjectall]" /></a>
					<p><a href="$value[url]" target="_blank">$value[subject]</a></p>
					<p class="smalltxt">�۸�: <strong class="price">$value[price]Ԫ</strong></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="mainarea">
	
		<!--�����ϼ���Ʒ-->
		<!--{block name="spacegoods" parameter="order/i.dateline DESC/limit/0,5/subjectlen/14/subjectdot/1/showdetail/1/cachetime/11900/cachename/weekcommendgoods/tpl/data"}-->
		<div class="block">
			<h3>�����ϼ���Ʒ</h3>
			<ul class="avatarlist" style="height: 160px; overflow: hidden;">
				<!--{loop $_SBLOCK['weekcommendgoods'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
					<ul>
						<li><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}Ԫ {$value[province]}{$value[city]}">$value[subject]</a></li>
						<li class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></li>
						<li>�۸�: <strong class="price">$value[price]Ԫ</strong></li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<div class="block" style="height: 540px; overflow: hidden;">
			<h3>����������Ʒ</h3>
			<!--{block name="spacegoods" parameter="order/i.lastpost DESC/limit/0,11/showdetail/1/cachetime/12900/cachename/newgoods/tpl/data"}-->
			<dl>
				<!--{loop $_SBLOCK['newgoods'] $value}-->
				<dt><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}Ԫ {$value[province]}{$value[city]}">$value[subject]</a></dt>
				<dd>����:<a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> / �۸�: $value[price]Ԫ</dd>
				<!--{/loop}-->
			</dl>
		</div>
	</div>
	<div class="mainarea">
	
		<!--�ȵ���Ʒ�б�-->
		<div id="hotgoods" class="block" style="height: 540px; overflow: hidden;">
			<h3 id="hotgoodstabs" class="tabs">
				<a id="weektab" href="javascript:setTab('hotgoods','week')" class="tab curtab">�����ȵ�</a>
				<a id="monthtab" href="javascript:setTab('hotgoods','month')" class="tab">�����ȵ�</a>
				<a id="alltab" href="javascript:setTab('hotgoods','all')" class="tab">�ȵ�����</a>
			</h3>
			<!--����������Ʒ(һ��)-->
			<!--{block name="spacegoods" parameter="dateline/604800/order/i.replynum DESC/limit/0,8/cachetime/64400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotgoodsweek/tpl/data"}-->
			<div id="week" class="tabcontent">
				<ul class="coverlist">
					<!--{loop $_SBLOCK['hotgoodsweek'] $value}-->
					<li>
						<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}Ԫ {$value[province]}{$value[city]}">$value[subject]</a></h4></li>
							<li class="smalltxt">�۸�: <strong class="price">$value[price]Ԫ</strong></li>
							<li class="smalltxt">����: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> <span class="smalltxt">($value[province])</span><!--{/if}--></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}-->
								<!--{if $value[goodrate]}--><span class="goodrate">����: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--����������Ʒ(һ��)-->
			<!--{block name="spacegoods" parameter="dateline/2592000/order/i.replynum DESC/limit/0,8/cachetime/78400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotgoodsmonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="coverlist">
					<!--{loop $_SBLOCK['hotgoodsmonth'] $value}-->
					<li>
						<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}Ԫ {$value[province]}{$value[city]}">$value[subject]</a></h4></li>
							<li class="smalltxt">�۸�: <strong class="price">$value[price]Ԫ</strong></li>
							<li class="smalltxt">����: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> <span class="smalltxt">($value[province])</span><!--{/if}--></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}-->
								<!--{if $value[goodrate]}--><span class="goodrate">����: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--����������Ʒ(ȫ��)-->
			<!--{block name="spacegoods" parameter="order/i.replynum DESC/limit/0,8/cachetime/89400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotgoods/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="coverlist">
					<!--{loop $_SBLOCK['hotgoods'] $value}-->
					<li>
						<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}Ԫ {$value[province]}{$value[city]}">$value[subject]</a></h4></li>
							<li class="smalltxt">�۸�: <strong class="price">$value[price]Ԫ</strong></li>
							<li class="smalltxt">����: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> <span class="smalltxt">($value[province])</span><!--{/if}--></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a><!--{/if}-->
								<!--{if $value[goodrate]}--><span class="goodrate">����: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template goods_footer}