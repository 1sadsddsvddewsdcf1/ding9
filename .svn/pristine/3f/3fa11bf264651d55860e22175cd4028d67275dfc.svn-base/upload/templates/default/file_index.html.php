<?exit?>
{template file_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content���� -->
<div class="contentR">
	<div class="sideR">
		<!-- �û���� -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!--{block name="spacefile" parameter="order/i.dateline DESC/limit/0,9/cachetime/13400/cachename/newfile/tpl/data"}-->
		<div class="block" style="height: 471px; overflow: hidden;">
			<h3>���·����ļ�</h3>
			<dl>
				<!--{loop $_SBLOCK['newfile'] $value}-->
				<dt><a href="$value[url]" target="_blank">$value[subject]</a></dt>
				<dd><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / #date("Y-m-d", $value["dateline"])#</dd>
				<!--{/loop}-->
			</dl>
		</div>
		
	</div>
	<div class="mainarea">
		
		<div id="hotfile" class="block topblock" style="height: 240px; overflow: hidden;">
			<h3 id="hotfiletabs" class="tabs">
				<a id="weektab" href="javascript:setTab('hotfile','week')" class="tab curtab">���ȵ�</a>
				<a id="monthtab" href="javascript:setTab('hotfile','month')" class="tab">���ȵ�</a>
				<a id="alltab" href="javascript:setTab('hotfile','all')" class="tab">������</a>
			</h3>
			<!--վ�������б�(һ��)-->
			<!--{block name="spacefile" parameter="dateline/604800/order/i.replynum DESC/limit/0,18/cachetime/55400/subjectlen/40/subjectdot/1/cachename/hotfileweek/tpl/data"}-->
			<div  id="week" class="tabcontent">
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['hotfileweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ�������б�(һ��)-->
			<!--{block name="spacefile" parameter="dateline/2592000/order/i.replynum DESC/limit/0,18/cachetime/97200/subjectlen/40/subjectdot/1/cachename/hotfilemonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['hotfilemonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ�������б�(ȫ��)-->
			<!--{block name="spacefile" parameter="order/i.replynum DESC/limit/0,18/cachetime/97900/subjectlen/40/subjectdot/1/cachename/hotfile/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['hotfile'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>

		<!--�����ļ��б�-->
		<div id="commend" class="block">
			<h3 id="commendtabs" class="tabs">
				<a id="commendfiletab" href="javascript:setTab('commend','commendfile')" class="tab curtab">�ܺ�������</a>
				<a id="spacialfiletab" href="javascript:setTab('commend','spacialfile')" class="tab">�ܵ������</a>
			</h3>
			<!--{block name="spacefile" parameter="dateline/604800/order/i.goodrate DESC/limit/0,3/cachetime/64400/showdetail/1/messagelen/65/messagedot/1/cachename/commendfile/tpl/data"}-->
			<div id="commendfile" class="tabcontent">
				<ul class="messagelist" style="height: 300px; overflow: hidden;">
					<!--{loop $_SBLOCK['commendfile'] $value}-->
					<li>
						<h4>
							<em class="smalltxt" title="����$value[replynum]������">($value[replynum])</em>
							<a href="$value[url]" target="_blank">$value[subject]</a>
						</h4>
						<p>$value[message]...</p>
						<p class="smalltxt">
							<a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a> �ϴ���#date("Y-m-d", $value["dateline"])#
							<!--{if $value['filesize']}-->, ��С: $value[filesize] $value[filesizeunit]<!--{/if}-->
							<!--{if $value['system']}-->, ����ƽ̨: $value[system]<!--{/if}-->
							<!--{if $value['permission']}-->, ��Ȩ��ʽ: $value[permission]<!--{/if}-->
						</p>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{block name="spacefile" parameter="dateline/604800/order/i.viewnum DESC/limit/0,3/cachetime/74400/showdetail/1/messagelen/65/messagedot/1/cachename/spacialfile/tpl/data"}-->
			<div id="spacialfile" class="tabcontent" style="display: none;">
				<ul class="messagelist" style="height: 300px; overflow: hidden;">
					<!--{loop $_SBLOCK['spacialfile'] $value}-->
					<li>
						<h4>
							<em class="smalltxt" title="����$value[replynum]������">($value[replynum])</em>
							<a href="$value[url]" target="_blank">$value[subject]</a>
						</h4>
						<p>$value[message]...</p>
						<p class="smalltxt">
							<a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a> �ϴ���#date("Y-m-d", $value["dateline"])#
							<!--{if $value['filesize']}-->, ��С: $value[filesize] $value[filesizeunit]<!--{/if}-->
							<!--{if $value['system']}-->, ����ƽ̨: $value[system]<!--{/if}-->
							<!--{if $value['permission']}-->, ��Ȩ��ʽ: $value[permission]<!--{/if}-->
						</p>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<!--{block name="spacefile" parameter="order/i.lastpost DESC/limit/0,15/cachetime/13400/cachename/hotreplyfile/tpl/data"}-->
		<div class="block">
			<h3>���±����ļ�</h3>
			<dl>
				<!--{loop $_SBLOCK['hotreplyfile'] $value}-->
				<dt><a href="$value[url]" target="_blank">$value[subject]</a></dt>
				<dd><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / #date("Y-m-d", $value["dateline"])#</dd>
				<!--{/loop}-->
			</dl>
		</div>
	</div>
	<div class="mainarea">
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
		<!--{block name="spacefile" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/cachename/sublist/tpl/data"}-->
		<!--{if $_SBLOCK['sublist']}-->
		<div class="blockcategory">
			<h3>
				<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
				<a href="#action/category/catid/$cat[catid]#" class="more">����</a>
			</h3>
			<ul class="msgtitlelist">
			<!--{loop $_SBLOCK['sublist'] $value}-->
				<li>
					<cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite> <a href="$value[url]" target="_blank">$value[subject]</a>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		</div>
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template file_footer}