<?exit?>
{template site_header}

<div id="navigation" class="simplepage">
	<p>����λ�ã�
		<a href="{S_URL}/">��ҳ</a>
		&gt;&gt; �鿴����
	</p>
	<h2>�鿴����</h2>
</div>

<div class="contentR">
	<div class="sideR">

		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="spacenews" parameter="catid/$item[catid]/dateline/2592000/order/i.replynum DESC/limit/0,10/cachetime/28800/cachename/hotnews/tpl/data"}-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>�¶������ȵ�</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">
		<div id="commentlist" class="block topblock">
			<h1 class="articletitle">����: <a href="#action/viewnews/itemid/$item[itemid]#">$item[subject]</a></h1>
			<p class="articleinfo smalltxt" style="text-align: center;">
				�鿴��: $item[viewnum] / 
				������: $item[replynum] / 
				����: $item[goodrate] / 
				����: $item[badrate]
			</p>
			
			<ul class="commentlist">
				<!--{loop $iarr $value}-->
				<li>
					<h4>
						<a href="#action/viewcomment/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#" class="more del">ɾ��</a> 
						<a href="javascript:;" onclick="getQuote($value[cid])" class="more quote">����</a>
						<!--{if empty($value[authorid])}-->$value[author]<!--{else}--><a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a><!--{/if}-->
					 	<span class="smalltxt">(#date("Y-n-d H:i:s", $value["dateline"])#, ����: <strong>$value[rates]</strong> )</span>
					</h4>
					<div>
					<!--{if empty($value['message'])}-->
					�� <span style="font-size:16px">$value[rates]</span> ��
					<!--{else}-->
					$value[message]
					<!--{/if}-->
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $multipage}-->
			<div class="pages">
				$multipage
			</div>
			<!--{/if}-->
		</div>
		
		<div id="xspace-rates" class="block">
			<div id="xspace-rates-bg">
				<div id="xspace-rates-star" class="xspace-rates0">&nbsp;</div>
				<div id="xspace-rates-a">
					<a href="javascript:;" onmouseover="rateHover(-5);" onmouseout="rateOut();" onclick="setRateXML('-5', '$item[itemid]');">-5</a>
					<a href="javascript:;" onmouseover="rateHover(-3);" onmouseout="rateOut();" onclick="setRateXML('-3', '$item[itemid]');">-3</a>
					<a href="javascript:;" onmouseover="rateHover(-1);" onmouseout="rateOut();" onclick="setRateXML('-1', '$item[itemid]');">-1</a>
					<a href="javascript:;" onmouseover="rateHover(0);" onmouseout="rateOut();" onclick="setRateXML('0', '$item[itemid]');">-</a>
					<a href="javascript:;" onmouseover="rateHover(1);" onmouseout="rateOut();" onclick="setRateXML('1', '$item[itemid]');">+1</a>
					<a href="javascript:;" onmouseover="rateHover(3);" onmouseout="rateOut();" onclick="setRateXML('3', '$item[itemid]');">+3</a>
					<a href="javascript:;" onmouseover="rateHover(5);" onmouseout="rateOut();" onclick="setRateXML('5', '$item[itemid]');">+5</a>
				</div>
				<input type="hidden" id="xspace-rates-value" name="rates" value="0" />
			</div>
			<p>���֣�<span id="xspace-rates-tip">0</span></p>
		</div>
		
		<div id="comment" class="block cleanblock">
			<h3>����˵����</h3>
			<form id="postcomm" action="#action/viewcomment/itemid/$item[itemid]/php/1#" method="post">
				<p><label for="message">����:</label><textarea id="message" name="message" onfocus="showcode()" onkeydown="ctlent(event,'postcomm');"></textarea></p>
				<!--{if empty($_SCONFIG['noseccode'])}-->
				<p class="seccodeline"><label for="seccode">��֤:</label><input type="text" id="seccode" name="seccode" value="" size="20" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="�����壿�����һ��" /></p>
				<!--{/if}-->
				<p><button type="submit" id="submitcomm" name="submitcomm" value="submit" style="margin-left: 2.8em; line-height: 35px; height: 35px; padding: 0 30px; color: #090;">��������</button></p>
				<input type="hidden" id="itemid" name="itemid" value="$item[itemid]" />
			</form>
		</div>
	</div>
</div>

{template site_footer}