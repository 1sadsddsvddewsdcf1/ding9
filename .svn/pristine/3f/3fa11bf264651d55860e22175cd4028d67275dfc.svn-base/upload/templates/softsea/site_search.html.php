<?exit?>
{template site_header}
<script type="text/javascript" src="{S_URL}/include/js/city.js"></script>
<div id="menu"><h1>����</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>

<!--{if empty($iarr)}-->
<div id="search" class="tabblock">
	<h3 id="searchtabs" class="tabs">
		<a id="subjecttab" href="javascript:setTab('search','subject')" class="tab curtab">����</a>
		<a id="authortab" href="javascript:setTab('search','author')" class="tab">����</a>
		<a id="messagestrtab" href="javascript:setTab('search','messagestr')" class="tab">����</a>
		<a id="usertab" href="javascript:setTab('search','user')" class="tab">�û�</a>
		<a id="grouptab" href="javascript:setTab('search','group')" class="tab">Ȧ��</a>
		<a id="bbs" href="{B_URL}/search.php" class="tab" target="_blank">��̳</a>
	</h3>
	<!--��������-->
	<div id="subject" class="tabcontent">
		<form action="{S_URL}/batch.search.php" method="post">
			<label for="searchkey">����</label><input type="text" name="searchkey" id="searchkey" />&nbsp;
			<select name="type">
				<option value="">ȫ��</option>
				<!--{loop $channels['types'] $value}-->
					<option value="$value[nameid]">$value[name]</option>
				<!--{/loop}-->
			</select>&nbsp;<button type="submit" name="subjectsearch" value="true">����</button>
		</form>
	</div>
	<!--��������-->
	<div id="author" class="tabcontent" style="display: none;">
		<form action="{S_URL}/batch.search.php" method="post">
			<label for="searchkey1">����</label><input type="text" name="searchkey" id="searchkey1" />&nbsp;
			<select name="type">
				<option value="">ȫ��</option>
				<!--{loop $channels['types'] $value}-->
					<option value="$value[nameid]">$value[name]</option>
				<!--{/loop}-->
			</select>&nbsp;<button type="submit" name="authorsearch" value="true">����</button>
		</form>
	</div>
	<!--ȫ�ļ���-->
	<div id="messagestr" class="tabcontent" style="display: none;">
		<form action="{S_URL}/batch.search.php" method="post">
			<label for="searchkey2">����</label><input type="text" name="searchkey" id="searchkey2" />&nbsp;
			<select name="type">
			<!--{loop $channels['types'] $value}-->
				<option value="$value[nameid]">$value[name]</option>
			<!--{/loop}-->
			</select>&nbsp;<button type="submit" name="messagesearch" value="true">����</button>
		</form>
	</div>
	<!--�˼���-->
	<div id="user" class="tabcontent" style="display: none;">
		<form id="searchuserform" action="{S_URL}/batch.search.php" method="post">
			<label for="spacename">��������</label><input type="text" name="spacename" id="spacename" />&nbsp;
			<div id="more" style="display:none;">
				<div>
					<label for="username">�û���</label><input type="text" name="username" id="username" />
				</div>
				<div>
					<label for="province">���ڵ�</label>
					<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script>
					<script language="javascript" type="text/javascript">showcity('city', '');</script>
				</div>
				$requiredtext
				$requiredselect
			</div>
			<button type="submit" name="usersearch" value="true">����</button>
			<script language="javascript" type="text/javascript">
			<!--
				function setUserClass() {
					var userDiv = getbyid('searchuserform');
					if ( userDiv.className == '' ) {
						userDiv.className = 'open';
					} else {
						userDiv.className = '';
					}
				}
				function setText(obj) {
					if (obj.innerHTML=='[�߼�����]') {
						obj.innerHTML='[�رո߼�����]';
					} else {
						obj.innerHTML='[�߼�����]';
					}
					
				}
			//-->
			</script>
			<span onclick="display('more');setUserClass();setText(this);" style="cursor: pointer;">[�߼�����]</span>
		</form>
	</div>
	<!--Ȧ�Ӽ���-->
	<div id="group" class="tabcontent" style="display: none;">
		<form action="{S_URL}/batch.search.php" method="post">
			<label for="searchkey2">Ȧ����</label><input type="text" name="searchkey" id="searchkey2" />&nbsp;
			<button type="submit" name="groupsearch" value="true">����</button>
		</form>
	</div>
	
</div>
<!--{else}-->
<div class="block topblock">
	<a href="{S_URL}/batch.search.php" class="more">��������</a>
	<h3>
		<strong>�������</strong>
	</h3>
	<ul class="msgtitlelist">
		<!--{loop $iarr $value}-->
			<!--{if !empty($usersearch)}-->
				<li><a href="$value[url]" target="_blank">[{$value[username]}]$value[spacename]</a></li>
			<!--{elseif !empty($groupsearch)}-->
				<li><a href="$value[url]" target="_blank">$value[groupname]</a> (<a href="{S_URL}/?$value[uid]" target="_blank">$value[username]</a>, #date("Y-n-d H:i:s", $value["dateline"])#)</li>
			<!--{else}-->
				<li>[{$lang[$value[type]]}] <a href="$value[url]" target="_blank">$value[subject]</a> (<a href="{S_URL}/?$value[uid]" target="_blank">$value[username]</a>, #date("Y-n-d H:i:s", $value["dateline"])#)</li>
			<!--{/if}-->
		<!--{/loop}-->
	</ul>
</div>
<div class="pagediv">
	$multipage
</div>
<!--{/if}-->
</div>
<div class="side">
		<!--{block name="tag" parameter="order/spacenewsnum DESC/limit/0,18/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>����TAG</h3>
			<div style="height: 201px;">
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacenewsnum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
	</div>
</div>

{template site_footer}