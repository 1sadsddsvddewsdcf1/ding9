<?exit?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset]" />
<title>$title  $_SCONFIG[seotitle]- Powered by SupeSite</title>
<meta name="keywords" content="$keywords $_SCONFIG[seokeywords]" />
<meta name="description" content="$description $_SCONFIG[seodescription]" />
<link rel="stylesheet" type="text/css" href="{S_URL}/templates/$_SCONFIG[template]/css/style.css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<div id="wrap">
	<div id="header">
		<table border="0" cellpadding="0" cellspacing="0" id="headertab">
			<tr>
				<td id="logo">
					<a href="{S_URL}/"><img src="{S_URL}/templates/$_SCONFIG[template]/images/logo.jpg" alt="$_SCONFIG[sitename]" style="border:none;" /></a>
				</td>
				<td id="topmenu">
					<ul>
						<!--{loop $channels['menus'] $key $value}-->
						<li><a href="$value[url]" class="$key">$value[name]</a></li>
						<!--{/loop}-->
					</ul>
				</td>
			</tr>
		</table>
	</div>
	
	<div id="menu">
		<!--{block name="bbsforum" parameter="type/forum/allowblog/1/order/displayorder/limit/0,100/cachetime/14400/cachename/forumarr/tpl/data"}-->
		<ul>
			<!--{loop $_SBLOCK['forumarr'] $value}-->
			<li><a href="$value[url]">$value[name]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
