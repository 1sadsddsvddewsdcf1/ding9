<?exit?>
{template spaces_header}

<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>

		<div class="block">
			<h3><strong>���½�ӡ</strong></h3>
			<ul class="thumbmsglist thumb2col">
				<!--{if empty($trackarr)}-->
				<li>���ڻ�û�������½�ӡ</li>
				<!--{else}-->
				<!--{loop $trackarr $value}-->
				<li>
					<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[username]������ #date("Y-n-d", $value["dateline"])# ���ʹ�������" /></a></p>
					<div>
					<p><a href="$value[url]" target="_blank">$value[username]</a></p>
					<p>#date("Y-n-d", $value["dateline"])#</p>
					</div>
				</li>
				<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div>
	</div>
	<div class="side">
		
		<div class="block blockG">
			<h1>ͬ�ǿռ�</h1>
		</div>

		<!-- ͬ�ǿռ� -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
				<button value="true" type="submit" name="usersearch">ͬ�ǿռ�</button>
			</form>
		</div>
		
		<!--һ�ܸ������а�-->
		<!--{block name="userspace" parameter="lastpost/604800/limit/0,10/order/u.viewnum DESC/cachetime/29800/cachename/hotlist/tpl/data"}-->
		<div class="block">
			<h3>һ�ܸ������а�</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[spacename]</a>
					<span class="smalltxt"><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>
<!-- /Content -->

{template site_footer}