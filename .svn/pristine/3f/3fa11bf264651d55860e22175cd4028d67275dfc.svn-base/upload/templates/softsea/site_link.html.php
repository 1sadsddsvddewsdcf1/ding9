<?exit?>
{template site_header}
<div id="menu"><h1>��������</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<!-- ���� -->
		<!--{block name="friendlink" parameter="order/displayorder/limit/0,100/cachetime/11600/namelen/16/cachename/friendlink/tpl/data"}-->
		<!--{eval $imglink=$txtlink="";}-->
		<!--{loop $_SBLOCK['friendlink'] $value}-->
		<!--{if $value[logo]}-->
		<!--{eval $imglink .="<li><a href=\"".$value[url]."\" target=\"_blank\"><img src=\"".$value[logo]."\" alt=\"".$value[description]."\" /></a></li>";}-->
		<!--{else}-->
		<!--{eval $txtlink .= "<li><a href=\"".$value[url]."\" title=\"".$value[description]."\" target=\"_blank\">".$value[name]."</a></li>";}-->
		<!--{/if}-->
		<!--{/loop}-->
		<div id="friendlink">
			<ul class="imglink">
			$imglink
			</ul>
			<ul>
			$txtlink
			</ul>
		</div>
	</div>
	<div class="side">
		<!--{block name="tag" parameter="order/spacenewsnum DESC/limit/0,18/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>����TAG</h3>
			<div>
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacenewsnum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
	</div>
</div>

{template site_footer}