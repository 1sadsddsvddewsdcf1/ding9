<?exit?>
<!--{eval include template($type."_header");}-->
<!--{eval $ads3 = getad('system', $type, '3')}-->
<link id="commonstyle" rel="stylesheet" type="text/css" href="{S_URL}/css/space.css" />

<!--{if !empty($ads3['pageheadad'])}-->
<div class="adbanner">
	$ads3[pageheadad]
</div>
<!--{/if}-->
	
<!-- Content���� -->
<div class="content topcontent">

	<div class="mainarea">
				
		<!--{if !empty($showtplfile)}-->
		<div id="show"><!--{eval include template($showtplfile, 1);}--></div>
		<!--{/if}-->
		
	</div>

	<div class="side">

		<div class="block topblock">
			<h3>��������</h3>
			<div id="avatar" class="xspace-sideblock"><div id="xspace-avatar"><a href="#uid/$uid/action/viewpro/showpro/1#"><img src="$space[photo]" alt="$space[username]" class="xspace-imgstyle" /></a>
				<p><a href="#uid/$uid#">$space[username]</a></p></div></div>
		</div>

		<!--{if !empty($ads3['viewsiderad'])}-->
		<div class="block">
			<h3>�����Ƽ�</h3>
			<div style="text-align:center;padding:0.5em;">$ads3['viewsiderad']</div>
		</div>
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads3['pagefootad'])}-->
<div class="adbox">$ads3[pagefootad]</div>
<!--{/if}-->

<script language="javascript" type="text/javascript">
<!--
	addMediaAction('articlebody');
	addImgLink("articlebody");
//-->
</script>
<!--{if !empty($ads3['pagemovead']) || !empty($ads3['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads3['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads3['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads3['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}
