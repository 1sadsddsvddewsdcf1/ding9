<?exit?>
{template file_header}
<!--{eval $ads = getad('system', 'file', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<div id="hotfile" class="tabblock" style="height: 323px; overflow: hidden;">
			<h3 id="hotfiletabs" class="tabs">
				<a id="weektab" href="javascript:setTab('hotfile','week')" class="tab curtab">�����ȵ�</a>
				<a id="monthtab" href="javascript:setTab('hotfile','month')" class="tab">�����ȵ�</a>
				<a id="alltab" href="javascript:setTab('hotfile','all')" class="tab">�ȵ�������</a>
			</h3>
			<!--վ�������б�(һ��)-->
			<!--{block name="spacefile" parameter="dateline/604800/order/i.replynum DESC/limit/0,26/cachetime/55400/subjectlen/36/subjectdot/1/cachename/hotfileweek/tpl/data"}-->
			<div  id="week" class="tabcontent">
				<ul class="msgtitlelist list2col linelist">
					<!--{loop $_SBLOCK['hotfileweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ�������б�(һ��)-->
			<!--{block name="spacefile" parameter="dateline/2592000/order/i.replynum DESC/limit/0,26/cachetime/97200/subjectlen/36/subjectdot/1/cachename/hotfilemonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist list2col linelist">
					<!--{loop $_SBLOCK['hotfilemonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ�������б�(ȫ��)-->
			<!--{block name="spacefile" parameter="order/i.replynum DESC/limit/0,26/cachetime/97900/subjectlen/36/subjectdot/1/cachename/hotfile/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist list2col linelist">
					<!--{loop $_SBLOCK['hotfile'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">ȫ��</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" name="subjectsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!--{block name="spacefile" parameter="order/i.dateline DESC/limit/0,7/subjectlen/30/subjectdot/1/cachetime/13400/cachename/newfile/tpl/data"}-->
		<div class="block" style="height: 200px; overflow: hidden;">
			<h3>�����ļ�</h3>
			<ul>
				<!--{loop $_SBLOCK['newfile'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[subject]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
		<!--{block name="spacefile" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/cachename/sublist/tpl/data"}-->
		<!--{if $_SBLOCK['sublist']}-->
		<div class="blockcategory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="msgtitlelist">
			<!--{loop $_SBLOCK['sublist'] $value}-->
			<li>
				<cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite> <a href="$value[url]" target="_blank">$value[subject]</a>
			</li>
			<!--{/loop}-->
			<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		</div>
	</div>
	<div class="side">
		<!--{block name="spacefile" parameter="order/i.lastpost DESC/limit/0,15/subjectlen/30/subjectdot/1/cachetime/13400/cachename/hotreplyfile/tpl/data"}-->
		<div class="block">
			<h3>���±����ļ�</h3>
			<ul>
				<!--{loop $_SBLOCK['hotreplyfile'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[subject]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}