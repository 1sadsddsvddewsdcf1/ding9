<?exit?>
{template group_header}
<!--{eval $ads = getad('system', 'group', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--�������-->
		<!--{block name="group" parameter="order/g.lastpost DESC/limit/0,5/cachetime/9900/cachename/updategroup/tpl/data"}-->
		<div class="block topblock">
			<h3>�������</h3>
			<ul class="imagelist" style="height: 140px; overflow: hidden;">
				<!--{loop $_SBLOCK['updategroup'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<p><a href="$value[url]" target="_blank" title="$value[groupname]">$value[groupname]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<div id="infos" class="tabblock" style="height: 240px; overflow: hidden;">
			<h3 id="infostabs" class="tabs">
				<a id="newinfotab" href="javascript:setTab('infos','newinfo');" class="tab curtab">����Ȧ������</a>
				<a id="hotinfotab" href="javascript:setTab('infos','hotinfo');" class="tab">�ܵ����</a>
			</h3>
			<!--��������-->
			<!--{block name="spaceblog" parameter="notype/1/allgroup/1/showgroupname/1/order/i.dateline DESC/limit/0,18/cachetime/9880/cachename/newinfo/tpl/data"}-->
			<div id="newinfo" class="tabcontent">
				<ul class="msgtitlelist list2col linelist">
					<!--{if $_SBLOCK['newinfo']}-->
						<!--{loop $_SBLOCK['newinfo'] $value}-->
							<li><cite><a href="#action/mygroup/gid/$value[gid]#" target="_blank">$value[g_groupname]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{else}-->
						<li>������Ϣ</li>
					<!--{/if}-->
				</ul>
			</div>
			<!--��������-->
			<!--{block name="spaceblog" parameter="notype/1/allgroup/1/showgroupname/1/dateline/604800/order/i.viewnum DESC/limit/0,18/cachetime/61980/cachename/hotinfo/tpl/data"}-->
			<div id="hotinfo" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist list2col linelist">
					<!--{if $_SBLOCK['hotinfo']}-->
						<!--{loop $_SBLOCK['newinfo'] $value}-->
							<li><cite><a href="#action/mygroup/gid/$value[gid]#" target="_blank">$value[g_groupname]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{else}-->
						<li>������Ϣ</li>
					<!--{/if}-->
				</ul>
			</div>
		</div>

	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<label for="searchkey2">Ȧ����</label><input type="text" name="searchkey" id="searchkey2" />&nbsp;
				<button type="submit" name="groupsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!--���³���Ȧ��-->
		<!--{block name="group" parameter="order/g.dateline DESC/limit/0,12/cachetime/13900/cachename/newgroup/tpl/data"}-->
		<div class="block" style="height: 310px;">
			<h3>���³���</h3>
			<ul>
				<!--{loop $_SBLOCK['newgroup'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[groupname]</a></dt>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / ��Ա:$value[usernum]</span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">

	<div class="side">
		<!--{block name="group" parameter="lastpost/604800/order/g.usernum DESC/limit/0,3/showdetail/1/cachetime/29900/cachename/weekhotgroup/tpl/data"}-->
		<div class="block blockG">
			<h3>������Ȧ��</h3>
			<ul class="thumblist">
				<!--{loop $_SBLOCK['weekhotgroup'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<h6><a href="$value[url]" target="_blank">$value[groupname]</a></h6>
					<p>Ȧ��: <a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a> / ��Ա: $value[usernum]</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--{block name="group" parameter="order/g.usernum DESC/limit/0,10/cachetime/91900/cachename/hotgrouplist/tpl/data"}-->
		<div class="block" style="height: 320px;">
			<h3>Ȧ������</h3>
			<ol>
				<!--{loop $_SBLOCK['hotgrouplist'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[groupname]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / ��Ա:$value[usernum]</span>
				</li>
				<!--{/loop}-->
			</ol>
		</div>
	</div>
	<div class="mainarea">
		
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
			<div class="blockcategory">
				<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
				<!--{block name="group" parameter="catid/$cat[subcatid]/order/g.lastpost DESC/limit/0,10/cachetime/$ctime/cachename/catgroup/tpl/data"}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['catgroup'] $key $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[groupname]</a></li>
					<!--{/loop}-->
					<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
				</ul>
			</div>
		<!--{/loop}-->
		</div>
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}