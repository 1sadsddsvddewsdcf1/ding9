<?exit?>
{template topic_header}
<!--{eval $ads = getad('system', 'topic', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->

	<!-- Content���� -->
	<div class="content topcontent">
		<div class="mainarea">
			<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
				<!--{loop $guidearr $value}-->
				&gt;&gt; <a href="$value[url]">$value[name]</a>
				<!--{/loop}-->
			</p>

			<div id="hottopic" class="tabblock" style="overflow: hidden; height: 323px;">
				<h3 id="hottopictabs" class="tabs">
					<a id="toptab" href="javascript:setTab('hottopic','top');" class="tab curtab">�����Ƽ�</a>
					<a id="monthtab" href="javascript:setTab('hottopic','month');" class="tab">�µ����</a>
					<a id="alltab" href="javascript:setTab('hottopic','all');" class="tab">�ܵ����</a>
				</h3>
				<!--�����Ƽ�ר���б�(һ��)-->
				<!--{block name="topic" parameter="top/3,2,1/order/top DESC, id DESC/limit/0,26/cachetime/0/subjectlen/40/subjectdot/1/cachename/toptopic/tpl/data"}-->
				<div id="top" class="tabcontent">
					<ul class="msgtitlelist list2col linelist">
						<!--{loop $_SBLOCK['toptopic'] $value}-->
							<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--�µ����ר���б�(һ��)-->
				<!--{block name="topic" parameter="dateline/2592000/order/viewnum DESC/limit/0,26/cachetime/0/subjectlen/40/subjectdot/1/cachename/hottopicmonth/tpl/data"}-->
				<div  id="month" class="tabcontent" style="display: none;">
					<ul class="msgtitlelist list2col linelist">
						<!--{loop $_SBLOCK['hottopicmonth'] $value}-->
							<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--�ܵ����ר���б�(ȫ��)-->
				<!--{block name="topic" parameter="order/viewnum DESC/limit/0,26/cachetime/0/subjectlen/40/subjectdot/1/cachename/hottopic/tpl/data"}-->
				<div id="all" class="tabcontent" style="display: none;">
					<ul class="msgtitlelist list2col linelist">
						<!--{loop $_SBLOCK['hottopic'] $value}-->
							<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span></li>
						<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
				<div class="blockcategorylist">
				<!--������������Ѷ�б�-->
				<!--{loop $_SBLOCK['category'] $ckey $cat}-->
				<!--{block name="topic" parameter="catid/$cat[subcatid]/order/id DESC/limit/0,10/cachetime/0/subjectlen/40/cachename/topiclist/tpl/data"}-->
				<div class="blockcategory">
					<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
					<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['topiclist'] $value}-->
						<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
						<!--{/loop}-->
						<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
					</ul>
				</div>
				<!--{/loop}-->
				</div>
			</div>
		</div>
		<!-- �Ҳ��� -->
		<div class="side">
			<div id="searchdiv">
				<form id="searchform" action="{S_URL}/batch.search.php" method="post">
					<input type="text" id="searchkey" name="searchkey" />
					<select name="type" id="type">
						<option value="">ȫ��</option>
						<!--{loop $channels['types'] $value}-->
							<option value="$value[nameid]">$value[name]</option>
						<!--{/loop}-->
					</select>
					<button type="submit" name="subjectsearch" value="true">����</button>
					<a href="{S_URL}/batch.search.php">�߼�����</a>
				</form>
			</div>
			<!-- �û���� -->
			<div id="userpanel">
				<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
			</div>

			<!--����ר��-->
			<div id="newpost" class="block">
				<!--{block name="topic" parameter="dateline/0/order/viewnum DESC/limit/0,10/cachetime/0/subjectlen/14/subjectdot/1/cachename/hottopic/tpl/data"}-->
				<h3>����ר��</h3>
				<ul>
					<!--{loop $_SBLOCK['hottopic'] $value}-->
					<li><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span> <span class="smalltxt">#date("m-d", $value["dateline"])# </span></li>
					<!--{/loop}-->
				</ul>
			</div>

			<!--ר���б�-->
			<div class="block">
				<!--{block name="topic" parameter="catid/0/order/id DESC/limit/0,10/cachetime/0/subjectlen/14/cachename/topiclist/tpl/data"}-->
				<h3>ר���б�</h3>
				<ul>
					<!--{loop $_SBLOCK['topiclist'] $value}-->
					<li><a href="$value[url]">$value[subject]</a><span class="smalltxt">($value[viewnum])</span> <span class="smalltxt">#date("m-d", $value["dateline"])# </span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

{template site_footer}