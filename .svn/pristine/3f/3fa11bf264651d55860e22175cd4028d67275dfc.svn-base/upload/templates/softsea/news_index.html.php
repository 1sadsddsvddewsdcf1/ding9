<?exit?>
{template news_header}
<!--{eval $ads = getad('system', 'news', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<!-- Content���� -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--ͼ����Ѷ�õ�Ƭ-->
		<!--{block name="spacenews" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/subjectlen/24/subjectdot/1/cachetime/11930/cachename/picnews/tpl/data"}-->
		<div id="slideimg">
		<!--{if !empty( $_SBLOCK['picnews'])}-->
		<script type="text/javascript" language="javascript">
		<!--			
		var xsTextBar = 1; //�Ƿ���ʾ�������ӣ�1Ϊ��ʾ��0Ϊ����ʾ
		var xsPlayBtn = 0; //�Ƿ���ʾ���Ű�ť��1��ʾ��0Ϊ����ʾ
		var xsImgSize = new Array(260,217); //�õ�ͼƬ�ĳߴ磬��ʽΪ������,�߶ȡ�
	
		var xsImgs = new Array();
		var xsImgLinks = new Array();
		var xsImgTexts = new Array();
		
		<!--{eval $i=0;}-->
		<!--{loop $_SBLOCK['picnews'] $key $value}-->
		xsImgs[$i] = "$value[a_thumbpath]";
		xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
		xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
		<!--{eval $i++;}-->
		<!--{/loop}-->
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		
		<!--һ�ܻظ�����ͷ��-->
		<!--{block name="spacenews" parameter="dateline/604800/showattach/1/showdetail/1/order/i.replynum DESC/limit/0,1/subjectlen/34/subjectdot/1/messagelen/80/messagedot/1/cachetime/18600/cachename/headnews/tpl/data"}-->
		<div id="headline">
			<!--{if !empty($_SBLOCK['headnews'])}-->
			<!--{loop $_SBLOCK['headnews'] $value}-->
			<strong><a href="$value[url]" target="_blank">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<div id="hotarticle" class="tabblock" style="margin-left: 274px;">
			<h3 id="hotarticletabs" class="tabs">
				<a id="newnewstab" href="javascript:setTab('hotarticle','newnews');" class="tab curtab">������Ѷ</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week');" class="tab">�ܵ����</a>
				<a id="monthtab" href="javascript:setTab('hotarticle','month');" class="tab">�µ����</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all');" class="tab">�ܵ����</a>
			</h3>
			<!--������Ѷ�б�-->
			<!--{block name="spacenews" parameter="order/i.dateline DESC/limit/0,6/subjectlen/40/subjectdot/1/cachetime/13800/cachename/newnews/tpl/data"}-->
			<div id="newnews" class="tabcontent">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['newnews'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ��������Ѷ�б�(һ��)-->
			<!--{block name="spacenews" parameter="dateline/604800/order/i.viewnum DESC/limit/0,6/cachetime/85400/subjectlen/40/subjectdot/1/cachename/hotnews1/tpl/data"}-->
			<div  id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotnews1'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ��������Ѷ�б�(һ��)-->
			<!--{block name="spacenews" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,6/cachetime/97200/subjectlen/40/subjectdot/1/cachename/hotnews2/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotnews2'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ��������Ѷ�б�(ȫ��)-->
			<!--{block name="spacenews" parameter="order/i.viewnum DESC/limit/0,6/cachetime/99400/subjectlen/40/subjectdot/1/cachename/hotnews3/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotnews3'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">ȫ��</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" name="subjectsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!--ͼƬ��Ѷ��ʾ-->
		<div id="picnews">
			<h3>ͼƬ��Ѷ</h3>
			<!--{block name="spacenews" parameter="haveattach/1/showattach/1/order/i.lastpost DESC/limit/0,5/cachetime/8000/cachename/picnews/tpl/data"}-->
			<ul id="scroller" class="imgthumblist">
				<!--{loop $_SBLOCK['picnews'] $value}-->
				<li class="list1line">
					<div><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[a_thumbpath]" alt="$value[subjectall]" /></a></div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--{block name="announcement" parameter="order/displayorder/limit/0,1/cachetime/96400/subjectlen/30/subjectdot/1/cachename/announce/tpl/data"}-->
		<div id="announcement">
			<strong>����:</strong>
			<!--{if empty($_SBLOCK['announce'])}-->
				��ʱû�й���
			<!--{else}-->
			<!--{loop $_SBLOCK['announce'] $value}-->
				<a href="$value[url]" target="_blank">$value[subject]</a>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
	</div>
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<div class="blockcategorylist">
		<!--������������Ѷ�б�-->
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spacenews" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/36/subjectdot/1/cachename/newslist/tpl/data"}-->
		<div class="blockcategory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newslist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
			</ul>
		</div>
		<!--{/loop}-->
		</div>
	</div>
	
	<!-- �Ҳ��� -->
	<div class="side">
		
		<!--{block name="tag" parameter="order/spacenewsnum DESC/limit/0,30/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>����TAG</h3>
			<div>
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacenewsnum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
		
		<!--����������Ѷ��ʾ-->
		<!--{block name="spacenews" parameter="order/i.lastpost DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/7500/cachename/newnews/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>���۸���</h3>
			<ul>
				<!--{loop $_SBLOCK['newnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">#date("m-d", $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--�¶������ȵ�-->
		<!--{block name="spacenews" parameter="lastpost/2592000/order/i.replynum DESC/limit/0,10/cachetime/75400/subjectlen/30/subjectdot/1/cachename/replyhot/tpl/data"}-->
		<div class="block">
			<h3>�¶������ȵ�</h3>
			<ul>
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">#date("m-d", $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>

	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}