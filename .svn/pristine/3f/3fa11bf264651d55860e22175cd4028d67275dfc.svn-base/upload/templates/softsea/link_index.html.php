<?exit?>
{template link_header}
<!--{eval $ads = getad('system', 'link', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<!-- Content���� -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<div id="hotlink" class="tabblock" style="height: 313px; overflow: hidden;">
			<h3 id="hotlinktabs" class="tabs">
				<a id="newtab" href="javascript:setTab('hotlink','new')" class="tab curtab">������ǩ</a>
				<a id="weektab" href="javascript:setTab('hotlink','week')" class="tab">�����ȵ�</a>
				<a id="monthtab" href="javascript:setTab('hotlink','month')" class="tab">�����ȵ�</a>
				<a id="alltab" href="javascript:setTab('hotlink','all')" class="tab">�ȵ�����</a>
			</h3>
			<!--����������ǩ-->
			<!--{block name="spacelink" parameter="order/i.dateline DESC/limit/0,24/subjectlen/36/subjectdot/1/cachetime/15400/cachename/newlink/tpl/data"}-->
			<div id="new" class="tabcontent">
				<ul class="msgtitlelist list2col linelist">
					<!--{loop $_SBLOCK['newlink'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" title="{$value[subjectall]}">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--������ǩ�б�(һ��)-->
			<!--{block name="spacelink" parameter="dateline/604800/order/i.replynum DESC/limit/0,24/cachetime/85400/subjectlen/36/subjectdot/1/cachename/hotlinkweek/tpl/data"}-->
			<div  id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist list2col linelist">
					<!--{loop $_SBLOCK['hotlinkweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--������ǩ�б�(һ��)-->
			<!--{block name="spacelink" parameter="dateline/2592000/order/i.replynum DESC/limit/0,24/cachetime/97200/subjectlen/36/subjectdot/1/cachename/hotlinkmonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist list2col linelist">
					<!--{loop $_SBLOCK['hotlinkmonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--������ǩ�б�(ȫ��)-->
			<!--{block name="spacelink" parameter="order/i.replynum DESC/limit/0,24/cachetime/97800/subjectlen/36/subjectdot/1/cachename/hotlink/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist list2col linelist">
					<!--{loop $_SBLOCK['hotlink'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>

	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">ȫ��</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" name="subjectsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<div class="block blockG" style="height: 190px; overflow: hidden;">
			<h3>��������������ǩ?</h3>
			<a href="{S_URL}/spacecp.php?action=linkmove&amp;op=rightclick" style="display: block; margin: 10px 70px 5px; background: #FFF; height: 48px; line-height: 48px; overflow: hidden; text-align: center; font-weight: bold; color: #1DA4CD;"><img src="{S_URL}/templates/default/images/thumb_bookmark_xpi.gif" alt="��װ��ǩ�Ҽ�" title="��װ��ǩ�Ҽ�" style="vertical-align: middle;" />��װ��ǩ�Ҽ�</a>
			<p style="margin: 0; padding:5px;line-height:150%;">��װ�󣬽������������ҳ���������Ҽ��˵��н����ֽ���ǰ���Ӽ��뵽�Լ����˿ռ���ǩ�Ŀ��ٲ˵������һ�¾Ϳ����ύ��ǩ���ǳ����㡣����ʹ�õ�ʱ��Ҳ��������ж�ء�</p>
		</div>
	</div>

</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<div class="blockcategorylist">
			<!--{loop $_SBLOCK['category'] $ckey $cat}-->
			<!--{eval $ctime=2800+30*$ckey;}-->
			<!--{block name="spacelink" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/40/subjectdot/1/cachename/sublist/tpl/data"}-->
			<!--{if $_SBLOCK['sublist']}-->
			<div class="blockcategory">
				<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['sublist'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
					<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
				</ul>
			</div>
			<!--{/if}-->
			<!--{/loop}-->
		</div>
	</div>
	<div class="side">
		<!-- �¶ȵ���ȵ� -->
		<!--{block name="spacelink" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,10/cachetime/83400/subjectlen/30/subjectdot/1/cachename/viewhot/tpl/data"}-->
		<div class="block">
			<h3>�¶ȵ���ȵ�</h3>
			<ul>
				<!--{loop $_SBLOCK['viewhot'] $value}-->
				<li><a href="$value[url]" title="{$value[subjectall]}" target="_blank">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!-- �������۸��� -->
		<!--{block name="spacelink" parameter="order/i.lastpost DESC/limit/0,20/subjectlen/30/subjectdot/1/cachetime/15400/cachename/lastlink/tpl/data"}-->
		<div class="block">
			<h3>����������ǩ</h3>
			<ul>
				<!--{loop $_SBLOCK['lastlink'] $value}-->
				<li>
					<a href="$value[url]" title="{$value[subjectall]}" target="_blank">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}