<?exit?>
{template bbs_header}
<!--{eval $ads2 = getad('system', 'bbs', '2');}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--������������־�б�-->
		<!--{if $forum['type'] != 'group'}-->
		<!--{block name="bbsthread" parameter="perpage/20/fid/$fid/showdetail/1/messagelen/160/subjectlen/40/order/dateline DESC/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		<div class="block topblock">
			<h3>�����б�</h3>
			<ul id="threadlist" class="messagelist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<h4><a href="$value[url]" target="_blank">$value[subject]</a></h4>
					<p class="msginfo">
						<a href="#uid/$value[authorid]#" target="_blank">$value[author]</a> ������: #date("Y-m-d", $value["dateline"])#, 
						<!--{if $value[replies]}--><a href="$value[url]" target="_blank" class="replynum">�ظ�: $value[replies]</a><!--{/if}-->
					</p>
					<!--{if $value[message]}--><p>$value[message]</p><!--{/if}-->
				</li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[newlist_multipage]}-->
			<div class="pages">
			$_SBLOCK[newlist_multipage]
			</div>
			<!--{/if}-->
			
		</div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--{block name="bbsforum" parameter="fup/$fid/allowblog/1/order/displayorder/limit/0,100/cachetime/28800/cachename/subarr/tpl/data"}-->
		<!--{if $_SGET['page']<2 && !empty($_SBLOCK['subarr'])}-->
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['subarr'] $key $value}-->
		<!--{eval $cachetime=1800+$key*5;}-->
		<!--{block name="bbsthread" parameter="fid/$value[fid]/order/dateline DESC/limit/0,10/cachetime/$cachetime/cachename/subthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['subthreadlist']}-->
		<div class="blockcategory">
			<h3><a href="#action/forumdisplay/fid/$value[fid]#">$value[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
				<li><a href="#action/forumdisplay/fid/$value[fid]#" class="more">���࡭��</a></li>
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		</div>
		<!--{/if}-->
		
	</div>
	<div class="side">
		<div class="block blockG">
			<h1>$forum[name]</h1>
			<!--�Ӱ��-->
			<!--{if $_SBLOCK['subarr']}-->
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subarr'] $value}-->
				<li><a href="$value[url]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->
		</div>

		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="bbsthread" parameter="fid/$fid/dateline/2592000/order/views DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/97200/cachename/hotthread/tpl/data"}-->
		<!--{if $_SBLOCK['hotthread']}-->
		<div class="block">
			<h3>�¶ȹ�ע�ȵ�</h3>
			<ul>
				<!--{loop $_SBLOCK['hotthread'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[replies])</span></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
	</div>	
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagefootad'])}-->
<div class="adbox">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}
