<?exit?>
{template blog_header}
<!--{eval $ads = getad('system', 'blog', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
	
		<!--������־ͼƬ�õ�Ƭ ��ʼ-->
		<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/cachetime/13930/cachename/picblog/tpl/data"}-->
		<div id="slideimg">
		<!--{if !empty( $_SBLOCK['picblog'])}-->
		<script type="text/javascript" language="javascript">
		<!--			
		var xsTextBar = 1; //�Ƿ���ʾ�������ӣ�1Ϊ��ʾ��0Ϊ����ʾ
		var xsPlayBtn = 0; //�Ƿ���ʾ���Ű�ť��1��ʾ��0Ϊ����ʾ
		var xsImgSize = new Array(260,217); //�õ�ͼƬ�ĳߴ磬��ʽΪ������,�߶ȡ�
	
		var xsImgs = new Array();
		var xsImgLinks = new Array();
		var xsImgTexts = new Array();
		
		<!--{eval $i=0;}-->
		<!--{loop $_SBLOCK['picblog'] $key $value}-->
		xsImgs[$i] = "$value[a_thumbpath]";
		xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
		xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
		<!--{eval $i++;}-->
		<!--{/loop}-->
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		
		<!--ͷ���Ķ� ����:һ��֮�ڷ�����/��������-->
		<div id="headline">
			<!--{block name="spaceblog" parameter="dateline/604800/showattach/1/showdetail/1/order/i.replynum DESC/limit/0,1/subjectlen/40/subjectdot/1/messagelen/100/messagedot/1/cachetime/68600/cachename/headblog/tpl/data"}-->
			<!--{if !empty($_SBLOCK['headblog'])}-->
			<!--{loop $_SBLOCK['headblog'] $value}-->
			<strong><a href="$value[url]" target="_blank">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<div id="hotarticle" class="tabblock" style="margin-left: 274px;">
			<h3 id="hotarticletabs" class="tabs">
				<a id="newtab" href="javascript:setTab('hotarticle','new')" class="tab curtab">������־</a>
				<a id="daytab" href="javascript:setTab('hotarticle','day')" class="tab">�ܵ����</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week')" class="tab">�µ����</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all')" class="tab">�ܵ����</a>
			</h3>
			<!--���·�������־-->
			<!--{block name="spaceblog" parameter="order/i.dateline DESC/limit/0,6/showspacename/1/subjectlen/40/subjectdot/1/cachetime/14800/cachename/coolblog/tpl/data"}-->
			<div id="new" class="tabcontent">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{if !empty($_SBLOCK['coolblog'])}-->
						<!--{loop $_SBLOCK['coolblog'] $value}-->
						<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{/if}-->
				</ul>
			</div>
			<!--վ������BLOG�б�(һ��)-->
			<!--{block name="spaceblog" parameter="dateline/604800/order/i.viewnum DESC/limit/0,6/cachetime/65400/subjectlen/40/subjectdot/1/cachename/hotarticleweek/tpl/data"}-->
			<div id="day" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotarticleweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ������BLOG�б�(һ��)-->
			<!--{block name="spaceblog" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,6/cachetime/77200/subjectlen/40/subjectdot/1/cachename/hotarticlemonth/tpl/data"}-->
			<div id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotarticlemonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--վ������BLOG�б�(ȫ��)-->
			<!--{block name="spaceblog" parameter="order/i.viewnum DESC/limit/0,6/cachetime/87400/subjectlen/40/subjectdot/1/cachename/hotarticle/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotarticle'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">ȫ��</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" name="subjectsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<div id="spacestar">
			<h3>�ռ�֮��</h3>
			<!--{block name="userspace" parameter="isstar/1/showdetail/1/order/u.lastpost DESC/limit/0,8/cachetime/94400/cachename/spacestar/tpl/data"}-->
			<ul>
				<!--{loop $_SBLOCK['spacestar'] $value}-->
				<li>
					<div><a href="$value[url]" title="$value[username]"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!-- ͬ�ǿռ� -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
				<button value="true" type="submit" name="usersearch">ͬ�ǿռ�</button>
			</form>
		</div>
	</div>

</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<!--ͼƬ��־��ʾ-->
		<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.lastpost DESC/subjectlen/16/subjectdot/1/limit/0,5/cachetime/8000/cachename/picblog/tpl/data"}-->
		<div class="block" style="padding: 0;">
			<ul class="imagelist" style="height: 133px;">
			<!--{loop $_SBLOCK['picblog'] $value}-->
				<li>
					<div><a href="$value[url]" title="$value[subject]"><img src="$value[a_thumbpath]" alt="$value[subject]" /></a></div>
					<p><a href="$value[url]">$value[subject]</a></p>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	
	<div class="side">
		<!--{block name="tag" parameter="order/spaceallnum DESC/limit/0,20/cachetime/21600/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>���ű�ǩ</h3>
			<div style="height: 82px; overflow: hidden;">
			<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spaceallnum])</em></a>
			<!--{/loop}-->
			</div>
		</div>		
	</div>
	
	
</div>

<div class="content">
	<div class="side">
		
		<!--�����û��ռ������б�-->
		<!--{block name="userspace" parameter="lastpost/604800/order/u.spaceblognum DESC/limit/0,10/cachetime/19900/cachename/newspace/tpl/data"}-->
		<div id="hotspace" class="block stat" style="height: 320px;">
			<a href="#action/spaces#" class="more">���пռ�</a>
			<h3>һ���ȵ�ռ�</h3>
			<ol>
				<!--{loop $_SBLOCK['newspace'] $value}-->
				<li><a href="$value[url]">$value[spacename]</a></li>
				<!--{/loop}-->
			</ol>
		</div>
		
		<!--�������ռ�-->
		<!--{block name="userspace" parameter="order/u.dateline DESC/limit/0,15/cachetime/11900/cachename/lastspace/tpl/data"}-->
		<div class="block">
			<h3>�������ռ�</h3>
			<ul>
				<!--{loop $_SBLOCK['lastspace'] $value}-->
				<li><a href="$value[url]">$value[spacename]</a> <span class="smalltxt">#date("m-d", $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--վ������BLOG�б�(һ��)-->
		<!--{block name="spaceblog" parameter="lastpost/604800/order/i.replynum DESC/limit/0,10/cachetime/15400/subjectlen/30/subjectdot/1/cachename/replyhot/tpl/data"}-->
		<div class="block">
			<h3>һ�������ȵ�</h3>
			<ul>
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></li>
				<!--{/loop}-->
			</ul>
		</div>
	
		<!--���۸���-->
		<!--{block name="spaceblog" parameter="order/i.lastpost DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/11000/cachename/newblog/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>���۸���</h3>
			<ul>
				<!--{loop $_SBLOCK['newblog'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></li>
				<!--{/loop}-->
			</ul>
		</div>

	</div>
	<div class="mainarea">
		<div class="blockcategorylist">
		<!--������������־�б�-->
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spaceblog" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/$ctime/subjectlen/36/subjectdot/1/cachename/bloglist/tpl/data"}-->
		<div class="blockcategory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['bloglist'] $value}-->
				<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
				<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
			</ul>
		</div>
		<!--{/loop}-->
		</div>
	</div>
	<!-- /Content -->
</div>

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if (getad('system', 'blog', 'pagemovead', '1' ,'1')) || (getad('system', 'blog', 'pageoutad', '1', '1'))}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if (getad('system', 'blog', 'pageoutad', '1', '1'))}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip(getad('system', 'blog', 'pageoutad', '1'));}--><\/div>").floatIt();
<!--{/if}-->
<!--{if (getad('system', 'blog', 'pagemovead', '1', '1'))}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip(getad('system', 'blog', 'pagemovead', '1'));}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip(getad('system', 'blog', 'pagemovead', '1'));}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->
<!--{if (getad('system', 'blog', 'pageoutindex', '1' ,'1'))}-->
#getad('system', 'blog', 'pageoutindex', '1')#
<!--{/if}-->
{template site_footer}