<?exit?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset]" />
<title>$title  $_SCONFIG[seotitle]- Powered by SupeSite</title>
<meta name="keywords" content="$keywords $_SCONFIG[seokeywords]" />
<meta name="description" content="$description $_SCONFIG[seodescription]" />
<link rel="stylesheet" type="text/css" href="{S_URL}/templates/$_SCONFIG[template]/css/group.css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
<!--{if !empty($grouparr[css])}-->
<style type="text/css">

$grouparr[css]

</style>
<!--{/if}-->
</head>

<body>
<div id="wrap">
	<!-- Headerҳ�� -->
	<div id="group_topmenu">
		<table border="0" cellpadding="0" cellspacing="0" id="headertab">
			<tr>
				<td id="logo">
					<a href="{S_URL}/"><img src="{S_URL}/templates/$_SCONFIG[template]/images/logo.gif" alt="$_SCONFIG[sitename]" style="border: none;" /></a>
				</td>
				<td id="topmenu">
					<ul>
						<li><a href="{S_URL}/">��ҳ</a></li>
						<!--{loop $channels['menus'] $value}-->
						<li><a href="$value[url]">$value[name]</a></li>
						<!--{/loop}-->
						<li><a href="{S_URL}/batch.search.php">����</a></li>
					</ul>
				</td>
			</tr>
		</table>
	</div>
	<div id="header" style="background-image: url($grouparr['headerimage']);">
		<div id="groupname">
			<h1><a href="#action/mygroup/gid/$_SGET[gid]#" title="$grouparr['groupname']">$grouparr['groupname']</a></h1>
			<p><a href="javascript:;" onclick="javascript:setCopy('$grouparr[domain]');" title="����Ȧ������">$grouparr[domain]</a></p>
		</div>
		<div id="menu">
			<ul>
				<li><a href="#action/mygroup/gid/$_SGET[gid]#">Ȧ����ҳ</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list#">���ĸ���</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/recommend#">��Ա�Ƽ�</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/digest#">��������</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/bbs#">������</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/members#">��Ա�б�</a></li>
				<li><a href="{S_URL}/spacecp.php?action=mygroups&gid=$gid" target="_blank">Ȧ�ӹ���</a></li>
				<li class="important"><a href="javascript:;" onclick="javascript:joingroup('$_SGET[gid]');">+���뱾Ȧ</a></li>
			</ul>
		</div>
	</div>
	<!-- /Headerҳ�� -->
