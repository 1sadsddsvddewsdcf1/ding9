<?exit?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset]" />
<title>$_SCONFIG[sitename]  $_SCONFIG[seotitle]- Powered by SupeSite</title>
<meta name="keywords" content="$_SCONFIG[sitename] $_SCONFIG[seokeywords]" />
<meta name="description" content="$_SCONFIG[sitename] $_SCONFIG[seodescription]" />
<link rel="stylesheet" type="text/css" href="{S_URL}/templates/$_SCONFIG[template]/css/style.css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
</head>  
<body>
<!--{eval $ads = getad('system', 'indexad', '1'); }-->
<div id="wrap">
	<div id="header">
		<table border="0" cellpadding="0" cellspacing="0" id="headertab">
			<tr>
				<td id="logo">
					<a href="{S_URL}/"><img src="{S_URL}/templates/$_SCONFIG[template]/images/logo.jpg" alt="$_SCONFIG[sitename]" style="border:none;" /></a>
				</td>
				<td id="topmenu">
					<ul>
						<!--{loop $channels['menus'] $key $value}-->
						<li><a href="$value[url]" class="$key">$value[name]</a></li>
						<!--{/loop}-->
					</ul>
				</td>
			</tr>
		</table>
  	</div>
	<div id="menu" class="empty"> </div>
	<!--{if !empty($ads['pageheadad']) }-->
	<div class="adbanner">$ads[pageheadad]</div>
	<!--{/if}-->
	<div class="content topcontent">
		<div class="mainarea" style="padding-top: 10px;">
			<!--������־ͼƬ�õ�Ƭ ��ʼ-->
			<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/cachetime/13930/cachename/picblog/tpl/data"}-->
			<div id="slideimg">
			<!--{if !empty( $_SBLOCK['picblog'])}-->
			<script type="text/javascript" language="javascript">
			<!--			
			var xsTextBar = 1; //�Ƿ���ʾ�������ӣ�1Ϊ��ʾ��0Ϊ����ʾ
			var xsPlayBtn = 0; //�Ƿ���ʾ���Ű�ť��1��ʾ��0Ϊ����ʾ
			var xsImgSize = new Array(260,217); //�õ�ͼƬ�ĳߴ磬��ʽΪ������,�߶ȡ�
		
			var xsImgs = new Array();
			var xsImgLinks = new Array();
			var xsImgTexts = new Array();
			
			<!--{eval $i=0;}-->
			<!--{loop $_SBLOCK['picblog'] $key $value}-->
			xsImgs[$i] = "$value[a_thumbpath]";
			xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
			xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
			<!--{eval $i++;}-->
			<!--{/loop}-->
			//-->
			</script>
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
			<!--{/if}-->
			</div>

			<!--һ�ܻظ�����ͷ��-->
			<!--{block name="spacenews" parameter="dateline/604800/showattach/1/showdetail/1/order/i.replynum DESC/limit/0,1/subjectlen/34/subjectdot/1/messagelen/100/messagedot/1/cachetime/18600/cachename/headnews/tpl/data"}-->
			<div id="headline">
			<!--{if !empty($_SBLOCK[headnews])}-->
			<!--{loop $_SBLOCK[headnews] $value}-->
				<strong><a href="$value[url]" target="_blank">$value[subject]</a></strong>
				<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
			</div>

			<div id="news" class="tabblock" style="margin-left: 274px;">
				<h3 id="newstabs">
					<a id="newnewstab" href="javascript:setTab('news','newnews');" class="tab curtab">������Ѷ</a>
					<a id="hotnewstab" href="javascript:setTab('news','hotnews');" class="tab">�����ȵ�</a>
				</h3>
				<!--{block name="spacenews" parameter="order/i.dateline DESC/limit/0,6/cachetime/85400/subjectlen/40/subjectdot/1/cachename/hotnews1/tpl/data"}-->
				<div id="newnews" class="tabcontent">
					<ul class="msgtitlelist" style="height: 144px;">
						<!--{loop $_SBLOCK['hotnews1'] $value}-->
						<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--վ��������Ѷ�б�(һ��)-->
				<!--{block name="spacenews" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,6/cachetime/97200/subjectlen/40/subjectdot/1/cachename/hotnews2/tpl/data"}-->
				<div id="hotnews" class="tabcontent" style="display: none;">
					<ul class="msgtitlelist" style="height: 144px;">
						<!--{loop $_SBLOCK['hotnews2'] $value}-->
						<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
			</div>
		</div>
		
		<div class="side">
			<div id="searchdiv">
				<form id="searchform" action="{S_URL}/batch.search.php" method="post">
					<input type="text" id="searchkey" name="searchkey" />
					<select name="type" id="type">
						<option value="">ȫ��</option>
						<!--{loop $channels['types'] $value}-->
							<option value="$value[nameid]">$value[name]</option>
						<!--{/loop}-->
					</select>
					<button type="submit" name="subjectsearch" value="true">����</button>
					<a href="{S_URL}/batch.search.php">�߼�</a>
				</form>
			</div>
			<!-- �û���� -->
			<div id="userpanel">
				<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
			</div>
			<a href="{B_URL}/register.php?referer={S_URL}/index.php"><img src="{S_URL}/templates/$_SCONFIG[template]/images/btn_register.gif" alt="���������Լ��ĸ��˿ռ�" style="display: block; margin-top: 7px;" /></a>
		</div>
	</div>
	
	<div class="content" style="margin-bottom: 6px;">
		<div class="mainarea">
			<!--{block name="poll" parameter="order/dateline DESC/limit/0,1/cachetime/80000/cachename/poll/tpl/data"}-->
			<div id="polls" style="float: left; padding-right: 10px; width: 264px; w\idth: 228px; height: 36px; overflow: hidden;">
				<strong>����:</strong>
				<!--{if empty($_SBLOCK['poll'])}-->
					��ʱû�е���
				<!--{else}-->
					<!--{loop $_SBLOCK['poll'] $value}-->
						<a href="$value[url]" target="_blank">$value[subject]</a>
					<!--{/loop}-->
				<!--{/if}-->
			</div>
			<!--{block name="announcement" parameter="order/displayorder/limit/0,1/cachetime/96400/subjectlen/40/subjectdot/1/cachename/announce/tpl/data"}-->
			<div id="announcement" style="float: right; width: 391px; w\idth: 365px;">
				<strong>����:</strong>
				<!--{if empty($_SBLOCK['announce'])}-->
					��ʱû�й���
				<!--{else}-->
				<!--{loop $_SBLOCK['announce'] $value}-->
					<a href="$value[url]" target="_blank">$value[subject]</a>
				<!--{/loop}-->
				<!--{/if}-->
			</div>
		</div>
		<div class="side">
			<div id="cityspace">
				<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
				<form action="{S_URL}/batch.search.php" method="post">
					<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
					<button type="submit" name="usersearch" value="true">ͬ�ǿռ�</button>
				</form>
			</div>
		</div>
	</div>
	
	<!--{if !empty($ads['pagecenterad'])}-->
	<div class="adbox">
	$ads[pagecenterad]
	</div>
	<!--{/if}-->
	
	<div class="content">
		<div class="mainarea">
			<div class="midmain">
				<!--{if !empty($channels['types']['blog'])}-->
				<div id="blog" class="block" style="height: 165px; overflow: hidden;">
					<h2><a href="#action/blog#">��־</a></h2>
					<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.lastpost DESC/limit/0,1/subjectlen/16/cachetime/13930/cachename/picblog/tpl/data"}-->
					<!--{if !empty($_SBLOCK['picblog'])}-->
						<div class="thumbmsg">
						<!--{loop $_SBLOCK['picblog'] $value}-->
						<a href="$value[url]"><img src="$value[a_thumbpath]" alt="$value[subjectall]" title="$value[subjectall]" /></a>
						<a href="$value[url]">$value[subject]</a>
						<!--{/loop}-->
						</div>
					<!--{/if}-->
	
					<!--{block name="spaceblog" parameter="order/i.dateline DESC/subjectlen/40/subjectdot/1/limit/0,5/cachetime/18400/cachename/hotblog/tpl/data"}-->
					<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['hotblog'] $value}-->
						<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
						<!--{/loop}-->
						<li><a href="#action/blog#" class="more">���࡭��</a></li>
					</ul>
				</div>
				<!--{/if}-->
				
				<!--{if !empty($channels['menus']['group'])}-->
				<div id="group" class="block" style="height: 165px; overflow: hidden;">
					<h2><a href="#action/group#">Ȧ��</a></h2>
					<!--{block name="group" parameter="lastpost/604800/order/g.usernum DESC/limit/0,1/showdetail/1/cachetime/29900/cachename/weekhotgroup/tpl/data"}-->
					<!--{if !empty($_SBLOCK['weekhotgroup'])}-->
						<div class="thumbmsg">
						<!--{loop $_SBLOCK['weekhotgroup'] $value}-->
						<a href="$value[url]"><img src="$value[logo]" alt="$value[groupname]" title="$value[groupname]" /></a>
						<a href="$value[url]">$value[groupname]</a>
						<!--{/loop}-->
						</div>
					<!--{/if}-->
	
					<!--{block name="group" parameter="order/g.dateline DESC/limit/0,5/cachetime/19900/cachename/newgroup/tpl/data"}-->
					<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['newgroup'] $value}-->
						<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[groupname]</a> <span class="smalltxt">$value[usernum] members</span></li>
						<!--{/loop}-->
						<li><a href="#action/group#" class="more">���࡭��</a></li>
					</ul>
				</div>
				<!--{/if}-->
				
				<!--{if !empty($channels['menus']['bbs'])}-->
				<div id="bbs" class="block" style="height: 165px; overflow: hidden;">
					<h2><a href="#action/bbs#">��̳</a></h2>
					<!--{block name="bbsattachment" parameter="dateline/604800/filetype/image/order/t.views DESC/limit/0,1/subjectlen/12/cachetime/38200/cachename/imagethread/tpl/data"}-->
					<!--{if !empty($_SBLOCK['imagethread'])}-->
						<div class="thumbmsg">
						<!--{loop $_SBLOCK['imagethread'] $value}-->
						<a href="$value[url]"><img src="$value[attachment]" alt="$value[subjectall]" title="$value[subjectall]" /></a>
						<a href="$value[url]">$value[subject]</a>
						<!--{/loop}-->
						</div>
					<!--{/if}-->
	
					<!--{block name="bbsthread" parameter="order/t.dateline DESC/subjectlen/40/subjectdot/1/limit/0,5/cachetime/5630/cachename/newthread/tpl/data"}-->
					<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['newthread'] $value}-->
						<li><cite><a href="#uid/$value[authorid]/action/viewpro#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt">$value[replies] replies</span></li>
						<!--{/loop}-->
						<li><a href="#action/bbs#" class="more">���࡭��</a></li>
					</ul>
				</div>
				<!--{/if}-->
				
				<!--{if !empty($channels['types']['image'])}-->
				<div id="image" class="tabblock" style="height: 250px; overflow: hidden;">
					<a href="#action/image#" class="more">����ͼƬ</a>
					<h3 id="imagetabs">
						<a id="newimagetab" href="javascript:setTab('image','newimage');" class="tab curtab">����ͼƬ</a>
						<a id="hotimagetab" href="javascript:setTab('image','hotimage');" class="tab">����ͼƬ</a>
					</h3>
					<div id="newimage" class="tabcontent">
						<!--{block name="spaceimage" parameter="order/i.dateline DESC/limit/0,8/subjectlen/18/subjectdot/1/messagelen/30/messagedot/1/showdetail/1/cachetime/27900/cachename/newimage/tpl/data"}-->
						<ul class="newimage">
						<!--{loop $_SBLOCK['newimage'] $value}-->
							<li>
								<div>
									<a href="$value[url]" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" title="$value[subjectall]" /></a>
								</div>
								<p><a href="$value[url]" title="$value[subjectall]">$value[subject]</a></p>
								<!--{if !empty($value[message])}--><p>$value[message]</p><!--{/if}-->
							</li>
						<!--{/loop}-->
						</ul>
					</div>
					<div id="hotimage" class="tabcontent" style="display: none;">
						<!--{block name="spaceimage" parameter="dateline/604800/order/i.viewnum DESC/limit/0,8/subjectlen/18/subjectdot/1/messagelen/60/messagedot/1/showdetail/1/cachetime/27900/cachename/hotimage/tpl/data"}-->
						<ul class="newimage">
						<!--{loop $_SBLOCK['hotimage'] $value}-->
							<li>
								<div>
									<a href="$value[url]" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" title="$value[subjectall]" /></a>
								</div>
									<p><a href="$value[url]" title="$value[subjectall]">$value[subject]</a></p>
									<!--{if !empty($value[message])}--><p>$value[message]</p><!--{/if}-->
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				</div>
				<!--{/if}-->
				
				<!--{if !empty($channels['types']['file'])}-->
				<div id="file" class="tabblock" style="height: 254px; overflow: hidden;">
					<a href="#action/file#" class="more">�����ļ�</a>
					<h3 id="filetabs">
						<a id="newfiletab" href="javascript:setTab('file','newfile');" class="tab curtab">�����ļ�</a>
						<a id="hotfiletab" href="javascript:setTab('file','hotfile');" class="tab">��������</a>
					</h3>
					<div id="newfile" class="tabcontent">
						<!--{block name="spacefile" parameter="order/i.dateline DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/15980/cachename/newfile/tpl/data"}-->
						<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['newfile'] $value}-->
							<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
						<!--{/loop}-->
						</ul>
					</div>
					<div id="hotfile" class="tabcontent" style="display: none;">
						<!--{block name="spacefile" parameter="dateline/604800/order/i.replynum DESC/subjectlen/30/subjectdot/1/limit/0,10/showdetail/1/cachetime/33800/cachename/hotfile/tpl/data"}-->
						<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['hotfile'] $value}-->
							<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
						<!--{/loop}-->
						</ul>
					</div>
				</div>
				<!--{/if}-->

				<!--{if !empty($_SCONFIG['modelarr'])}-->
				<div id="model" class="tabblock" style="height: 254px; overflow: hidden;">
					<h3 id="modeltabs">
					<!--{eval $i=0;}-->
					<!--{loop $_SCONFIG['modelarr'] $key $value}-->
						<!--{if $i==0}-->
						<a id="{$key}tab" href="javascript:setTab('model','$key');" class="tab curtab">$value</a>
						<!--{else}-->
						<a id="{$key}tab" href="javascript:setTab('model','$key');" class="tab">$value</a>
						<!--{/if}-->
						<!--{eval $i++}-->
					<!--{/loop}-->
					</h3>
					<!--{eval $i=0;}-->
					<!--{loop $_SCONFIG['modelarr'] $key $value}-->
					<!--{if $i == 0}-->
					<div id="$key" class="tabcontent">
					<!--{else}-->
					<div id="$key" class="tabcontent" style="display: none;">
					<!--{/if}-->
					<!--{eval $i++}-->
						<!--{eval $ctime=1800+30*$i;}-->
						<!--{block name="model" parameter="name/$key/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/32/subjectdot/1/cachename/newsmodel/tpl/data"}-->
						<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['newsmodel'] $value}-->
							<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
						<!--{/loop}-->
						</ul>
					</div>
					<!--{/loop}-->
				</div>
				<!--{/if}-->
			</div>
			
			<div class="midside">
				<!--{block name="tag" parameter="order/spaceallnum DESC/limit/0,20/cachetime/21600/cachename/hottag/tpl/data"}-->
				<div id="hottag" class="block blockG">
					<h3>���ű�ǩ</h3>
					<div style="height: 149px; line-height: 1.9em; overflow: hidden;">
					<!--{loop $_SBLOCK['hottag'] $value}-->
						<a href="$value[url]">$value[tagname]<em>($value[spaceallnum])</em></a>
					<!--{/loop}-->
					</div>
				</div>
				
				<!--{block name="userspace" parameter="order/u.spaceallnum DESC/limit/0,12/cachetime/44000/cachename/topspace/tpl/data"}-->
				<div id="hotspace" class="block" style="height: 350px; overflow: hidden;">
					<a href="#action/spaces#" class="more">���пռ�</a>
					<h3>�ռ�����</h3>
					<ol>
					<!--{loop $_SBLOCK['topspace'] $value}-->
						<li><a href="$value[url]">$value[spacename]</a></li>
					<!--{/loop}-->
					</ol>
				</div>
				
				<!--����������������-->
				<!--{block name="bbsforum" parameter="type/forum/allowblog/1/order/posts DESC/limit/0,12/cachetime/14400/cachename/hotforums/tpl/data"}-->
				<div id="hottforum" class="block" style="height: 350px;overflow: hidden;">
					<a href="{B_URL}" class="more">������̳</a>
					<h3>��̳�������</h3>
					<ol>
						<!--{loop $_SBLOCK['hotforums'] $value}-->
						<li><a href="$value[url]">$value[name] <span class="smalltxt">$value[posts]</span></a></li>
						<!--{/loop}-->
					</ol>
				</div>
				
				<!--{block name="userspace" parameter="order/u.dateline DESC/limit/0,14/cachetime/44000/cachename/newspace/tpl/data"}-->
				<div id="newspace" class="block">
					<h3>�¿ռ�</h3>
					<ul style="height: 298px;overflow: hidden;">
					<!--{loop $_SBLOCK['newspace'] $value}-->
						<li><a href="$value[url]">$value[spacename]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			
		</div>
		
		<div class="side">
			<!--{if !empty($channels['types']['video'])}-->
			<div id="indexvideo">
				<!--{block name="spacevideo" parameter="dateline/604800/order/i.replynum DESC/limit/0,1/cachetime/64400/subjectlen/30/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotreplyvideo/tpl/data"}-->
				<!--{loop $_SBLOCK['hotreplyvideo'] $value}-->
				<a href="$value[url]" title="$value[subjectall]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a>
				<p><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a> <span class="smalltxt">$value[viewnum] views, $value[replynum] replies</span></p>
				<!--{/loop}-->
			</div>
			<div id="videoblock" class="tabblock" style="height: 260px; overflow: hidden;">
				<a href="#action/video#" class="more">����Ӱ��</a>
				<h3 id="videoblocktabs">
					<a id="newvideotab" href="javascript:setTab('videoblock','newvideo');" class="tab curtab">����Ӱ��</a>
					<a id="hotviewvideotab" href="javascript:setTab('videoblock','hotviewvideo');" class="tab">����Ӱ��</a>
				</h3>
				<div id="newvideo" class="tabcontent">
				<!--{block name="spacevideo" parameter="order/i.dateline DESC/limit/0,10/cachetime/64400/subjectlen/30/subjectdot/1/cachename/newvideo/tpl/data"}-->
					<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['newvideo'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
				<div id="hotviewvideo" class="tabcontent" style="display: none;">
				<!--{block name="spacevideo" parameter="dateline/604800/order/i.viewnum DESC/limit/0,10/cachetime/64400/subjectlen/30/subjectdot/1/cachename/hotvideo/tpl/data"}-->
					<ul class="msgtitlelist">
						<!--{loop $_SBLOCK['hotvideo'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
			</div>
			<!--{/if}-->
			<!--{if !empty($channels['types']['goods'])}-->
			<div id="goods" class="tabblock" style="height: 570px; overflow: hidden;">
				<a href="#action/goods#" class="more">������Ʒ</a>
				<h3 id="goodstabs">
					<a id="newgoodstab" href="javascript:setTab('goods','newgoods');" class="tab curtab">������Ʒ</a>
					<a id="hotgoodstab" href="javascript:setTab('goods','hotgoods');" class="tab">������Ʒ</a>
				</h3>
				<div id="newgoods" class="tabcontent">
					<!--{block name="spacegoods" parameter="order/i.dateline DESC/limit/0,6/subjectlen/24/subjectdot/1/messagelen/60/messagedot/1/cachetime/15980/showdetail/1/cachename/newgoods/tpl/data"}-->
					<ul class="thumbmsglist">
					<!--{loop $_SBLOCK['newgoods'] $value}-->
						<li style="padding: 5px;">
							<p class="thumb"><a href="$value[url]"><img src="$value[thumb]" alt="$value[subjectall]" title="$value[subjectall]" /></a></p>
							<div style="width: 190px;">
								<h6><a href="$value[url]">$value[subject]</a></h6>
								<!--{if !empty($value[message])}--><p>$value[message]</p><!--{/if}-->
							</div>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
				<div id="hotgoods" class="tabcontent" style="display: none;">
					<!--{block name="spacegoods" parameter="dateline/604800/order/i.replynum DESC/limit/0,4/subjectlen/30/subjectdot/1/messagelen/60/messagedot/1/showdetail/1/cachetime/33800/cachename/hotgoods/tpl/data"}-->
					<ul class="thumbmsglist">
					<!--{loop $_SBLOCK['hotgoods'] $value}-->
						<li style="padding: 5px;">
							<p class="thumb"><a href="$value[url]"><img src="$value[thumb]" alt="$value[subjectall]" title="$value[subjectall]" /></a></p>
							<div style="width: 190px;">
								<h6><a href="$value[url]">$value[subject]</a></h6>
								<!--{if !empty($value[message])}--><p>$value[message]</p><!--{/if}-->
							</div>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<!--{/if}-->
			<!--{if !empty($channels['types']['link'])}-->
			<div id="link" class="tabblock" style="height: 250px; overflow: hidden;">
				<a href="#action/link#" class="more">������ǩ</a>
				<h3 id="linktabs">
					<a id="newlinktab" href="javascript:setTab('link','newlink');" class="tab curtab">������ǩ</a>
					<a id="hotlinktab" href="javascript:setTab('link','hotlink');" class="tab">������ǩ</a>
				</h3>
				<div id="newlink" class="tabcontent">
					<!--{block name="spacelink" parameter="order/i.dateline DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/15980/cachename/newlink/tpl/data"}-->
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['newlink'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
				<div id="hotlink" class="tabcontent" style="display: none;">
					<!--{block name="spacelink" parameter="dateline/604800/order/i.replynum DESC/subjectlen/30/subjectdot/1/limit/0,10/showdetail/1/cachetime/33800/cachename/hotlink/tpl/data"}-->
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotlink'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<!--{/if}-->
		</div>
	</div>
	<!--{if !empty($_SCONFIG['showindex'])}-->
			<!--{block name="friendlink" parameter="order/displayorder/limit/0,$_SCONFIG['showindex']/cachetime/11600/namelen/32/cachename/friendlink/tpl/data"}-->
			<!--{eval $imglink=$txtlink="";}-->
			<!--{loop $_SBLOCK['friendlink'] $value}-->
			<!--{if $value[logo]}-->
			<!--{eval $imglink .="<li><a href=\"".$value[url]."\" target=\"_blank\"><img src=\"".$value[logo]."\" alt=\"".$value[description]."\" /></a></li>";}-->
			<!--{else}-->
			<!--{eval $txtlink .= "<li><a href=\"".$value[url]."\" title=\"".$value[description]."\" target=\"_blank\">".$value[name]."</a></li>";}-->
			<!--{/if}-->
			<!--{/loop}-->
			<div id="links">
				<a class="more" href="#action/site/type/link#">��������</a>
				<h3>��������</h3>
				<ul class="pic">
				$imglink
				</ul>
				<ul class="text">
				$txtlink
				</ul>
			</div>
			<!-- /���� -->
		<!--{/if}-->

	<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

	<!-- Footer -->	
	<div class="content" id="footerlink">
		<a href="{S_URL}/">$_SCONFIG[sitename]</a> | 
		<a href="{B_URL}/" target="_blank">������̳</a> | 
		<a href="{S_URL}/?action/site/type/panel">������</a> | 
		<a href="{S_URL}/?action/site/type/map">վ���ͼ</a> | 
		<a href="{S_URL}/?action/site/type/link">��������</a> | 
		<a href="{S_URL}/?action/spaces">�ռ��б�</a> | 
		<a href="{S_URL}/archiver/">վ��浵</a> | 
		<a href="mailto:$_SCONFIG[adminemail]">��ϵ����</a>
	</div>
</div>

<div id="footer">
	<p id="copyright">
		Powered by <a href="http://www.supesite.com" target="_blank"><strong>Supe<span>Site</span></strong></a> <em><?=S_VER?></em> 
		&#169; 2001-2008 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
		<br />{eval debuginfo();}
	</p>
</div>
<!-- /Footer -->


<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
</body>
</html>