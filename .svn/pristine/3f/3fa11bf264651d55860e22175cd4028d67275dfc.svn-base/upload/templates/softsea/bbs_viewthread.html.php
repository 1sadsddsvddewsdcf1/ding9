<?exit?>
{template bbs_header}
<!--{eval $ads3 = getad('system', 'bbs', '3');}-->
<!--{if !empty($ads3['pageheadad'])}-->
<div class="adbanner">$ads3[pageheadad]</div>
<!--{/if}-->
<!-- Content���� -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<div id="articledetail" class="block">
			<p id="articlectrl"><span>����:
				<a href="javascript:;" onclick="doZoom('12');">С</a>
				<a href="javascript:;" onclick="doZoom('14');">��</a>
				<a href="javascript:;" onclick="doZoom('16');">��</a></span>
				&nbsp;
			</p>
			<h1 id="articletitle">$thread[subject]</h1>
			<p id="articleinfo">
				$thread[author] ������: #date('Y-n-d H:i', $thread["dateline"])# 
				��Դ: <a href="{S_URL}/">$_SCONFIG[sitename]</a>
			</p>
			
			<!--{if !empty($ads3['pagecenterad'])}-->
			<div class="adbox">
				$ads3[pagecenterad]
			</div>
			<!--{/if}-->

			<div id="articlebody">
				$thread[message]
			
				<!--{if !empty($thread['attachments'])}-->
				<div class="imginlog">
					<!--{loop $thread['attachments'] $value}-->
					<!--{if ($value['isimage'])}-->
					<p><img src="$value[attachment]"><br />$value[filename]</p>
					<!--{else}-->
					<p><img src="{S_URL}/images/base/haveattach.gif" align="absmiddle" border="0"><a href="{B_URL}/attachment.php?aid=$value[aid]" target="_blank"><strong>$value[filename]</strong></a><br />($value[dateline], Size: $value[attachsize], Downloads: $value[downloads])</p>
					<!--{/if}-->
					<!--{/loop}-->
				</div>
				<!--{/if}-->
			</div>
		</div>
		
		<div id="commentlist" class="block">
			<!--{if $iarr}-->
			<h2>���»ظ�</h2>
			<dl>
				<!--{loop $iarr $key $post}-->
				<dt>$post[author] at #date("Y-n-d H:i:s", $post["dateline"])#</dt>
				<dd>
					<div>$post[message]</div>
					<!--{if !empty($item['posts'][$post['pid']]['attachments'])}-->
					<div class="imginlog">
						<!--{loop $item['posts'][$post['pid']]['attachments'] $post}-->
						<!--{if ($post['isimage'])}-->
						<p><img src="$post[attachment]"><br />$post[filename]</p>
						<!--{else}-->
						<p><img src="{S_URL}/images/base/haveattach.gif" align="absmiddle" border="0"><a href="{B_URL}/attachment.php?aid=$post[aid]" target="_blank"><strong>$post[filename]</strong></a><br />($post[dateline], Size: $post[attachsize], Downloads: $post[downloads])</p>
						<!--{/if}-->
						<!--{/loop}-->
					</div>
					<!--{/if}-->
				</dd>
				<!--{/loop}-->
			</dl>
			<!--{/if}-->
			<div class="pages">
				<div class="xspace-page">
					<a href="{B_URL}/viewthread.php?tid=$thread[tid]" target="_blank">�鿴ȫ���ظ�</a>
					<a href="{B_URL}/post.php?action=reply&tid=$thread[tid]" target="_blank">��Ҳ��˵����</a>
				</div>
			</div>
		</div>
	</div>

	<div class="side">

		<!--���¸�������-->
		<!--{block name="bbsthread" parameter="fid/$thread[fid]/limit/0,10/subjectlen/36/subjectdot/1/cachetime/24500/order/dateline DESC/cachename/newthread/tpl/data"}-->
		<!--{if $_SBLOCK['newthread']}-->
		<div class="block">
			<h3>���¸�������</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newthread'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="bbsthread" parameter="fid/$thread[fid]/dateline/2592000/order/views DESC/limit/0,10/subjectlen/36/subjectdot/1/cachetime/97200/cachename/hotthread/tpl/data"}-->
		<!--{if $_SBLOCK['hotthread']}-->
		<div class="block">
			<h3>�¶ȹ�ע�ȵ�</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotthread'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
	</div>		
</div>
<!-- /Content -->

<!--{if !empty($ads3['pagefootad'])}-->
<div class="adbox">$ads3[pagefootad]</div>
<!--{/if}-->

<script language="javascript" type="text/javascript">
<!--
	addImgLink("articlebody");
	addImgLink("commentlist");
//-->
</script>
<!--{if !empty($ads3['pagemovead']) || !empty($ads3['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads3['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads3['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads3['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}
