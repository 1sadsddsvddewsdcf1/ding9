<?exit?>
{template site_header}
<div id="menu"><h1>վ�㹫��</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<div class="block">
			<ul class="messagelist">
			<!--{loop $listvalue $value}-->
				<li>
					<h4><a href="$value[url]">$value[subject]</a></h4>
					<p class="msginfo">������: $value[author]&nbsp;&nbsp;��ʼʱ��: $value[starttime]&nbsp;&nbsp;����ʱ��: $value[endtime]</p>
					<p>$value[message]</p>
				</li>
			<!--{/loop}-->
			</ul>
			<div class="pages">
				$multipage
			</div>
		</div>
	</div>
	<div class="side">
		<!--{block name="announcement" parameter="order/displayorder/limit/0,10/cachetime/96400/subjectlen/30/cachename/announce/tpl/data"}-->
		<div class="block">
			<h3>���¹���</h3>
			<ul>
			<!--{loop $_SBLOCK['announce'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

{template site_footer}