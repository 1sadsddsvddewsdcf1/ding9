<?exit?>
{template topic_header}
<!--{eval $ads2 = getad('system', 'topic', '2');}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<!-- Content���� -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		<!--����������ר���б�-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="topic" parameter="perpage/40/catid/$thecat[subcatid]/order/id DESC/cachename/topiclist/tpl/data"}-->
		<!--{if $_SBLOCK['topiclist']}-->
		<div class="block">
			<h3>ר���б�</h3>
			<ul class="msgtitlelist linelist articlelist">
				<!--{loop $_SBLOCK['topiclist'] $value}-->
				<li>
					<cite>#date("y-m-d", $value["dateline"])# </cite>
					<a href="$value[url]" target="_blank">$value[subject]</a>
				</li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[topiclist_multipage]}-->
			<div class="pages">
				$_SBLOCK[topiclist_multipage]
			</div>
			<!--{/if}-->
			
		</div>
		<!--{/if}-->
		<!--{/if}-->
	</div>
	<div class="side">
		<div class="block blockG">
			<h1>$thecat[name]</h1>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{/if}-->

			<!--{block name="category" parameter="upid/$thecat[catid]/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['subarr'] $value}-->
					<li><a href="$value[url]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>

		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="topic" parameter="catid/$thecat[subcatid]/dateline/2592000/order/viewnum DESC/limit/0,8/cachetime/0/subjectlen/14/subjectdot/1/cachename/hottopicmonth/tpl/data"}-->
		<div class="block">
			<h3>�¶ȹ�ע�ȵ�</h3>
			<ul>
				<!--{loop $_SBLOCK['hottopicmonth'] $value}-->
				<li><a href="$value[url]" target="_blank">$value[subject]</a> <span class="smalltxt">($value[viewnum])</span></li>
				<!--{/loop}-->
			</ul>
		</div>

	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagefootad'])}-->
<div class="adbox">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}