<?exit?>
{template site_header}
<div id="menu"><h1>��ӭ $_SGLOBAL[supe_username_show] �ĵ���</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<div id="panel">
			<ul class="quicklink">
				<!--{if $_SGLOBAL[supe_uid]}-->
					<li><a href="#uid/$_SGLOBAL[supe_uid]#" class="myspace" target="_blank" style="color:red;font-weight:bold;">�ҵĸ��˿ռ�</a></li>
					<!--{if !empty($_SGLOBAL[member][havespace])}-->
					<li><a href="{S_URL}/spacecp.php?docp=me" class="spacemng" target="_blank">�����ҵĿռ�</a></li>
					<!--{else}-->
					<li><a href="#action/register#" class="spacesignup" target="_blank">�����ҵĿռ�</a></li>
					<!--{/if}-->
					<!--{if $_SGLOBAL[member][groupid] == 1}-->
					<li><a href="{S_URL}/admincp.php" class="sitemng" target="_blank">վ�����ƽ̨</a></li>
					<!--{/if}-->
					<li><a href="{S_URL}/batch.login.php?action=logout" class="logout">��ȫ�˳�</a></li>
				<!--{else}-->
					<li><a href="#action/login#" class="login">��¼վ��</a></li>
					<li><a href="{B_URL}/register.php?referer={S_URL}/index.php" class="register" target="_blank">ע���û�</a></li>
				<!--{/if}-->
				<li><a href="{S_URL}/" class="sitehome" target="_blank">վ����ҳ</a></li>
				<li><a href="{B_URL}/" class="bbs" target="_blank">������̳</a></li>
			</ul>
		</div>
	</div>
	<div class="side">
		<!--{block name="tag" parameter="order/spacenewsnum DESC/limit/0,18/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>����TAG</h3>
			<div style="height: 201px;">
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacenewsnum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
	</div>
</div>

{template site_footer}