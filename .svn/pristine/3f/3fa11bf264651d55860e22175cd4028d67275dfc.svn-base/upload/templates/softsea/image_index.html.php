<?exit?>
{template image_header}
<!--{eval $ads = getad('system', 'image', '1');}-->

<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<!-- Content���� -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		<!--��������ͼƬ-->
		<!--{block name="spaceimage" parameter="order/i.lastpost DESC/limit/0,15/cachetime/11400/subjectlen/16/subjectdot/1/showdetail/1/cachename/commendimage/tpl/data"}-->
		<div class="block" style="padding: 0;">
			<h2>��������ͼƬ</h2>
			<ul class="imagelist" style="height: 417px; overflow: hidden;">
				<!--{loop $_SBLOCK['commendimage'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
					<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">ȫ��</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" name="subjectsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!--����ͼƬ-->
		<!--{block name="spaceimage" parameter="order/i.dateline DESC/limit/0,12/subjectlen/26/subjectdot/1/showdetail/1/cachetime/12000/cachename/newimage/tpl/data"}-->
		<div class="block" style="height: 320px; overflow: hidden;">
			<h3>�����ϴ�</h3>
			<ul>
				<!--{loop $_SBLOCK['newimage'] $value}-->
				<li>
					<a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / $value[imagenum]ͼ</span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<!--���㣺�������-->
		<div id="focusimage" class="tabblock" style="height: 520px; overflow: hidden;">
			<h3 id="focusimagetabs" class="tabs">
				<a id="weektab" href="javascript:setTab('focusimage','week')" class="tab curtab">���ܽ���</a>
				<a id="monthtab" href="javascript:setTab('focusimage','month')" class="tab">���½���</a>
				<a id="alltab" href="javascript:setTab('focusimage','all')" class="tab">��������</a>
			</h3>
			<!--������������б�(һ��)-->
			<!--{block name="spaceimage" parameter="dateline/604800/order/i.replynum DESC/limit/0,10/cachetime/84400/showdetail/1/subjectlen/20/subjectdot/1/messagelen/34/messagedot/1/cachename/focusimageweek/tpl/data"}-->
			<div id="week" class="tabcontent">
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['focusimageweek'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								<a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a>
								$value[replynum]������
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--������������б�(һ��)-->
			<!--{block name="spaceimage" parameter="dateline/2592000/order/i.replynum DESC/limit/0,10/cachetime/94400/showdetail/1/subjectlen/20/subjectdot/1/messagelen/34/messagedot/1/cachename/focusimagemonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['focusimagemonth'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								<a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a>
								$value[replynum]������
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--������������б�(ȫ��)-->
			<!--{block name="spaceimage" parameter="order/i.replynum DESC/limit/0,10/cachetime/104400/showdetail/1/subjectlen/20/subjectdot/1/messagelen/34/messagedot/1/cachename/focusimage/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['focusimage'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								<a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a>
								$value[replynum]������
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<div class="side">
		<!--�¶Ⱥ���-->
		<!--{block name="spaceimage" parameter="dateline/2592000/order/i.lastpost DESC/limit/0,21/cachetime/57400/subjectlen/26/subjectdot/1/showdetail/1/cachename/specialimage/tpl/data"}-->
		<div class="block" style="height: 522px; overflow: hidden;">
			<h3>�¶Ⱥ���ͼ</h3>
			<ul>
				<!--{loop $_SBLOCK['specialimage'] $value}-->
				<li>
					<a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / $value[imagenum]ͼ</span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}