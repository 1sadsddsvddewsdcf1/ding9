<?exit?>
{template site_header}
<div id="menu"><h1>����ģʽ</h1></div>
<form id="opform" name="opform" action="batch.manage.php?uid=$uid&itemid=$itemid" method="post">
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $lang[manage] &gt;&gt; <a href="batch.manage.php?uid=$theuid">$space[spacename]</a>
			<!--{if !empty($item[subject])}--> &gt;&gt; <a href="#uid/$item[uid]/action/viewspace/itemid/$item[itemid]#" target="_blank">$item[subject]</a><!--{/if}-->
		</p>

		<!--{if !empty($item)}-->
		<div class="block">
			<h3>$item[subject]</h3>
			<ul class="messagelist">
				<li>
					<p class="msginfo"><strong>IP</strong>: $iteminf[postip]</p>
					<p class="msginfo"><strong>����ʱ��</strong>: #date("Y-m-d H:i:s", $item["dateline"])#</p>
					<p class="msginfo">�鿴($item[viewnum]) / ����($item[replynum]) / ����($item[goodrate]) / ����($item[badrate])</p>
					<p><strong>����Դ��</strong>:</p>
					<p><textarea style="width:95%; height:20em; border: 1px solid #EEE; background: #FFF; padding: 5px; font: 12px/160% Courier New, Arial, Helvetica, sans-serif;">$iteminf[message]</textarea></p>
				</li>
			</ul>
		</div>
		<div class="block" style="padding:0.5em;">
			<button type="submit" name="actionsubmit" value="delete" onclick="this.form.action+='&actionsubmit=delete';return confirm('ȷ��ֱ��ɾ����?');">ֱ��ɾ��</button> 
			<button type="submit" name="actionsubmit" value="rush" onclick="this.form.action+='&actionsubmit=rush';">�������վ</button> &nbsp;
			<select name="catid">$catstr</select> <button type="submit" name="actionsubmit" value="category" onclick="this.form.action+='&actionsubmit=category';">���ķ���</button> 
			$gradestr <button type="submit" name="actionsubmit" value="grade" onclick="this.form.action+='&actionsubmit=grade';">��˵ȼ�</button>
		</div>
		
		<!--{if !empty($commentlist)}-->
		<div id="commentlist" class="block">
			<h3>ǰ100������Դ����</h3>
			<ul class="messagelist">
				<!--{loop $commentlist $value}-->
				<li>
					<h4>
						<input type="checkbox" name="comments[]" value="$value[cid]">
						<!--{if empty($value[authorid])}-->$value[author]<!--{else}--><a href="batch.manage.php?uid=$value[authorid]" class="author">$value[author]</a><!--{/if}-->
					</h4>
					<div>
						<p class="msginfo">(#date("Y-n-d H:i:s", $value["dateline"])#, ����: <strong class="price">$value[rates]</strong>, IP: $value[ip] )</p>
						<p><textarea style="width:95%; height:5em; border: 1px solid #EEE; background: #FFF; padding: 5px; font: 12px/160% Courier New, Arial, Helvetica, sans-serif;">$value[message]</textarea></p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<div class="block" style="padding:0.5em;"><input type="checkbox" id="chkall" name="chkall" onclick="checkall(this.form, 'comments')" />ȫѡ <button type="submit" name="actionsubmit" value="deletecomment" onclick="this.form.action+='&actionsubmit=deletecomment';">ɾ������</button></div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--{if !empty($itemlist)}-->
		<div class="block">
			<h3>$space[username]����Ϣ�б�</h3>
			<ul class="msgtitlelist linelist articlelist">
				<!--{if $itemlist}-->
				<!--{loop $itemlist $value}-->
				<li>
					<cite>#date("m-d", $value["dateline"])#</cite>
					<input type="checkbox" name="items[]" value="$value[itemid]"> 
					{$lang[$value[type]]} / <a href="{S_URL}/batch.manage.php?itemid=$value[itemid]">$value[subject]</a> 
					($value[viewnum]/$value[replynum])
				</li>
				<!--{/loop}-->
				<!--{if $nextstart}--><li><h4><a href="{S_URL}/batch.manage.php?uid=$uid&start=$nextstart">�鿴��һ�б���Ϣ</a></h4></li><!--{/if}-->
				<!--{else}-->
				���ڻ�û�з�����Ϣ
				<!--{/if}-->
			</ul>
			<div>$multipage</div>
		</div>
		
		<div class="block" style="padding:0.5em;">
			<input type="checkbox" id="chkall" name="chkall" onclick="checkall(this.form, 'items')" /> ȫѡ &nbsp;
			<button type="submit" name="actionsubmit" value="deletelist" onclick="this.form.action+='&actionsubmit=deletelist';return confirm('ȷ��ֱ��ɾ����?');">ֱ��ɾ��</button> &nbsp;
			<button type="submit" name="actionsubmit" value="rushlist" onclick="this.form.action+='&actionsubmit=rushlist';">�������վ</button> &nbsp;
			$gradestr <button type="submit" name="actionsubmit" value="gradelist" onclick="this.form.action+='&actionsubmit=gradelist';">�ȼ����</button>
		</div>
	<!--{/if}-->

	</div>
	<div class="side">
		<div class="block blockG">
			<h3>���߿ռ�</h3>
			<div class="catepic">
				<div><a href="batch.manage.php?uid=$theuid"><img src="$space[photo]" alt="$space[spacename]" border="0" /></a></div>
				<p style="text-align:center;font-weight:bold;"><a href="batch.manage.php?uid=$theuid">$space[username]</a><br><a href="batch.manage.php?uid=$theuid">$space[spacename]</a>
				<br><br>$space[status]
				</p>
			</div>

			<ul class="msgtitlelist">
				<li>����Ϣ��: $space[spaceallnum]</li>
				<li>�������: $space[viewnum]</li>
				<li><a href="{B_URL}/viewpro.php?uid=$theuid">�鿴��̳����</a></li>
				<li><a href="batch.manage.php?uid=$theuid">�鿴����������Ϣ</a></li>
				<li>����ʱ��: #date("Y-m-d H:i:s", $space["dateline"])#</li>
				<li>������: #date("Y-m-d H:i:s", $space["lastpost"])#</li>
			</ul>
		</div>
		
	</div>

</div>
</form>


{template site_footer}