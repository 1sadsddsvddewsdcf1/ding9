<?exit?>
{template site_header}
<div id="menu"><h2>ͶƱ:$poll[subject]</h2></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<div id="articledetail" class="block">
			<h1 id="articletitle">ͶƱ:$poll[subject]</h1>
			<p id="articleinfo">ͶƱ����:$poll[votersnum]</p>
			<p id="articleinfo">��ʼʱ��($poll[dateline])-����ʱ��($poll[updatetime])</p>
			<div id="articlebody">ͶƱ˵��:$poll[summary]</div>
		</div>
		<div id="polldata" class="tabblock">
				<h3 id="polldatatabs">
					<a id="dopolltab" href="javascript:setTab('polldata','dopoll');" class="tab curtab">����ͶƱ</a>
					<a id="pollresulttab" href="javascript:setTab('polldata','pollresult');" class="tab">ͶƱ���</a>
				</h3>
				<div id="dopoll" class="tabcontent">
					<form id="pollform" action="#action/poll/php/1#" method="post">
					<table summary="ͶƱѡ��" cellpadding="3" cellspacing="0" border="0">
					<!--{loop $poll[options] $okey $options}-->
						<tr>
							<td>
							<!--{if $poll[ismulti]}-->
							<input type="checkbox" id="votekey-$okey" name="votekey[]" value="$okey" />
							<!--{else}-->
							<input type="radio" id="votekey-$okey" name="votekey[]" value="$okey" />
							<!--{/if}-->
							</td>
							<td>
							<label for="votekey-$okey">$options[name]</label>
							</td>
						</tr>
					<!--{/loop}-->
						<tr>
							<td>&nbsp;</td>
							<td style="text-align: center;">
								<input type="hidden" name="pollid" value="$poll[pollid]" />
								<input type="hidden" name="pollsubmit" value="yes" />
								<button id="dovote" name="pollbtn" type="submit" value="true">ͶƱ</button>
								&nbsp;<button type="button" onclick="setTab('polldata','pollresult');">�鿴���</button>
							</td>
						</tr>
					</table>
					</form>
				</div>
				<div id="pollresult" class="tabcontent" style="display: none;">
					<ul>
					<!--{loop $poll[options] $key $options}-->
						<li>
							$options[name]
							<div>
								<span class="pollnum">��Ʊ:$options[num] / $options[percent]%</span>
								<div class="pollpercent" style="width: $options[percent]%;">&nbsp;</div>
							</div>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
	</div>
	<div class="side">
		<div class="block">
			<h3>����ͶƱ</h3>
			<!--{block name="poll" parameter="order/dateline DESC/limit/0,10/cachetime/80000/cachename/poll/tpl/data"}-->
			<ul>
				<!--{if empty($_SBLOCK['poll'])}-->
					<li>��ʱû�е���</li>
				<!--{else}-->
					<!--{loop $_SBLOCK['poll'] $value}-->
					<li><a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div>
	</div>
</div>

{template site_footer}