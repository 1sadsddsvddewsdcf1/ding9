<?exit?>
{template bbs_header}
<!--{eval $ads = getad('system', 'bbs', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<!-- Content���� -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--ͼƬ����-->
		<!--{block name="bbsattachment" parameter="filetype/image/t_lastpost/2592000/order/t.replies DESC/limit/0,10/cachetime/49900/cachename/picthread/tpl/data"}-->
		<div id="slideimg">
		<!--{if !empty( $_SBLOCK['picthread'])}-->
		<script type="text/javascript" language="javascript">
		<!--			
		var xsTextBar = 1; //�Ƿ���ʾ�������ӣ�1Ϊ��ʾ��0Ϊ����ʾ
		var xsPlayBtn = 0; //�Ƿ���ʾ���Ű�ť��1��ʾ��0Ϊ����ʾ
		var xsImgSize = new Array(260,217); //�õ�ͼƬ�ĳߴ磬��ʽΪ������,�߶ȡ�
	
		var xsImgs = new Array();
		var xsImgLinks = new Array();
		var xsImgTexts = new Array();
		
		<!--{eval $i=0;}-->
		<!--{loop $_SBLOCK['picthread'] $key $value}-->
		xsImgs[$i] = "$value[attachment]";
		xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
		xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
		<!--{eval $i++;}-->
		<!--{/loop}-->
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		
		<!--������(2������������������)-->
		<!--{block name="bbsthread" parameter="showdetail/1/messagelen/80/subjectlen/34/dateline/172800/order/replies DESC/limit/0,1/cachetime/52400/cachename/coolthread/tpl/data"}-->
		<div id="headline">
			<!--{if !empty($_SBLOCK['coolthread'])}-->
			<!--{loop $_SBLOCK['coolthread'] $value}-->
			<strong><a href="$value[url]">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<div id="hotarticle" class="tabblock" style="margin-left: 274px; height: 176px;">
			<h3 id="hotarticletabs" class="tabs">
				<a id="newtab" href="javascript:setTab('hotarticle','new')" class="tab curtab">��̳����</a>
				<a id="daytab" href="javascript:setTab('hotarticle','day')" class="tab">�����ȵ�</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week')" class="tab">�����ȵ�</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all')" class="tab">��������</a>
			</h3>
			<!--��������-->
			<!--{block name="bbsthread" parameter="order/dateline DESC/limit/0,6/cachetime/21400/cachename/ratehot/tpl/data"}-->
			<div id="new" class="tabcontent">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['ratehot'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--���������б�(һ��)-->
			<!--{block name="bbsthread" parameter="dateline/604800/order/views DESC/limit/0,6/cachetime/72400/subjectlen/40/subjectdot/1/cachename/hotthreadweek/tpl/data"}-->
			<div id="day" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthreadweek'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--���������б�(һ��)-->
			<!--{block name="bbsthread" parameter="dateline/2592000/order/views DESC/limit/0,6/cachetime/82400/subjectlen/40/subjectdot/1/cachename/hotthreadmonth/tpl/data"}-->
			<div id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthreadmonth'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--���������б�(ȫ��)-->
			<!--{block name="bbsthread" parameter="order/views DESC/limit/0,6/cachetime/92400/subjectlen/40/subjectdot/1/cachename/hotthread/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthread'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
	<!-- �Ҳ� -->
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">ȫ��</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" name="subjectsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<div id="bbsintro" class="block" style="height: 86px; overflow: hidden;">
			<h3>��������</h3>
			<ul class="msgtitlelist">
			<li><a href="{B_URL}/">������̳</a> <span class="smalltxt">���뽻������</span></li>
			<li><a href="{B_URL}/register.php">ע���Ա</a> <span class="smalltxt">ӵ�и��˿ռ�</span></li>
			</ul>
		</div>

		<!-- ��̳���� -->
		<!--{block name="bbsannouncement" parameter="order/displayorder/limit/0,1/cachetime/96400/cachename/announcelist/tpl/data"}-->
		<div id="announcement">
			<strong>����:</strong>
			<!--{if empty($_SBLOCK['announcelist'])}-->
				��ʱû�й���
			<!--{else}-->
			<!--{loop $_SBLOCK['announcelist'] $ikey $value}-->
				<a href="$value[url]" target="_blank">$value[subject]</a>
			<!--{/loop}-->
			<!--{/if}-->
		</div>


	</div>
	<!-- /�Ҳ� -->
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<div class="blockcategorylist">
			<!--����������б�-->
			<!--{loop $_SBLOCK['forumarr'] $ckey $cat}-->
			<!--{eval $ctime=3800+30*$ckey;}-->
			<!--{block name="bbsthread" parameter="fid/$cat[fid]/order/dateline DESC/limit/0,5/cachetime/$ctime/subjectlen/40/subjectdot/1/cachename/threadlist/tpl/data"}-->
			<div class="blockcategory" style="height: 170px;">
				<h3><a href="#action/forumdisplay/fid/$cat[fid]#">$cat[name]</a></h3>
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['threadlist'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
					<li><a href="#action/forumdisplay/fid/$cat[fid]#" class="more">���࡭��</a></li>
				</ul>
			</div>
			<!--{/loop}-->
		</div>
	</div>
	<!-- �Ҳ��� -->
	<div class="side">

		<!--����������������-->
		<!--{block name="bbsforum" parameter="type/forum/allowblog/1/order/posts DESC/limit/0,10/cachetime/14400/cachename/hotforums/tpl/data"}-->
		<div id="hottforum" class="block" style="height: 320px;">
			<h3>��̳����������</h3>
			<ol>
				<!--{loop $_SBLOCK['hotforums'] $value}-->
				<li><a href="$value[url]">$value[name] <span class="smalltxt">$value[posts]</span></a></li>
				<!--{/loop}-->
			</ol>
		</div>

		<!--��Ա����-->
		<div id="hotmembers" class="tabblock" style="height: 260px; overflow: hidden;">
			<h3 id="hotmemberstabs" class="tabs">
				<a id="poststab" href="javascript:setTab('hotmembers','posts')" class="tab curtab">��������</a>
				<a id="onlinetab" href="javascript:setTab('hotmembers','online')" class="tab">��������</a>
			</h3>
			<!--{block name="bbsmember" parameter="order/m.posts DESC/limit/0,10/cachetime/86400/cachename/hotmembers/tpl/data"}-->
			<div id="posts" class="tabcontent">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotmembers'] $value}-->
					<li><cite style="text-align: right; margin-right: 5px;">$value[posts]</cite><a href="$value[url]">$value[username]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{block name="bbsmember" parameter="order/m.oltime DESC/limit/0,10/cachetime/86400/cachename/toponline/tpl/data"}-->
			<div id="online" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['toponline'] $value}-->
					<li><cite style="width: 80px; text-align: right;">$value[oltime]Сʱ</cite><a href="$value[url]">$value[username]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
		<!--���¸�������-->
		<!--{block name="bbsthread" parameter="order/lastpost DESC/limit/0,14/subjectlen/30/subjectdot/1/cachetime/11460/cachename/newpost/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>��������</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newpost'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[replies])</span></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!-- /Content -->
<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}