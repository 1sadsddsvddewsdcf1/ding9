<?exit?>
{template spaces_header}
<!--{eval $ads = getad('system', 'spaces', '1');}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
	
		<!--�ռ�֮��-->
		<!--{if $page<2}-->
		<!--{block name="userspace" parameter="isstar/1/showdetail/1/limit/0,100/order/u.lastpost DESC/cachetime/17400/cachename/spacestar/tpl/data"}-->
		<div class="block">
			<h3>�ռ�֮��</h3>
			<ul class="imagelist">
				<!--{loop $_SBLOCK['spacestar'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank" title="$value[spacename]"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
					<p><a href="$value[url]" target="_blank">$value[spacename]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--�������-->
		<!--{block name="userspace" parameter="perpage/20/showdetail/1/order/u.lastpost DESC/cachetime/17400/cachename/lastpostspace/tpl/data"}-->
		<div class="block">
			<h2>�ռ�����б�</h2>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['lastpostspace'] $value}-->
				<li>
					<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a></p>
					<div>
						<em class="smalltxt">��Ϣ��: $value[spaceallnum]</em>
						<h4><a href="$value[url]" target="_blank">$value[spacename]</a></h4>
						<!--{if $value['announcement']}--><p>$value[announcement]</p><!--{/if}-->
						<p class="msginfo">
							<a href="$value[url]" target="_blank" class="author">$value[username]</a>
							<!--{if $value['province']}--> $value[province]<!--{/if}-->
							<!--{if $value['city']}-->/ $value[city]<!--{/if}--> &nbsp;
							������: #date("Y-m-d", $value["dateline"])#<!--{if !empty($value[lastpost])}-->, ������: #date("Y-m-d", $value["lastpost"])#<!--{/if}-->
						</p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{if $_SBLOCK[lastpostspace_multipage]}-->
			<div class="pages">
				$_SBLOCK[lastpostspace_multipage]
			</div>
			<!--{/if}-->
		</div>
	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">ȫ��</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" name="subjectsearch" value="true">����</button>
				<a href="{S_URL}/batch.search.php">�߼�����</a>
			</form>
		</div>
		<!-- �û���� -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!-- ͬ�ǿռ� -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
				<button value="true" type="submit" name="usersearch">ͬ�ǿռ�</button>
			</form>
		</div>
		<!--һ�ܸ������а�-->
		<!--{block name="userspace" parameter="lastpost/604800/limit/0,10/order/u.viewnum DESC/cachetime/29800/cachename/hotlist/tpl/data"}-->
		<div class="block">
			<h3>һ�ܸ������а�</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

{template site_footer}