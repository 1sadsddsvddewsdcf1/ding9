<?exit?>
{template blog_header}
<!--{eval $ads2 = getad('system', 'blog', '2');}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--������������־�б�-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="spaceblog" parameter="perpage/20/catid/$thecat[subcatid]/order/i.dateline DESC/showspacename/1/showdetail/1/messagelen/300/messagedot/1/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		<div class="block">
			<h3>��־�б�</h3>
			<ul class="messagelist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<h4><a href="$value[url]" target="_blank">$value[subject]</a></h4>
					<p class="msginfo">
						<a href="#uid/$value[uid]#" target="_blank">$value[username]</a>
						<!--{if $value[province]}-->($value[province]) <!--{/if}-->
						������ #date("Y-m-d", $value["dateline"])# 
						<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">����: $value[replynum]</a> <!--{/if}-->
						<!--{if $value[goodrate]}-->����: $value[goodrate] <!--{/if}-->
						<!--{if !empty($value['tags'])}-->
						��ǩ:
						<!--{loop $value['tags'] $tag}-->
						<!--{eval $newtag = rawurlencode($tag);}-->
						<a href="#action/tag/tagname/$newtag#" target="_blank">$tag</a> 
						<!--{/loop}-->
						</p>
						<!--{/if}-->
					</p>
					<p>$value[message] <a href="$value[url]" target="_blank">...ȫ��</a></p>
				</li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[newlist_multipage]}-->
			<div class="pages">
			$_SBLOCK[newlist_multipage]
			</div>
			<!--{/if}-->
			
		</div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--��̳��Դ�б�-->
		<!--{if !empty($thecat['bbsmodel'])}-->
		<!--{if $_SGET['page']<2 || !empty($_SGET['mode'])}-->
		<!--{eval $_SGET['mode']='bbs';}-->
		<!--{block name="bbsthread" parameter="perpage/20/$thecat[blockparameter]/cachename/bbsthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['bbsthreadlist']}-->
		<div class="block">
			<h3>��̳��Դ</h3>
			<ul class="msgtitlelist linelist articlelist">
				<!--{loop $_SBLOCK['bbsthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[bbsthreadlist_multipage]}-->
			<div class="pages">
			$_SBLOCK[bbsthreadlist_multipage]
			</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->
		
		<!--{block name="category" parameter="upid/$thecat[catid]/ischannel/2/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
		<!--{if $_SGET['page']<2}-->
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['subarr'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spaceblog" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/40/cachename/subnewlist/tpl/data"}-->
		<!--{if $_SBLOCK['subnewlist']}-->
		<div class="blockcategory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subnewlist'] $value}-->
				<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
				<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		</div>
		<!--{/if}-->
	</div>
	<div class="side">
		<div class="block blockG">
			<h1>$thecat[name]</h1>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{else}-->
			<div class="catepic">
				<p>$thecat[name]</p>
			</div>
			<!--{/if}-->

			<!--{if $_SBLOCK['subarr']}-->
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subarr'] $value}-->
				<li><a href="$value[url]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->
		</div>
		
		<!--ר���б�-->
		<!--{block name="category" parameter="upid/$thecat[catid]/ischannel/1/showattach/1/order/c.displayorder/limit/0,100/cachetime/16400/cachename/channel/tpl/data"}-->
		<!--{if $_SBLOCK['channel']}-->
		<div class="block">
			<h3>ר��</h3>
			<ul class="imglogolist">
				<!--{loop $_SBLOCK['channel'] $value}-->
				<li>
					<a href="#action/category/catid/$value[catid]#"><img src="$value[thumb]" alt="" /></a>
					<p><a href="#action/category/catid/$value[catid]#">$value[name]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="spaceblog" parameter="dateline/2592000/catid/$thecat[subcatid]/order/i.viewnum DESC/limit/0,15/subjectlen/30/subjectdot/1/cachetime/17200/cachename/hotnews/tpl/data"}-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>���¹�ע�ȵ�</h3>
			<ul>
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<li>
					<a href="$value[url]">$value[subject]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#">$value[username]</a></span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagefootad'])}-->
<div class="adbox">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}