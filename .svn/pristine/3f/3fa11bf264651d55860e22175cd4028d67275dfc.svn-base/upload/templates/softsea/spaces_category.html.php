<?exit?>
{template spaces_header}
<!--{eval $ads2 = getad('system', 'spaces', '2');}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--��ǰ���������б�-->
		<!--{block name="userspace" parameter="perpage/40/catid/$thecat[subcatid]/order/u.lastpost DESC/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		
		<div class="block">
			<h3>�ռ��б�</h3>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a></p>
					<div>
						<em>��Ϣ��: $value[spaceallnum]</em>
						<h4><a href="$value[url]" target="_blank">$value[spacename]</a></h4>
						<!--{if !empty($value[announcement])}--><p>$value[announcement]</p><!--{/if}-->
						<p class="msginfo">
							<a href="$value[url]" target="_blank" class="author">$value[username]</a><!--{if $value['province']}--> $value[province]<!--{/if}--><!--{if $value['city']}-->/ $value[city]<!--{/if}-->, ������: #date("Y-m-d", $value["dateline"])#<!--{if !empty($value[lastpost])}-->, ������: #date("Y-m-d", $value["lastpost"])#<!--{/if}--></p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[newlist_multipage]}-->
			<div class="pages">
			$_SBLOCK[newlist_multipage]
			</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->

		<!--��̳��Դ�б�-->
		<!--{if !empty($thecat['bbsmodel'])}-->
		<!--{if $_SGET['page']<2 || !empty($_SGET['mode'])}-->
		<!--{eval $_SGET['mode']='bbs';}-->
		<!--{block name="bbsthread" parameter="perpage/40/$thecat[blockparameter]/cachename/bbsthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['bbsthreadlist']}-->
		<div class="block">
			<h3>��̳��Դ</h3>
			<ul class="msgtitlelist linelist articlelist">
				<!--{loop $_SBLOCK['bbsthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[bbsthreadlist_multipage]}-->
			<div class="pages">
				$_SBLOCK[bbsthreadlist_multipage]
			</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->
		
		<!--�ӷ��������б�-->
		<!--{block name="category" parameter="upid/$thecat[catid]/ischannel/2/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['subarr'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
		<!--{block name="userspace" parameter="catid/$cat[subcatid]/limit/0,10/order/u.lastpost DESC/cachetime/$ctime/cachename/sublist/tpl/data"}-->
		<!--{if $_SBLOCK['sublist']}-->	
		<div class="blockcategory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['sublist'] $value}-->
				<li><cite><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[spacename]</a></li>
				<!--{/loop}-->
				<li><a href="#action/category/catid/$cat[catid]#" class="more">���࡭��</a></li>
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		</div>
	</div>

	<div class="side">
	
		<div class="block blockG">
			<h1>$thecat[name]</h1>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{/if}-->
			
			<!--{if $_SBLOCK['subarr']}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['subarr'] $value}-->
					<li><a href="$value[url]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>
		
		<!--ר���б�-->
		<!--{block name="category" parameter="upid/$thecat[catid]/ischannel/1/showattach/1/order/c.displayorder/limit/0,100/cachetime/16400/cachename/channel/tpl/data"}-->
		<!--{if $_SBLOCK['channel']}-->
		<div class="block">
			<h3>ר��</h3>
			<ul class="imglogolist">
				<!--{loop $_SBLOCK['channel'] $value}-->
				<li>
					<a href="#action/category/catid/$value[catid]#"><img src="$value[thumb]" alt="" /></a>
					<p><a href="#action/category/catid/$value[catid]#">$value[name]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--һ�ܸ������а�-->
		<!--{block name="userspace" parameter="catid/$thecat[subcatid]/lastpost/604800/limit/0,10/order/u.viewnum DESC/cachetime/29800/cachename/hotlist/tpl/data"}-->
		<div class="block">
			<h3>һ�ܸ������а�</h3>
			<ul>
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagefootad'])}-->
<div class="adbox">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads2['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads2['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->
	
{template site_footer}