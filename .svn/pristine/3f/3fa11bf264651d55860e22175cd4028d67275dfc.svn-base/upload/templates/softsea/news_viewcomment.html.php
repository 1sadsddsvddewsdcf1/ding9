<?exit?>
{template news_header}
<!--{eval $ads2 = getad('system', 'news', '3');}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">����λ�ã�
			<a href="{S_URL}/">��ҳ</a>
			&gt;&gt; �鿴����
		</p>
		
		<div id="articledetail">
			<h1 id="articletitle">����: <a href="#action/viewnews/itemid/$item[itemid]#">$item[subject]</a></h1>
			<p id="articleinfo">
				�鿴��: $item[viewnum] |
				������: $item[replynum] |
				����: $item[goodrate] |
				����: $item[badrate]
			</p>
			<!--{if !empty($ads3['pagecenterad'])}-->
			<div class="adbox">$ads3[pagecenterad]</div>
			<!--{/if}-->	
		</div>
		<div id="commentlist">
			<dl>
				<!--{loop $iarr $value}-->
				<dt>
					<span>
						<a href="#action/viewcomment/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#">ɾ��</a> 
						<a href="javascript:;" onclick="getQuote($value[cid])">����</a>
					</span>
					<!--{if empty($value[authorid])}-->$value[author]<!--{else}--><a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a><!--{/if}-->
					&nbsp; ����ʱ�䣺 #date("Y-n-d H:i:s", $value["dateline"])#
				</dt>
				<dd>
					<!--{if empty($value['message'])}-->
					�� <span style="font-size:16px">$value[rates]</span> ��
					<!--{else}-->
					$value[message]
					<!--{/if}-->
				</dd>
				<!--{/loop}-->
			</dl>
				
			<!--{if $multipage}-->
			<div class="pages">
				$multipage
			</div>
			<!--{/if}-->
		</div>
		
		<div id="xspace-rates" class="block">
			<div id="xspace-rates-bg">
				<div id="xspace-rates-star" class="xspace-rates0">&nbsp;</div>
				<div id="xspace-rates-a">
					<a href="javascript:;" onmouseover="rateHover(-5);" onmouseout="rateOut();" onclick="setRateXML('-5', '$item[itemid]');">-5</a>
					<a href="javascript:;" onmouseover="rateHover(-3);" onmouseout="rateOut();" onclick="setRateXML('-3', '$item[itemid]');">-3</a>
					<a href="javascript:;" onmouseover="rateHover(-1);" onmouseout="rateOut();" onclick="setRateXML('-1', '$item[itemid]');">-1</a>
					<a href="javascript:;" onmouseover="rateHover(0);" onmouseout="rateOut();" onclick="setRateXML('0', '$item[itemid]');">-</a>
					<a href="javascript:;" onmouseover="rateHover(1);" onmouseout="rateOut();" onclick="setRateXML('1', '$item[itemid]');">+1</a>
					<a href="javascript:;" onmouseover="rateHover(3);" onmouseout="rateOut();" onclick="setRateXML('3', '$item[itemid]');">+3</a>
					<a href="javascript:;" onmouseover="rateHover(5);" onmouseout="rateOut();" onclick="setRateXML('5', '$item[itemid]');">+5</a>
				</div>
				<input type="hidden" id="xspace-rates-value" name="rates" value="0" />
			</div>
			<p>���֣�<span id="xspace-rates-tip">0</span></p>
		</div>
			
		<div id="comment">
			<h2>����˵����</h2>
			<form id="postcomm" action="#action/viewcomment/itemid/$item[itemid]/php/1#" method="post">
				<p><label for="message">����:</label><textarea id="message" name="message" onfocus="showcode()" onkeydown="ctlent(event,'postcomm');"></textarea></p>
				<!--{if empty($_SCONFIG['noseccode'])}-->
				<p class="seccodeline"><label for="seccode">��֤:</label><input type="text" id="seccode" name="seccode" value="" size="20" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="�����壿�����һ��" /></p>
				<!--{/if}-->
				<p><button type="submit" id="submitcomm" name="submitcomm" value="submit">��������</button></p>
				<input type="hidden" id="itemid" name="itemid" value="$item[itemid]" />
			</form>
		</div>
	</div>

	<div class="side">

		<!--�¶ȹ�ע�ȵ�-->
		<!--{block name="spacenews" parameter="catid/$item[catid]/dateline/2592000/order/i.replynum DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/28800/cachename/hotnews/tpl/data"}-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>�¶������ȵ�</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
	</div>
</div>

<!--{if !empty($ads3['pagefootad'])}-->
<div class="adbox">$ads3[pagefootad]</div>
<!--{/if}-->

<script language="javascript" type="text/javascript">
<!--
	addMediaAction('articlebody');
	addImgLink("articlebody");
//-->
</script>
<!--{if !empty($ads3['pagemovead']) || !empty($ads3['pageoutad'])}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads3['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, "<div style=\"position: absolute; right: 6px; bottom: -"+lengthobj.winHeight+"px;\"><!--{eval echo jsstrip($ads3['pageoutad']);}--><\/div>").floatIt();
<!--{/if}-->
<!--{if !empty($ads3['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, "<div style=\"position: absolute; left: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div><div style=\"position: absolute; right: 6px; top: 6px;\"><!--{eval echo jsstrip($ads3['pagemovead']);}--><br \/><img src=\"{S_URL}/images/base/advclose.gif\" onMouseOver=\"this.style.cursor='hand'\" onClick=\"closeBanner('coupleBannerAdv');\"><\/div>").floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}