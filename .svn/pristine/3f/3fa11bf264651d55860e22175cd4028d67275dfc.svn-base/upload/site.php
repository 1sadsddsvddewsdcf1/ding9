<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	վ��ͨ�ü�ҳ��

	$RCSfile: site.php,v $
	$Revision: 1.7 $
	$Date: 2007/01/09 02:41:06 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

if(!empty($_SGET['type'])) {
	$tplname = 'site_'.trim(str_replace(array('..', '/', '\\'), '', $_SGET['type']));
	if($_SGET['type'] == 'map') {
		include_once(S_ROOT.'./function/model.func.php');
		$modelarr = array();
		foreach($channels['menus'] as $key => $val) {
			if($val['type'] == 'model' && $val['status'] == 1) {
				$catlistarr = getmodelinfoall('modelname', $key);
				$modelarr[$key] = array(
					'modelalias' => $catlistarr['models']['modelalias'],
					'modelname' => $catlistarr['models']['modelname'],
					'categories' => $catlistarr['categories'],
				);
			}
		}
	}
} else {
	header('Location: '.S_URL);
	exit;
}

include_once(S_ROOT.'./include/common.inc.php');

if($_SGET['type'] == 'panel') getcookie(1);

$title = $lang['view_site'];

if(file_exists(S_ROOT.'./templates/'.$_SCONFIG['template'].'/'.$tplname.'.html.php')) {
	include template($tplname);
} else {
	header('Location: '.S_URL);
}
ob_out();
?>