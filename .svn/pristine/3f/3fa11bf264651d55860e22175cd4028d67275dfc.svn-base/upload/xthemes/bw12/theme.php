<?php

$themes = array(
	'name'		=> 'У԰����',
	'preview'	=> 'space.jpg',
	'css'		=> 'space.css',
	'thumb'		=> 'thumb_space.jpg'
);

?>