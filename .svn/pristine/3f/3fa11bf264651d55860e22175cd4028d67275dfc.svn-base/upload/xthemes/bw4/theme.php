<?php

$themes = array(
	'name'		=> '��Ҷ�ʻ�',
	'preview'	=> 'space.jpg',
	'css'		=> 'space.css',
	'thumb'		=> 'thumb_space.jpg'
);

?>