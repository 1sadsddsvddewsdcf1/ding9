<?php

$themes = array(
	'name'		=> '׷��ƻ�',
	'preview'	=> 'space.jpg',
	'css'		=> 'space.css',
	'thumb'		=> 'thumb_space.jpg'
);

?>