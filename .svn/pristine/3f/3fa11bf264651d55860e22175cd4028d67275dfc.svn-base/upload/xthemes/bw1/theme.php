<?php

$themes = array(
	'name'		=> 'ʱ�����',
	'preview'	=> 'space.jpg',
	'css'		=> 'space.css',
	'thumb'		=> 'thumb_space.jpg'
);

?>