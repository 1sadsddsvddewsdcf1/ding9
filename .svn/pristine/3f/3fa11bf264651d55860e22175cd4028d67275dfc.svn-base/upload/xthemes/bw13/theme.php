<?php

$themes = array(
	'name'		=> '��Ը����',
	'preview'	=> 'space.jpg',
	'css'		=> 'space.css',
	'thumb'		=> 'thumb_space.jpg'
);

?>