<?php

$themes = array(
	'name'		=> 'ħ��ʦ',
	'preview'	=> 'space.jpg',
	'css'		=> 'space.css',
	'thumb'		=> 'thumb_space.jpg'
);

?>