<div id="sidebar">
<?php include (TEMPLATEPATH . '/rsidebar.php'); ?>		
</div>



